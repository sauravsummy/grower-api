package com.sunsum.exception;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ErrorDetailsTest {

  @Test
  void givenNoArgument_whenErrorDetailsConstructed_thenDateIsSet() {
    // Given (No argument provided)

    // When
    ErrorDetails errorDetails = new ErrorDetails();

    // Then
    assertNotNull(errorDetails.getDate());
    assertNull(errorDetails.getMessage());
  }

  @Test
  void givenMessage_whenErrorDetailsConstructed_thenDateAndMessageAreSet() {
    // Given
    String expectedMessage = "Test error message";

    // When
    ErrorDetails errorDetails = new ErrorDetails(expectedMessage);

    // Then
    assertNotNull(errorDetails.getDate());
    assertEquals(expectedMessage, errorDetails.getMessage());
  }

  @Test
  void givenNullObject_whenEquals_thenNotEquals() {
    ErrorDetails errorDetails = new ErrorDetails("Error message");
    assertNotEquals(null, errorDetails);
  }

  @Test
  void givenSameObject_whenEquals_thenEquals() {
    ErrorDetails errorDetails = new ErrorDetails("Error message");
    assertEquals(errorDetails, errorDetails);
  }

  @Test
  void givenDifferentObjectSameValues_whenEquals_thenEquals() {
    ErrorDetails errorDetails1 = new ErrorDetails("Error message");
    ErrorDetails errorDetails2 = new ErrorDetails("Error message");
    assertEquals(errorDetails1, errorDetails2);
  }

  @Test
  void givenDifferentObjectDifferentValues_whenEquals_thenNotEquals() {
    ErrorDetails errorDetails1 = new ErrorDetails("Error message");
    ErrorDetails errorDetails2 = new ErrorDetails("Different message");
    assertNotEquals(errorDetails1, errorDetails2);
  }

  @Test
  void givenSameValues_whenHashCode_thenSameHashCode() {
    ErrorDetails errorDetails1 = new ErrorDetails("Error message");
    ErrorDetails errorDetails2 = new ErrorDetails("Error message");
    assertEquals(errorDetails1.hashCode(), errorDetails2.hashCode());
  }

  @Test
  void givenNewValues_whenSetters_thenGettersMatch() {
    ErrorDetails errorDetails = new ErrorDetails();
    errorDetails.setMessage("Test Message");
    errorDetails.setDate("Test Date");
    assertEquals("Test Message", errorDetails.getMessage());
    assertEquals("Test Date", errorDetails.getDate());
  }
}
