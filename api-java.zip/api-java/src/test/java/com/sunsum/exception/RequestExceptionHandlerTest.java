package com.sunsum.exception;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

class RequestExceptionHandlerTest {

  private MockMvc mockMvc;

  @RestController
  static class DummyController {
    @GetMapping("/triggerBusinessRuleException")
    void triggerBusinessRuleException() {
      throw new BusinessRuleException("Business rule failed", HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/triggerGeneralException")
    void triggerGeneralException() throws Exception {
      throw new Exception("General error");
    }

    @PostMapping("/triggerMethodArgumentNotValidException")
    void triggerMethodArgumentNotValidException(@Valid @RequestBody DummyRequest request) {}

    static class DummyRequest {
      @NotNull private String requiredField;
    }
  }

  @BeforeEach
  void setUp() {
    mockMvc =
        MockMvcBuilders.standaloneSetup(new DummyController())
            .setControllerAdvice(new RequestExceptionHandler())
            .build();
  }

  @Test
  void givenBusinessRuleException_whenHandlingException_thenErrorResponse() throws Exception {
    // Given
    BusinessRuleException ex =
        new BusinessRuleException("Business rule failed", HttpStatus.BAD_REQUEST);

    // When & Then
    mockMvc
        .perform(get("/triggerBusinessRuleException").requestAttr("exception", ex))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON))
        .andExpect(jsonPath("$.message").value("Business rule failed"));
  }

  @Test
  void givenGeneralException_whenHandlingException_thenInternalServerErrorResponse()
      throws Exception {
    // Given
    Exception ex = new Exception("General error");

    // When & Then
    mockMvc
        .perform(get("/triggerGeneralException").requestAttr("exception", ex))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON))
        .andExpect(jsonPath("$.message").value("General error"));
  }

  @Test
  void givenMethodArgumentNotValidException_whenHandled_thenBadRequestStatus() throws Exception {
    mockMvc
        .perform(
            post("/triggerMethodArgumentNotValidException")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}"))
        .andExpect(status().isBadRequest());
  }
}
