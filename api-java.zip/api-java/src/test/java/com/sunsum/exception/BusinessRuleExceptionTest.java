package com.sunsum.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

class BusinessRuleExceptionTest {

  @Test
  void
      givenErrorMessageAndHttpStatus_whenBusinessRuleExceptionConstructed_thenCorrectPropertiesSet() {
    // Given
    String expectedErrorMessage = "Test error message";
    HttpStatus expectedHttpStatus = HttpStatus.BAD_REQUEST;

    // When
    BusinessRuleException exception =
        new BusinessRuleException(expectedErrorMessage, expectedHttpStatus);

    // Then
    assertEquals(expectedErrorMessage, exception.getMessage());
    assertEquals(expectedErrorMessage, exception.getErrorMessage());
    assertEquals(expectedHttpStatus, exception.getHttpStatus());
  }
}
