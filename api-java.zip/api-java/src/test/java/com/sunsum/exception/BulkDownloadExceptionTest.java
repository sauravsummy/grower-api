package com.sunsum.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class BulkDownloadExceptionTest {

  @Test
  void givenMessage_whenBulkDownloadExceptionConstructed_thenCorrectMessage() {
    // Given
    String expectedMessage = "Test message";

    // When
    BulkDownloadException exception = new BulkDownloadException(expectedMessage);

    // Then
    assertEquals(expectedMessage, exception.getMessage());
  }

  @Test
  void givenMessageAndCause_whenBulkDownloadExceptionConstructed_thenCorrectMessageAndCause() {
    // Given
    String expectedMessage = "Test message";
    Throwable cause = new Throwable("Cause");

    // When
    BulkDownloadException exception = new BulkDownloadException(expectedMessage, cause);

    // Then
    assertEquals(expectedMessage, exception.getMessage());
    assertEquals(cause, exception.getCause());
  }
}
