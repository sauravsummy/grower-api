package com.sunsum.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class BulkUploadExceptionTest {

  @Test
  void givenMessage_whenBulkUploadExceptionConstructed_thenCorrectMessage() {
    // Given
    String expectedMessage = "Test message";

    // When
    BulkUploadException exception = new BulkUploadException(expectedMessage);

    // Then
    assertEquals(expectedMessage, exception.getMessage());
  }

  @Test
  void givenMessageAndCause_whenBulkUploadExceptionConstructed_thenCorrectMessageAndCause() {
    // Given
    String expectedMessage = "Test message";
    Throwable cause = new Throwable("Cause");

    // When
    BulkUploadException exception = new BulkUploadException(expectedMessage, cause);

    // Then
    assertEquals(expectedMessage, exception.getMessage());
    assertEquals(cause, exception.getCause());
  }
}
