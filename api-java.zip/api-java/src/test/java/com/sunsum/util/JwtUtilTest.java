package com.sunsum.util;

import static org.junit.jupiter.api.Assertions.*;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

class JwtUtilTest {

  private JwtUtil jwtUtil;
  private String secret = "your_secret_key";

  @BeforeEach
  void setUp() throws NoSuchFieldException, IllegalAccessException {
    jwtUtil = new JwtUtil();

    // Set the secret using reflection
    Field secretField = JwtUtil.class.getDeclaredField("secret");
    secretField.setAccessible(true);
    secretField.set(jwtUtil, secret);
  }

  @Test
  void givenToken_whenExtractUserId_thenUserIdReturned() {
    String userId = "user1";
    String token = jwtUtil.getToken(userId, List.of(new SimpleGrantedAuthority("ROLE_USER")));

    String extractedUserId = jwtUtil.extractUserId(token);

    assertEquals(userId, extractedUserId);
  }

  @Test
  void givenToken_whenExtractExpiration_thenExpirationDateReturned() {
    // Arrange
    String userId = "user1";
    UserDetails userDetails =
        new User(userId, "password", List.of(new SimpleGrantedAuthority("ROLE_USER")));

    // Create a token with expiration
    Date now = new Date();
    Date expiryDate = new Date(now.getTime() + 3600000); // 1 hour later

    // Remove milliseconds for consistent comparison
    expiryDate = removeMilliseconds(expiryDate);

    String token =
        Jwts.builder()
            .setSubject(userId)
            .setIssuedAt(now)
            .setExpiration(expiryDate)
            .signWith(SignatureAlgorithm.HS512, secret)
            .compact();

    // Act
    Date extractedExpiration = jwtUtil.extractExpiration(token);

    // Remove milliseconds for consistent comparison
    extractedExpiration = removeMilliseconds(extractedExpiration);

    // Assert
    assertNotNull(extractedExpiration, "The extracted expiration date should not be null.");
    assertEquals(
        expiryDate,
        extractedExpiration,
        "The extracted expiration date should match the one set in the token.");
  }

  private Date removeMilliseconds(Date date) {
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(date);
    calendar.set(Calendar.MILLISECOND, 0);
    return calendar.getTime();
  }

  @Test
  void givenValidTokenAndUserDetails_whenIsValid_thenTrue() {
    String userId = "user1";
    UserDetails userDetails =
        new User(userId, "password", Arrays.asList(new SimpleGrantedAuthority("ROLE_USER")));
    String token = jwtUtil.getToken(userId, userDetails.getAuthorities());

    boolean isValid = jwtUtil.isValid(token, userDetails);

    assertTrue(isValid);
  }

  @Test
  void givenUserIdAndAuthorities_whenGetToken_thenTokenGenerated() {
    String userId = "user1";
    List<SimpleGrantedAuthority> authorities = List.of(new SimpleGrantedAuthority("ROLE_USER"));

    String token = jwtUtil.getToken(userId, authorities);

    assertNotNull(token);
    assertTrue(Jwts.parser().setSigningKey(secret).isSigned(token));
  }
}
