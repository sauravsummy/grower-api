package com.sunsum.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
class RisoCareCommonUtilsTest {

  @ParameterizedTest
  @ValueSource(strings = {"8108181818181", "81818181818", "01818181818"})
  void givenMobileNumber_whenFormatMobileNumber_thenShouldFormat(String mobileNo) {

    // given
    String mobileNumberStr = mobileNo;

    // when
    mobileNo = RisocareCommonUtils.formatMobileNumber(mobileNo);

    // then
    String expectedNumber = mobileNumberStr.substring(mobileNumberStr.length() - 11);
    expectedNumber = expectedNumber.startsWith("0") ? expectedNumber : "0" + expectedNumber;
    assertEquals(expectedNumber, mobileNo);
  }

  @Test
  void givenString_whenHashString_thenShouldReturnHashedString() {

    // given
    String inputString = "stringToBeHashed";

    // when
    String hashedString = RisocareCommonUtils.hashString(inputString);

    // then
    assertEquals("e2bfa75cf177478e7c13e9a1b3467266b2d62f242421e7a62e8a050ede959eb0", hashedString);
  }
}
