package com.sunsum.util;

import static org.junit.jupiter.api.Assertions.*;

import com.sunsum.constants.TaskFieldStatus;
import com.sunsum.model.entity.TaskField;
import java.time.LocalDate;
import lombok.RequiredArgsConstructor;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@RequiredArgsConstructor
class TaskUtilTest {

  @Test
  void givenTaskField_whenGetStatus_ShouldReturnStatusAsCompleted() {
    // given
    TaskField taskField = new TaskField();
    taskField.setTaskStatus(TaskFieldStatus.COMPLETED);
    taskField.setCompletionDate(LocalDate.now());

    // when
    String status = TaskUtil.getStatus(taskField);

    // then
    assertEquals("completed", status);
  }

  @Test
  void givenTaskField_whenGetStatus_ShouldReturnStatusAsInExecutable() {
    // given
    TaskField taskField = new TaskField();

    // when
    String status = TaskUtil.getStatus(taskField);

    // then
    assertEquals("inexecutable", status);
  }

  @Test
  void givenTaskField_whenGetStatus_ShouldReturnStatusAsExecutable() {
    // given
    TaskField taskFieldWithExecutableDateAnyTime = new TaskField();
    taskFieldWithExecutableDateAnyTime.setExecutableDate(DateUtil.MIN_DATE);

    TaskField taskField = new TaskField();
    taskField.setExecutableDate(LocalDate.now().minusDays(2));

    // when
    String status1 = TaskUtil.getStatus(taskFieldWithExecutableDateAnyTime);
    String status2 = TaskUtil.getStatus(taskField);

    // then
    assertEquals("executable", status1);
    assertEquals("executable", status2);
  }

  @Test
  void givenTaskField_whenGetStatus_ShouldReturnStatusAsOverdue() {
    // given
    TaskField taskField = new TaskField();
    taskField.setDueDate(LocalDate.now().minusDays(1));

    // when
    String status = TaskUtil.getStatus(taskField);

    // then
    assertEquals("overdue", status);
  }
}
