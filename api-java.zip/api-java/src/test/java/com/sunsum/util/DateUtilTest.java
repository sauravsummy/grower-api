package com.sunsum.util;

import static org.junit.jupiter.api.Assertions.*;

import com.sunsum.constants.AppConstants;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;

class DateUtilTest {

  @Test
  void givenDate_whenFormatDate_thenFormattedString() {
    Date date = new Date();
    String formattedDate = DateUtil.formatDate(date);
    assertNotNull(formattedDate);
  }

  @Test
  void givenNullDate_whenFormatDate_thenNull() {
    assertNull(DateUtil.formatDate(null));
  }

  @Test
  void givenValidStringDate_whenParseDate_thenDate() {
    String stringDate = "01-01-2023";
    Date parsedDate = DateUtil.parseDate(stringDate);
    assertNotNull(parsedDate);
  }

  @Test
  void givenInvalidStringDate_whenParseDate_thenThrowException() {
    String stringDate = "invalid-date";
    assertThrows(IllegalArgumentException.class, () -> DateUtil.parseDate(stringDate));
  }

  @Test
  void givenStringDateAndFormat_whenParseDate_thenDate() {
    String stringDate = "01-01-2023";
    String dateFormat = "dd-MM-yyyy";
    Date parsedDate = DateUtil.parseDate(stringDate, dateFormat);
    assertNotNull(parsedDate);
  }

  @Test
  void whenToday_thenNotNull() {
    assertNotNull(DateUtil.today());
  }

  @Test
  void givenLocalDateTimeAndOffset_whenConvertUtcToLocalTime_thenLocalDateTime() {
    LocalDate currentDate = LocalDate.now();
    long offset = 60;
    LocalDate result =
        DateUtil.convertUtcToLocalTime(currentDate.atStartOfDay(), offset).toLocalDate();
    assertNotNull(result);
  }

  @Test
  void givenTimestamp_whenLocalDateFromTimestamp_thenLocalDate() {
    Timestamp timestamp = new Timestamp(System.currentTimeMillis());
    LocalDate localDate = DateUtil.localDateFromTimestamp(timestamp);
    assertNotNull(localDate);
  }

  @Test
  void givenStringDate_whenParseToLocalDate_thenLocalDate() {
    String inputDate = "2023-01-01";
    String pattern = "yyyy-MM-dd";
    LocalDate localDate = DateUtil.parseToLocalDate(inputDate, pattern);
    assertNotNull(localDate);
  }

  @Test
  void whenCurrentLocalDate_thenNotNull() {
    assertNotNull(DateUtil.currentLocalDate());
  }

  @Test
  void givenNullHttpHeaders_whenGetTimeZoneOffset_thenZeroOffset() {
    long offset = DateUtil.getTimeZoneOffset(null);
    assertEquals(0, offset);
  }

  @Test
  void givenHttpHeadersWithNoTimeZoneOffset_whenGetTimeZoneOffset_thenZeroOffset() {
    HttpHeaders headers = new HttpHeaders();
    long offset = DateUtil.getTimeZoneOffset(headers);
    assertEquals(0, offset);
  }

  @Test
  void givenHttpHeadersWithTimeZoneOffset_whenGetTimeZoneOffset_thenCorrectOffset() {
    HttpHeaders headers = new HttpHeaders();
    headers.add(AppConstants.TIME_ZONE_OFFSET, "120");
    long offset = DateUtil.getTimeZoneOffset(headers);
    assertEquals(120, offset);
  }

  @Test
  void givenLocalDateTimeAndPositiveOffset_whenConvertUtcToLocalTime_thenAdjustedTime() {
    LocalDateTime dateTime = LocalDateTime.of(2023, 1, 1, 12, 0);
    LocalDateTime result = DateUtil.convertUtcToLocalTime(dateTime, 60);
    assertEquals(LocalDateTime.of(2023, 1, 1, 11, 0), result);
  }

  @Test
  void givenLocalDateTimeAndNegativeOffset_whenConvertUtcToLocalTime_thenAdjustedTime() {
    LocalDateTime dateTime = LocalDateTime.of(2023, 1, 1, 12, 0);
    LocalDateTime result = DateUtil.convertUtcToLocalTime(dateTime, -60);
    assertEquals(LocalDateTime.of(2023, 1, 1, 13, 0), result);
  }

  @Test
  void givenValidStringDateAndInvalidFormat_whenParseDate_thenThrowException() {
    assertThrows(
        IllegalArgumentException.class, () -> DateUtil.parseDate("01-01-2023", "invalid-format"));
  }

  @Test
  void givenInvalidStringDateAndValidFormat_whenParseDate_thenThrowException() {
    assertThrows(
        IllegalArgumentException.class, () -> DateUtil.parseDate("invalid-date", "dd-MM-yyyy"));
  }
}
