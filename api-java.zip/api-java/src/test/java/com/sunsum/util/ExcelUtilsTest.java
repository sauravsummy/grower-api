package com.sunsum.util;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Map;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class ExcelUtilsTest {

  private ExcelUtils excelUtils;

  @Mock private XSSFWorkbook workbook;
  @Mock private XSSFSheet sheet;
  @Mock private Row row;
  @Mock private Cell cell;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    excelUtils = new ExcelUtils();
  }

  @Test
  void givenHeadersAndMandatoryColumns_whenWriteHeaderRow_thenHeadersWritten() throws IOException {
    // Create real instances of workbook and sheet
    XSSFWorkbook workbook = new XSSFWorkbook();
    XSSFSheet sheet = workbook.createSheet();

    // Sample header and mandatory columns
    String headers = "Header1,Header2,Header3";
    String mandatoryColumns = "Header1,Header3";

    // Call the method under test
    ExcelUtils excelUtils = new ExcelUtils();
    excelUtils.writeHeaderRow(headers, mandatoryColumns, workbook, sheet);

    // Verify that the headers are written correctly
    Row row = sheet.getRow(0);
    assertNotNull(row);
    Cell cell1 = row.getCell(0);
    Cell cell2 = row.getCell(1);
    Cell cell3 = row.getCell(2);

    // Verify cell values
    assertEquals("Header1", cell1.getStringCellValue());
    assertEquals("Header2", cell2.getStringCellValue());
    assertEquals("Header3", cell3.getStringCellValue());

    // Cleanup
    workbook.close();
  }

  @Test
  void givenValueAndCellStyle_whenCreateCell_thenCellCreated() {
    // Arrange
    when(row.createCell(anyInt())).thenReturn(cell);
    Object value = "Test";
    CellStyle style = mock(CellStyle.class);

    // Act
    excelUtils.createCell(row, 1, value, style);

    // Assert
    verify(cell).setCellValue("Test");
    verify(cell).setCellStyle(style);
  }

  @Test
  void givenASheet_whenColumnNameToIndex_thenMapReturned() throws IOException {
    XSSFWorkbook workbook = new XSSFWorkbook();
    XSSFSheet sheet = workbook.createSheet();
    XSSFRow row = sheet.createRow(0);
    XSSFCell cell1 = row.createCell(0);
    XSSFCell cell2 = row.createCell(1);

    cell1.setCellValue("Column1");
    cell2.setCellValue("Column2");

    ExcelUtils excelUtils = new ExcelUtils();

    // Act
    Map<String, Integer> result = excelUtils.columnNameToIndex(sheet);

    // Assert
    assertNotNull(result);
    assertEquals(Integer.valueOf(0), result.get("Column1"));
    assertEquals(Integer.valueOf(1), result.get("Column2"));

    workbook.close();
  }

  @Test
  void givenValueAndStyle_whenCreateCell_thenCellCreatedWithCorrectValueAndStyle()
      throws IOException {
    XSSFWorkbook workbook = new XSSFWorkbook();
    XSSFSheet sheet = workbook.createSheet();
    Row row = sheet.createRow(0);
    CellStyle style = workbook.createCellStyle(); // Sample style for testing

    ExcelUtils excelUtils = new ExcelUtils();
    excelUtils.createCell(row, 0, "Test Value", style);

    Cell cell = row.getCell(0);
    assertNotNull(cell);
    assertEquals("Test Value", cell.getStringCellValue());
    assertEquals(style, cell.getCellStyle());

    workbook.close();
  }

  @Test
  void givenValueOfType_whenCreateCell_thenCellCreatedWithCorrectType() throws IOException {
    XSSFWorkbook workbook = new XSSFWorkbook();
    XSSFSheet sheet = workbook.createSheet();
    Row row = sheet.createRow(0);
    CellStyle style = workbook.createCellStyle(); // Sample style for testing
    LocalDate dateValue = LocalDate.now();

    ExcelUtils excelUtils = new ExcelUtils();

    excelUtils.createCell(row, 0, dateValue, LocalDate.class, style, CellType.NUMERIC);

    Cell cell = row.getCell(0);
    assertNotNull(cell);

    assertEquals(style, cell.getCellStyle());

    workbook.close();
  }

  @Test
  void givenSheet_whenColumnNameToIndex_thenMapReturned() throws IOException {
    XSSFWorkbook workbook = new XSSFWorkbook();
    XSSFSheet sheet = workbook.createSheet();
    Row row = sheet.createRow(0);

    row.createCell(0).setCellValue("Column1");
    row.createCell(1).setCellValue("Column2");
    row.createCell(2).setCellValue("Column3");

    ExcelUtils excelUtils = new ExcelUtils();
    Map<String, Integer> columnIndexMap = excelUtils.columnNameToIndex(sheet);

    assertNotNull(columnIndexMap);
    assertEquals(3, columnIndexMap.size());
    assertEquals(0, columnIndexMap.get("Column1"));
    assertEquals(1, columnIndexMap.get("Column2"));
    assertEquals(2, columnIndexMap.get("Column3"));

    workbook.close();
  }
}
