package com.sunsum.util;

import static com.sunsum.constants.AppConstants.FILE_PATH_SEPARATOR;
import static org.mockito.Mockito.*;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import java.io.IOException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.ResourceLoader;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

@ExtendWith(MockitoExtension.class)
class AwsS3UtilTest {

  @Mock private ResourceLoader resourceLoader;

  @Mock private AmazonS3 amazonS3;

  @InjectMocks private AwsS3Util awsS3Util;

  private MultipartFile mockFile;
  private final String bucketName = "test-bucket";
  private final String key = "test/key";

  @BeforeEach
  void setUp() {
    mockFile = new MockMultipartFile("file", "testfile.txt", "text/plain", "test data".getBytes());
  }

  @Test
  void givenFile_whenUploadFileToS3_thenSucceed() throws IOException {
    // Act
    awsS3Util.uploadFileToS3(mockFile, bucketName, key);

    // Assert
    verify(amazonS3, times(1))
        .putObject(
            eq(bucketName),
            eq(key + FILE_PATH_SEPARATOR + mockFile.getOriginalFilename()),
            any(),
            any(ObjectMetadata.class));
  }

  @Test
  void givenFileName_whenDelete_thenSucceed() {
    // Arrange
    String fileName = "testfile.txt";

    // Act
    awsS3Util.delete(bucketName, fileName);

    // Assert
    verify(amazonS3, times(1)).deleteObject(bucketName, fileName);
  }
}
