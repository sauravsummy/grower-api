package com.sunsum.util;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.UserDetails;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.UserProfileRepository;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

@ExtendWith(MockitoExtension.class)
class CommonUtilsTest {

  @Mock private UserProfileRepository userProfileRepository;

  @Mock private ModelMapper modelMapper;

  @Mock private SecurityContext securityContext;

  @Mock private Authentication authentication;

  @InjectMocks private CommonUtils commonUtils;

  private final long USER_ID = 1L;

  @BeforeEach
  void setUp() {
    SecurityContextHolder.setContext(securityContext);
    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(String.valueOf(USER_ID));
  }

  @Test
  void givenAuthenticatedUser_whenGetCurrentLoggedInUserId_thenReturnUserId() {
    // Act
    long currentUserId = commonUtils.getCurrentLoggedInUserId();

    // Assert
    assertEquals(USER_ID, currentUserId);
  }

  @Test
  void givenAuthenticatedUser_whenGetCurrentLoggedInUser_thenReturnUserProfile() {
    // Arrange
    UserProfile userProfile = new UserProfile();
    when(userProfileRepository.findById(USER_ID)).thenReturn(Optional.of(userProfile));

    // Act
    Optional<UserProfile> foundUserProfile = commonUtils.getCurrentLoggedInUser();

    // Assert
    assertTrue(foundUserProfile.isPresent());
    assertEquals(userProfile, foundUserProfile.get());
  }

  @Test
  void givenUserProfileExists_whenGetCurrentLoggedInUserDetails_thenReturnUserDetails() {
    // Arrange
    UserProfile userProfile = new UserProfile();
    UserDetails userDetails = new UserDetails();
    when(userProfileRepository.findById(USER_ID)).thenReturn(Optional.of(userProfile));
    when(modelMapper.map(userProfile, UserDetails.class)).thenReturn(userDetails);

    // Act
    UserDetails foundUserDetails = commonUtils.getCurrentLoggedInUserDetails();

    // Assert
    assertNotNull(foundUserDetails);
    assertEquals(userDetails, foundUserDetails);
  }

  @Test
  void givenNoUserProfile_whenGetCurrentLoggedInUserDetails_thenThrowBusinessRuleException() {
    // Arrange
    when(userProfileRepository.findById(USER_ID)).thenReturn(Optional.empty());

    // Act and Assert
    assertThrows(BusinessRuleException.class, () -> commonUtils.getCurrentLoggedInUserDetails());
  }
}
