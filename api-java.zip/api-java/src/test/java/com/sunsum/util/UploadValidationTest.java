package com.sunsum.util;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.multipart.MultipartFile;

class UploadValidationTest {

  private UploadValidation uploadValidation;

  @Mock private MultipartFile mockFile;
  @Mock private Sheet mockSheet;
  @Mock private Row mockRow;
  @Mock private Cell mockCell;
  @Mock private Iterator<Row> rowIterator;
  @Mock private Iterator<Cell> cellIterator;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    uploadValidation = new UploadValidation();
  }

  @Test
  void givenValidFile_whenCheckFileType_thenTrue() {
    // Arrange
    when(mockFile.getOriginalFilename()).thenReturn("valid.xlsx");

    // Act
    boolean result = uploadValidation.checkFileType(mockFile);

    // Assert
    assertTrue(result);
  }

  @Test
  void givenInvalidFile_whenCheckFileType_thenFalse() {
    // Arrange
    when(mockFile.getOriginalFilename()).thenReturn("invalid.txt");

    // Act
    boolean result = uploadValidation.checkFileType(mockFile);

    // Assert
    assertFalse(result);
  }

  @Test
  void givenEmptySheet_whenIsSheetEmpty_thenTrue() {
    // Arrange
    when(mockSheet.rowIterator()).thenReturn(Collections.emptyIterator());

    // Act
    boolean result = uploadValidation.isSheetEmpty(mockSheet);

    // Assert
    assertTrue(result);
  }

  @Test
  void givenNonEmptySheet_whenIsSheetEmpty_thenFalse() {
    // Arrange
    when(mockSheet.rowIterator()).thenReturn(Arrays.asList(mockRow).iterator());
    when(mockRow.cellIterator()).thenReturn(Arrays.asList(mockCell).iterator());
    when(mockCell.getStringCellValue()).thenReturn("Non-empty");

    // Act
    boolean result = uploadValidation.isSheetEmpty(mockSheet);

    // Assert
    assertFalse(result);
  }

  @Test
  void givenSheetWithHeaders_whenValidateHeaders_thenHeadersValidated() throws IOException {
    // Arrange
    List<String> mandatoryHeaders = Arrays.asList("Header1", "Header2");
    String headersString = "Header1, Header2, Header3";

    XSSFWorkbook workbook = new XSSFWorkbook();
    XSSFSheet sheet = workbook.createSheet();
    XSSFRow headerRow = sheet.createRow(0);

    // Set up headers in the sheet
    headerRow.createCell(0).setCellValue("Header1");
    headerRow.createCell(1).setCellValue("Header2");
    headerRow.createCell(2).setCellValue("Header3");

    UploadValidation uploadValidation = new UploadValidation();

    // Act
    boolean result = uploadValidation.validateHeaders(mandatoryHeaders, sheet);

    // Assert
    assertTrue(result);

    // Cleanup
    workbook.close();
  }

  @Test
  void givenFileType_whenGetMandatoryHeadersForFileType_thenHeadersListReturned() {
    // Arrange
    String headersString = "Header1, Header2, Header3";

    // Act
    List<String> result = uploadValidation.getMandatoryHeadersForFileType(headersString);

    // Assert
    assertEquals(Arrays.asList("Header1", "Header2", "Header3"), result);
  }

  @Test
  void givenRowWithMandatoryData_whenValidateMandatoryData_thenTrue() {
    // Arrange
    when(mockRow.getCell(0)).thenReturn(mockCell);
    when(mockRow.getCell(1)).thenReturn(mockCell);
    when(mockCell.getStringCellValue()).thenReturn("Data");
    Map<String, Integer> columnNameToIndex = new HashMap<>();
    columnNameToIndex.put("Column1", 0);
    columnNameToIndex.put("Column2", 1);
    List<String> mandatoryHeaders = Arrays.asList("Column1", "Column2");

    // Act
    boolean result =
        uploadValidation.validateMandatoryData(mockRow, mandatoryHeaders, columnNameToIndex);

    // Assert
    assertTrue(result);
  }

  @Test
  void givenRowWithMissingMandatoryData_whenValidateMandatoryData_thenFalse() {
    // Arrange
    when(mockRow.getCell(0)).thenReturn(mockCell);
    when(mockRow.getCell(1)).thenReturn(null);
    when(mockCell.getStringCellValue()).thenReturn("Data");
    Map<String, Integer> columnNameToIndex = new HashMap<>();
    columnNameToIndex.put("Column1", 0);
    columnNameToIndex.put("Column2", 1);
    List<String> mandatoryHeaders = Arrays.asList("Column1", "Column2");

    // Act
    boolean result =
        uploadValidation.validateMandatoryData(mockRow, mandatoryHeaders, columnNameToIndex);

    // Assert
    assertFalse(result);
  }
}
