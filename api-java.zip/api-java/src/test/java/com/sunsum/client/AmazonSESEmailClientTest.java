package com.sunsum.client;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;

import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
import com.amazonaws.services.simpleemail.model.*;
import com.sunsum.client.impl.AmazonSESEmailClient;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.EmailDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@ExtendWith(MockitoExtension.class)
class AmazonSESEmailClientTest {

  @Mock private AmazonSimpleEmailService mockAmazonSimpleEmailService;

  @InjectMocks private AmazonSESEmailClient emailClient;

  @Test
  void givenEmailDto_whenSendEmail_thenSuccessful() {
    // given
    EmailDTO emailDTO = new EmailDTO();
    emailDTO.setToEmail("recipient@gmail.com");
    emailDTO.setFromEmail("sender@gmail.com");
    emailDTO.setSubject("Subject");
    emailDTO.setBody("Body");

    given(mockAmazonSimpleEmailService.sendEmail(any(SendEmailRequest.class)))
        .willReturn(new SendEmailResult());

    // when
    ResponseEntity<String> responseEntity = emailClient.sendEmail(emailDTO);

    // then
    assertSame(HttpStatus.OK, responseEntity.getStatusCode());
  }

  @Test
  void givenEmailDto_whenSendEmail_thenThrowAmazonSimpleEmailServiceException() {
    // given
    EmailDTO emailDTO = new EmailDTO();
    given(mockAmazonSimpleEmailService.sendEmail(any(SendEmailRequest.class)))
        .willThrow(new AmazonSimpleEmailServiceException("Test exception"));

    // when & then
    assertThrows(
        BusinessRuleException.class,
        () -> emailClient.sendEmail(emailDTO),
        "Error sending email with SES");
  }

  @Test
  void givenEmailDto_whenSendEmail_thenThrowGeneralException() {
    // given
    EmailDTO emailDTO = new EmailDTO();
    given(mockAmazonSimpleEmailService.sendEmail(any(SendEmailRequest.class)))
        .willThrow(new RuntimeException("Test exception"));

    // when & then
    assertThrows(
        BusinessRuleException.class,
        () -> emailClient.sendEmail(emailDTO),
        "Exception occurred while sending email");
  }
}
