package com.sunsum.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.sunsum.constants.ErrorMsgConstants;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.FarmHoldingResponse;
import com.sunsum.model.dto.FieldTaskStatusResponse;
import com.sunsum.model.dto.FieldTasksStatus;
import com.sunsum.model.dto.FieldsResponse;
import com.sunsum.service.FarmHoldingService;
import com.sunsum.service.FieldService;
import com.sunsum.service.FieldTaskService;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@ExtendWith(MockitoExtension.class)
class FarmHoldingControllerTest {

  @Mock private FarmHoldingService farmHoldingService;

  @Mock private FieldService fieldService;

  @Mock private FieldTaskService fieldTaskService;

  @InjectMocks private FarmHoldingController farmHoldingController;

  @BeforeEach
  void setUp() {
    // Additional setup can be added here if required
  }

  @Test
  void whenGetFarmHoldingsForUser_thenReturnFarmHoldings() {
    // Given
    FarmHoldingResponse expectedResponse = new FarmHoldingResponse();
    when(farmHoldingService.getFarmHoldingsForUser()).thenReturn(expectedResponse);

    // When
    ResponseEntity<FarmHoldingResponse> response = farmHoldingController.getFarmHoldingsForUser();

    // Then
    assertEquals(ResponseEntity.ok(expectedResponse), response);
  }

  @Test
  void givenUserHasPermission_whenGetFields_thenReturnFields() {
    // Given
    String farmHoldingId = "1";
    FieldsResponse expectedResponse = new FieldsResponse(new ArrayList<>());
    when(farmHoldingService.hasUserPermissionForFarmHolding(Long.parseLong(farmHoldingId)))
        .thenReturn(true);
    when(fieldService.getFields(farmHoldingId)).thenReturn(ResponseEntity.ok(expectedResponse));

    // When
    ResponseEntity<FieldsResponse> response = farmHoldingController.getFields(farmHoldingId);

    // Then
    assertEquals(ResponseEntity.ok(expectedResponse), response);
  }

  @Test
  void givenUserHasNoPermission_whenGetFields_thenThrowException() {
    // Given
    String farmHoldingId = "1";
    when(farmHoldingService.hasUserPermissionForFarmHolding(Long.parseLong(farmHoldingId)))
        .thenReturn(false);

    // When & Then
    BusinessRuleException exception =
        assertThrows(
            BusinessRuleException.class, () -> farmHoldingController.getFields(farmHoldingId));
    Assertions.assertEquals(ErrorMsgConstants.UNAUTHORIZED_USER_FOR_FARMHOLDING, exception.getMessage());
    assertEquals(HttpStatus.FORBIDDEN, exception.getHttpStatus());
  }

  @Test
  void whenGetAllFieldTasks_thenReturnAllFieldTasks() {
    // Given
    List<FieldTasksStatus> fieldTasksStatuses = List.of(new FieldTasksStatus());
    when(fieldTaskService.getAllFieldsTask(1L)).thenReturn(fieldTasksStatuses);

    // When
    ResponseEntity<FieldTaskStatusResponse> response = farmHoldingController.getAllFieldTasks(1L);

    // Then
    assertEquals(HttpStatus.OK, response.getStatusCode());
  }

  @Test
  void whenGetUpComingFieldTasks_thenUpComingFieldTasks() {
    // Given
    List<FieldTasksStatus> fieldTasksStatuses = List.of(new FieldTasksStatus());
    when(fieldTaskService.getUpcomingFieldTasks(1L)).thenReturn(fieldTasksStatuses);

    // When
    ResponseEntity<FieldTaskStatusResponse> response =
        farmHoldingController.getUpComingFieldTasks(1L);

    // Then
    assertEquals(HttpStatus.OK, response.getStatusCode());
  }
}
