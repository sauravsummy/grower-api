package com.sunsum.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import com.sunsum.service.OtpService;
import javax.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@ExtendWith(MockitoExtension.class)
class OtpControllerTest {

  @Mock private OtpService otpService;

  @Mock private HttpServletRequest request;

  @InjectMocks private OtpController otpController;

  @BeforeEach
  void setUp() {
    // Mock setup can be included here if required
  }

  @Test
  void givenMobileNumber_whenSendOtpToMobile_thenOtpSent() {
    // Arrange
    String mobileNo = "1234567890";
    String expectedResponse = "OTP sent to mobile";
    when(otpService.sendOtpToMobile(mobileNo)).thenReturn(ResponseEntity.ok(expectedResponse));

    // Act
    ResponseEntity<String> response = otpController.sendOtpToMobile(mobileNo, request);

    // Assert
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(expectedResponse, response.getBody());
  }

  @Test
  void givenEmail_whenSendOtpToEmail_thenOtpSent() {
    // Arrange
    String emailId = "test@example.com";
    String expectedResponse = "OTP sent to email";
    when(otpService.sendOtpToEmail(emailId)).thenReturn(ResponseEntity.ok(expectedResponse));

    // Act
    ResponseEntity<String> response = otpController.sendOtpToEmail(emailId, request);

    // Assert
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(expectedResponse, response.getBody());
  }
}
