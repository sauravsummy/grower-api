package com.sunsum.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.sunsum.constants.TaskFieldStatus;
import com.sunsum.model.dto.TaskStatusUpdateRequest;
import com.sunsum.model.dto.TaskView;
import com.sunsum.service.TaskService;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

@ExtendWith(MockitoExtension.class)
class TaskControllerTest {

  @Mock private TaskService taskService;
  @InjectMocks private TaskController taskController;

  @BeforeEach
  void setUp() {
    // Additional setup if required
  }

  @Test
  void whenGetTask_thenTaskIsReturned() {
    Long taskId = 1L;
    Long fieldId = 1L;
    TaskView taskView = new TaskView(); // Populate with test data
    when(taskService.getTaskView(taskId, fieldId)).thenReturn(taskView);

    ResponseEntity<TaskView> response = taskController.getTask(taskId, fieldId);

    assertEquals(taskView, response.getBody());
    assertEquals(200, response.getStatusCodeValue());
  }

  @Test
  void whenUpdateTaskStatus_thenStatusIsUpdated() {
    Long taskId = 1L;
    TaskStatusUpdateRequest updateRequest = getTaskStatusUpdateRequest();
    String updatedStatus = "Updated Status";
    when(taskService.updateTaskStatus(taskId, updateRequest)).thenReturn(updatedStatus);

    ResponseEntity<String> response = taskController.updateTaskStatus(taskId, updateRequest);

    assertEquals(updatedStatus, response.getBody());
    assertEquals(200, response.getStatusCodeValue());
  }

  private static TaskStatusUpdateRequest getTaskStatusUpdateRequest() {
    TaskFieldStatus status = TaskFieldStatus.COMPLETED; // Example status
    String completionDate = "2023-01-01";
    String reportDefinitions = "Some report definitions";
    Long fieldId = 1L;
    MultipartFile mockFile =
        new MockMultipartFile("image", "image.jpg", "image/jpeg", "test image content".getBytes());
    List<MultipartFile> images = Collections.singletonList(mockFile);

    TaskStatusUpdateRequest updateRequest =
        new TaskStatusUpdateRequest(status, completionDate, reportDefinitions, fieldId, images);
    return updateRequest;
  }
}
