package com.sunsum.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.sunsum.constants.ErrorMsgConstants;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.TokenRepository;
import com.sunsum.service.TokenService;
import com.sunsum.util.CommonUtils;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;

@ExtendWith(MockitoExtension.class)
class LogOffControllerTest {

  @InjectMocks private LogOffController logOffController;

  @Mock private TokenService tokenService;

  @Mock private CommonUtils commonUtils;

  private MockHttpServletRequest request;

  @Mock private TokenRepository tokenRepository;

  @BeforeEach
  void setUp() {
    request = new MockHttpServletRequest();
    logOffController = new LogOffController(request, tokenService, commonUtils);
  }

  @Test
  void givenValidToken_whenLogoff_thenSuccessResponse() {
    // Arrange
    String validToken = "valid_token";
    when(tokenService.logoff(validToken)).thenReturn(true);

    // Act
    ResponseEntity<?> response = logOffController.logoff("Bearer " + validToken);

    // Assert
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals("User successfully logged off.", response.getBody());
  }

  @Test
  void givenInvalidToken_whenLogoff_thenUnauthorizedResponse() {
    // Arrange
    String invalidToken = "invalid_token";
    when(tokenService.logoff(invalidToken)).thenReturn(false);

    // Act
    ResponseEntity<?> response = logOffController.logoff("Bearer " + invalidToken);

    // Assert
    assertEquals(HttpStatus.UNAUTHORIZED.value(), response.getStatusCodeValue());
    Assertions.assertEquals("Invalid token." + ErrorMsgConstants.UNAUTHORIZED_USER_MSG, response.getBody());
  }

  @Test
  void givenNoAuthorizationHeader_whenLogoff_thenUnauthorizedResponse() {
    // Arrange (no specific arrangement needed here)

    // Act
    Executable executable = () -> logOffController.logoff(null);

    // Assert
    assertThrows(NullPointerException.class, executable);
  }

  @Test
  void givenMalformedAuthorizationHeader_whenLogoff_thenUnauthorizedResponse() {

    // Act
    ResponseEntity<?> response = logOffController.logoff("InvalidTokenFormat");

    // Assert
    assertEquals(HttpStatus.UNAUTHORIZED.value(), response.getStatusCodeValue());
    Assertions.assertEquals("Invalid token." + ErrorMsgConstants.UNAUTHORIZED_USER_MSG, response.getBody());
  }

  @Test
  void givenServiceException_whenLogoff_thenServerErrorResponse() {
    // Arrange
    String validToken = "valid_token";

    when(tokenService.logoff(validToken)).thenThrow(new RuntimeException("Service exception"));

    // Act
    ResponseEntity<?> response = logOffController.logoff("Bearer " + validToken);

    // Assert
    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
  }

  @Test
  void givenValidToken_whenLogoffAll_thenSuccessResponse() {
    // Arrange
    String validToken = "valid_token";
    UserProfile userProfile = new UserProfile();
    when(commonUtils.getCurrentLoggedInUser()).thenReturn(Optional.of(userProfile));
    doNothing().when(tokenService).deleteTokenByUserProfile(userProfile);

    // Act
    ResponseEntity<?> response = logOffController.logoffAllDevices("Bearer " + validToken);

    // Assert
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals("User successfully logged off from all devices.", response.getBody());
  }

  @Test
  void givenInValidToken_whenLogoffAll_thenSuccessResponse() {
    // Arrange
    String inValidToken = "invalid_token";

    // Act
    ResponseEntity<?> response = logOffController.logoffAllDevices("Bearer " + inValidToken);

    // Assert
    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
  }
}
