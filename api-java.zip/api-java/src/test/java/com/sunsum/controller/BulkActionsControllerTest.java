package com.sunsum.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.BulkUploadTracker;
import com.sunsum.model.dto.SheetIngestionResult;
import com.sunsum.service.DownloadService;
import com.sunsum.service.UploadService;
import java.io.ByteArrayInputStream;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

@ExtendWith(MockitoExtension.class)
class BulkActionsControllerTest {

  @Mock private UploadService uploadService;

  @Mock private DownloadService downloadService;

  private BulkActionsController bulkActionsController;

  @BeforeEach
  void setUp() {
    bulkActionsController = new BulkActionsController(uploadService, downloadService);
  }

  @Test
  void givenMultipartFile_whenUpload_thenExpectSuccessResponse() {
    // Arrange
    MultipartFile file =
        new MockMultipartFile("data", "filename.txt", "text/plain", "content".getBytes());
    SheetIngestionResult result = new SheetIngestionResult();
    when(uploadService.bulkInsert(file)).thenReturn(result);

    // Act
    ResponseEntity<SheetIngestionResult> response = bulkActionsController.upload(file);

    // Assert
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(result, response.getBody());
  }

  @Test
  void givenCategory_whenDownload_thenExpectFileData() throws Exception {
    // Arrange
    String category = "test";
    byte[] testData = "test data".getBytes();
    when(downloadService.download(category)).thenReturn(new ByteArrayInputStream(testData));

    // Act
    ResponseEntity<byte[]> response = bulkActionsController.download(category);

    // Assert
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertArrayEquals(testData, response.getBody());
  }

  @Test
  void whenRequestUploadTracker_thenExpectListOfTrackers() {
    // Arrange
    List<BulkUploadTracker> trackers = Arrays.asList(new BulkUploadTracker());
    when(uploadService.getUploadTrackerDetails()).thenReturn(trackers);

    // Act
    ResponseEntity<List<BulkUploadTracker>> response = bulkActionsController.uploadTracker();

    // Assert
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(trackers, response.getBody());
  }

  @Test
  void givenErrorCategory_whenDownload_thenExpectException() {
    // Arrange
    String category = "error";
    when(downloadService.download(category)).thenThrow(new RuntimeException("Error"));

    // Assert
    assertThrows(BusinessRuleException.class, () -> bulkActionsController.download(category));
  }
}
