package com.sunsum.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sunsum.model.dto.FcmTokenRequest;
import com.sunsum.service.FcmTokenService;
import com.sunsum.util.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ExtendWith(MockitoExtension.class)
class FcmTokenControllerTest {

  private MockMvc mockMvc;

  @Mock private FcmTokenService fcmTokenService;

  @Mock private JwtUtil jwtUtil;

  @InjectMocks private FcmTokenController fcmTokenController;

  @BeforeEach
  public void setup() {
    mockMvc = MockMvcBuilders.standaloneSetup(fcmTokenController).build();
  }

  @Test
  void givenValidAuthorizationAndRequest_whenSaveFcmToken_thenReturnSuccessResponse()
      throws Exception {
    // Given
    String mockAuthHeader = "Bearer validToken";
    FcmTokenRequest request = new FcmTokenRequest();
    request.setDeviceType("Android");
    when(jwtUtil.extractUserId("validToken")).thenReturn("123");

    // When & Then
    mockMvc
        .perform(
            post("/api/v1/save-fcm-token")
                .header("Authorization", mockAuthHeader)
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(request)))
        .andExpect(status().isOk())
        .andExpect(content().string("FCM Token saved successfully"));

    verify(fcmTokenService, times(1)).saveFcmToken(any(FcmTokenRequest.class));
    verify(jwtUtil, times(1)).extractUserId("validToken");
  }

  @Test
  void givenInvalidAuthorization_whenSaveFcmToken_thenReturnErrorResponse() throws Exception {
    // Given
    String mockAuthHeader = "Invalid token";
    FcmTokenRequest request = new FcmTokenRequest();

    // When & Then
    mockMvc
        .perform(
            post("/api/v1/save-fcm-token")
                .header("Authorization", mockAuthHeader)
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(request)))
        .andExpect(status().isBadRequest());

    verify(fcmTokenService, never()).saveFcmToken(any(FcmTokenRequest.class));
  }

  @Test
  void givenNullUserId_whenSaveFcmToken_thenReturnErrorResponse() throws Exception {
    // Given
    String mockAuthHeader = "Bearer validToken";
    FcmTokenRequest request = new FcmTokenRequest();
    when(jwtUtil.extractUserId("validToken")).thenReturn(null);

    // When & Then
    mockMvc
        .perform(
            post("/api/v1/save-fcm-token")
                .header("Authorization", mockAuthHeader)
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(request)))
        .andExpect(status().isBadRequest());

    verify(fcmTokenService, never()).saveFcmToken(any(FcmTokenRequest.class));
  }
}
