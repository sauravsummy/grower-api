package com.sunsum.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.google.gson.Gson;
import com.sunsum.constants.ChannelType;
import com.sunsum.constants.ErrorMsgConstants;
import com.sunsum.constants.UserRole;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.OtpVerifyRequest;
import com.sunsum.model.entity.Role;
import com.sunsum.model.entity.Token;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.service.OtpService;
import com.sunsum.service.TokenService;
import com.sunsum.util.JwtUtil;
import com.sunsum.util.RisocareCommonUtils;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(SpringExtension.class)
class AuthControllerTest {

  @Mock private AuthenticationManager authenticationManager;
  @Mock private TokenService tokenService;
  @Mock private JwtUtil jwtUtil;
  @Mock private UserProfileRepository userProfileRepository;
  @Mock private OtpService otpService;

  @InjectMocks private AuthController authController;
  @Captor private ArgumentCaptor<Token> existingTokenCaptor;

  @Captor private ArgumentCaptor<Token> newTokenCaptor;

  private UserProfile dummyUser;

  @BeforeEach
  void setUp() {
    dummyUser = createDummyUser();
    when(userProfileRepository.findByEmailIgnoreCase(anyString()))
        .thenReturn(Optional.of(dummyUser));
    when(userProfileRepository.findByPhoneNo(anyLong())).thenReturn(Optional.of(dummyUser));
    when(otpService.isValidOtp(any())).thenReturn(true);
  }

  @Test
  void givenValidCredentials_whenAuth_thenSuccessResponse() {
    OtpVerifyRequest otpVerifyRequest =
        new OtpVerifyRequest("test@example.com", "123456", ChannelType.EMAIL_ID);
    ReflectionTestUtils.setField(authController, "deviceLoginLimit", 2L);
    when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
        .thenReturn(new UsernamePasswordAuthenticationToken(dummyUser, null));
    when(jwtUtil.getToken(anyString(), any())).thenReturn("mockToken");

    Token mockToken = new Token();
    when(tokenService.findByUserProfile(any(UserProfile.class))).thenReturn(List.of(mockToken));

    ResponseEntity<String> response = authController.auth(otpVerifyRequest);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertTrue(response.getBody().contains("mockToken"));
    assertTrue(response.getBody().contains(dummyUser.getName()));

    verify(tokenService).save(any(Token.class));
  }

  private UserProfile createDummyUser() {
    UserProfile user = new UserProfile();
    user.setId(1L);
    user.setName("Dummy User");
    user.setEmail("test@example.com");
    user.setRoles(createDummyRoles());
    return user;
  }

  private Set<Role> createDummyRoles() {
    Role userRole = new Role();
    userRole.setName(UserRole.ROLE_FIELD_SUPPORTER);
    return Collections.singleton(userRole);
  }

  @Test
  void givenInvalidOtp_whenAuth_thenThrowBusinessRuleException() {
    OtpVerifyRequest otpVerifyRequest =
        new OtpVerifyRequest("test@example.com", "wrongOtp", ChannelType.EMAIL_ID);
    when(otpService.isValidOtp(any())).thenReturn(false);

    assertThrows(BusinessRuleException.class, () -> authController.auth(otpVerifyRequest));
  }

  @Test
  void givenNonExistentUser_whenAuth_thenThrowBusinessRuleException() {
    OtpVerifyRequest otpVerifyRequest =
        new OtpVerifyRequest("nonexistent@example.com", "123456", ChannelType.EMAIL_ID);
    when(userProfileRepository.findByEmailIgnoreCase(anyString())).thenReturn(Optional.empty());

    assertThrows(BusinessRuleException.class, () -> authController.auth(otpVerifyRequest));
  }

  @Test
  void givenAuthenticationManagerThrowsException_whenAuth_thenThrowBusinessRuleException() {
    OtpVerifyRequest otpVerifyRequest =
        new OtpVerifyRequest("error@example.com", "123456", ChannelType.EMAIL_ID);
    when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
        .thenThrow(RuntimeException.class);

    assertThrows(BusinessRuleException.class, () -> authController.auth(otpVerifyRequest));
  }

  @Test
  void shouldUpdateToken_whenAuthenticatingExistingUser() {
    Token existingToken = new Token();
    existingToken.setValue("oldToken");
    OtpVerifyRequest otpVerifyRequest =
        new OtpVerifyRequest("error@example.com", "123456", ChannelType.EMAIL_ID);
    ReflectionTestUtils.setField(authController, "deviceLoginLimit", 2L);
    // Set up to simulate an existing user authentication
    when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
        .thenReturn(new UsernamePasswordAuthenticationToken(createDummyUser(), null));
    when(tokenService.findByUserProfile(any(UserProfile.class))).thenReturn(List.of(existingToken));
    when(jwtUtil.getToken(anyString(), anyList())).thenReturn("updatedToken");

    authController.auth(otpVerifyRequest);

    // Assertions to ensure the token is updated
    verify(tokenService).save(existingTokenCaptor.capture());
    Token updatedToken = existingTokenCaptor.getValue();
    Assertions.assertEquals(RisocareCommonUtils.hashString("updatedToken"), updatedToken.getValue());
  }

  @Test
  void shouldCreateNewToken_whenAuthenticatingNewUser() {
    OtpVerifyRequest otpVerifyRequest =
        new OtpVerifyRequest("error@example.com", "123456", ChannelType.EMAIL_ID);
    // Set up to simulate a new user authentication
    ReflectionTestUtils.setField(authController, "deviceLoginLimit", 2L);
    when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
        .thenReturn(new UsernamePasswordAuthenticationToken(createDummyUser(), null));
    when(tokenService.findByUserProfile(any(UserProfile.class))).thenReturn(List.of());
    when(jwtUtil.getToken(anyString(), anyList())).thenReturn("newToken");

    authController.auth(otpVerifyRequest);

    // Assertions to ensure a new token is created
    verify(tokenService).save(newTokenCaptor.capture());
    Token newToken = newTokenCaptor.getValue();
    assertEquals(RisocareCommonUtils.hashString("newToken"), newToken.getValue());
  }

  @Test
  void shouldThrowBusinessRuleException_whenBadCredentialsProvided() {
    OtpVerifyRequest otpVerifyRequest =
        new OtpVerifyRequest("error@example.com", "123456", ChannelType.EMAIL_ID);

    when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
        .thenThrow(new BadCredentialsException("Bad credentials"));

    BusinessRuleException thrownException =
        assertThrows(BusinessRuleException.class, () -> authController.auth(otpVerifyRequest));

    assertEquals(HttpStatus.UNAUTHORIZED, thrownException.getHttpStatus());
    Assertions.assertEquals(ErrorMsgConstants.UNAUTHORIZED_USER_MSG, thrownException.getErrorMessage());
  }

  @Test
  void shouldThrowBusinessRuleException_whenUserNotFound() {
    OtpVerifyRequest otpVerifyRequest =
        new OtpVerifyRequest("error@example.com", "123456", ChannelType.EMAIL_ID);

    when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
        .thenThrow(new UsernameNotFoundException("User not found"));

    BusinessRuleException thrownException =
        assertThrows(BusinessRuleException.class, () -> authController.auth(otpVerifyRequest));

    assertEquals(HttpStatus.UNAUTHORIZED, thrownException.getHttpStatus());
    Assertions.assertEquals(ErrorMsgConstants.UNAUTHORIZED_USER_MSG, thrownException.getErrorMessage());
  }

  @Test
  void shouldThrowBusinessRuleException_whenUserExceedsLoginLimit() {

    ReflectionTestUtils.setField(authController, "deviceLoginLimit", 2L);
    OtpVerifyRequest otpVerifyRequest =
        new OtpVerifyRequest("error@example.com", "123456", ChannelType.EMAIL_ID);
    when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
        .thenReturn(new UsernamePasswordAuthenticationToken(createDummyUser(), null));
    when(tokenService.findByUserProfile(any(UserProfile.class)))
        .thenReturn(List.of(new Token(), new Token()));
    when(jwtUtil.getToken(anyString(), anyList())).thenReturn("newToken");

    ResponseEntity<String> response = authController.auth(otpVerifyRequest);
    assertEquals(HttpStatus.TOO_MANY_REQUESTS, response.getStatusCode());
    Assertions.assertEquals(
        ErrorMsgConstants.MAX_DEVICE_LOGIN_LIMIT_REACHED,
        new Gson().fromJson(response.getBody(), Map.class).get("message"));
  }
}
