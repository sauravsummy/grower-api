package com.sunsum.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import com.sunsum.constants.ErrorMsgConstants;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.FieldRequest;
import com.sunsum.model.dto.FieldResponse;
import com.sunsum.model.dto.FieldUpdateRequest;
import com.sunsum.model.dto.TaskStatusResponse;
import com.sunsum.service.FieldService;
import com.sunsum.service.TaskService;
import java.io.IOException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@ExtendWith(MockitoExtension.class)
class FieldControllerTest {

  @Mock private FieldService fieldService;

  @Mock private TaskService taskService;

  @InjectMocks private FieldController fieldController;

  @BeforeEach
  void setUp() {
    // Mock setup if required
  }

  @Test
  void givenUserHasPermission_whenGetField_thenReturnFieldResponse() {
    String id = "1";
    FieldResponse expectedResponse = new FieldResponse(); // Populate with test data
    when(fieldService.hasUserPermissionForField(Long.parseLong(id))).thenReturn(true);
    when(fieldService.getField(id)).thenReturn(ResponseEntity.ok(expectedResponse));

    ResponseEntity<FieldResponse> response = fieldController.getField(id);

    assertEquals(ResponseEntity.ok(expectedResponse), response);
  }

  @Test
  void givenUserHasNoPermission_whenGetField_thenThrowException() {
    String id = "1";
    when(fieldService.hasUserPermissionForField(Long.parseLong(id))).thenReturn(false);

    BusinessRuleException exception =
        assertThrows(BusinessRuleException.class, () -> fieldController.getField(id));
    Assertions.assertEquals(ErrorMsgConstants.UNAUTHORIZED_USER_FOR_FIELD, exception.getMessage());
    assertEquals(HttpStatus.FORBIDDEN, exception.getHttpStatus());
  }

  @Test
  void whenCreateField_thenReturnSuccessResponse() throws IOException {
    FieldRequest fieldRequest = new FieldRequest(); // Populate with test data
    String expectedResponse = "Field created successfully";
    when(fieldService.createField(fieldRequest)).thenReturn(ResponseEntity.ok(expectedResponse));

    ResponseEntity<String> response = fieldController.create(fieldRequest);

    assertEquals(ResponseEntity.ok(expectedResponse), response);
  }

  @Test
  void givenUserHasPermission_whenUpdate_thenReturnSuccessResponse() {
    String id = "1";
    FieldUpdateRequest fieldRequest = new FieldUpdateRequest(); // Populate with test data
    String expectedResponse = "Field updated successfully";
    when(fieldService.hasUserPermissionForField(Long.parseLong(id))).thenReturn(true);
    when(fieldService.updateField(fieldRequest, id))
        .thenReturn(ResponseEntity.ok(expectedResponse));

    ResponseEntity<String> response = fieldController.update(fieldRequest, id);

    assertEquals(ResponseEntity.ok(expectedResponse), response);
  }

  @Test
  void givenUserHasNoPermission_whenUpdate_thenThrowException() {
    String id = "1";
    FieldUpdateRequest fieldRequest = new FieldUpdateRequest(); // Populate with test data
    when(fieldService.hasUserPermissionForField(Long.parseLong(id))).thenReturn(false);

    BusinessRuleException exception =
        assertThrows(BusinessRuleException.class, () -> fieldController.update(fieldRequest, id));
    Assertions.assertEquals(ErrorMsgConstants.UNAUTHORIZED_USER_FOR_FIELD, exception.getMessage());
    assertEquals(HttpStatus.FORBIDDEN, exception.getHttpStatus());
  }

  @Test
  void givenUserHasPermission_whenGetAllTasks_thenReturnTaskStatusResponse() {
    String fieldId = "1";
    TaskStatusResponse expectedResponse = new TaskStatusResponse(); // Populate with test data
    when(fieldService.hasUserPermissionForField(Long.parseLong(fieldId))).thenReturn(true);
    when(taskService.getAllTasks(fieldId)).thenReturn(expectedResponse);

    ResponseEntity<TaskStatusResponse> response = fieldController.getAllTasks(fieldId);

    assertEquals(ResponseEntity.ok(expectedResponse), response);
  }

  @Test
  void givenUserHasNoPermission_whenGetAllTasks_thenThrowException() {
    String fieldId = "1";
    when(fieldService.hasUserPermissionForField(Long.parseLong(fieldId))).thenReturn(false);

    BusinessRuleException exception =
        assertThrows(BusinessRuleException.class, () -> fieldController.getAllTasks(fieldId));
    Assertions.assertEquals(ErrorMsgConstants.UNAUTHORIZED_USER_FOR_FIELD, exception.getMessage());
    assertEquals(HttpStatus.FORBIDDEN, exception.getHttpStatus());
  }

  @Test
  void givenUserHasPermission_whenGetUpComingTasks_thenReturnTaskStatusResponse() {
    String fieldId = "1";
    TaskStatusResponse expectedResponse = new TaskStatusResponse(); // Populate with test data
    when(fieldService.hasUserPermissionForField(Long.parseLong(fieldId))).thenReturn(true);
    when(taskService.getUpcomingTasks(fieldId)).thenReturn(expectedResponse);

    ResponseEntity<TaskStatusResponse> response = fieldController.getUpComingTasks(fieldId);

    assertEquals(ResponseEntity.ok(expectedResponse), response);
  }

  @Test
  void givenUserHasNoPermission_whenGetUpComingTasks_thenThrowException() {
    String fieldId = "1";
    when(fieldService.hasUserPermissionForField(Long.parseLong(fieldId))).thenReturn(false);

    BusinessRuleException exception =
        assertThrows(BusinessRuleException.class, () -> fieldController.getUpComingTasks(fieldId));
    Assertions.assertEquals(ErrorMsgConstants.UNAUTHORIZED_USER_FOR_FIELD, exception.getMessage());
    assertEquals(HttpStatus.FORBIDDEN, exception.getHttpStatus());
  }
}
