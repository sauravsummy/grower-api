package com.sunsum.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.sunsum.model.entity.BaseEntity;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;

class BaseEntityTest {

  @Test
  void testBaseEntity() {
    Long createdBy = 1L;
    LocalDateTime createdDate = LocalDateTime.now();
    Long lastUpdatedBy = 2L;
    LocalDateTime lastUpdatedDate = LocalDateTime.now().plusDays(1);

    BaseEntity baseEntity = new BaseEntity();
    baseEntity.setCreatedBy(createdBy);
    baseEntity.setCreatedDate(createdDate);
    baseEntity.setLastUpdatedBy(lastUpdatedBy);
    baseEntity.setLastUpdatedDate(lastUpdatedDate);

    // Asserts for getters
    assertEquals(createdBy, baseEntity.getCreatedBy());
    assertEquals(createdDate, baseEntity.getCreatedDate());
    assertEquals(lastUpdatedBy, baseEntity.getLastUpdatedBy());
    assertEquals(lastUpdatedDate, baseEntity.getLastUpdatedDate());
  }
}
