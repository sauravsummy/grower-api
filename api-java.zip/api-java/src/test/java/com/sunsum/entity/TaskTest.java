package com.sunsum.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.sunsum.constants.TaskRelation;
import com.sunsum.constants.TaskType;
import com.sunsum.model.entity.CustomDefinition;
import com.sunsum.model.entity.Task;
import com.sunsum.model.entity.TaskGroup;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Test;

class TaskTest {

  @Test
  void testTaskEntity() {
    Task task = new Task();

    Long id = 1L;
    String title = "Sample Task";
    TaskType type = TaskType.ACTION;
    String brief = "Sample Brief";
    List<CustomDefinition> customDefinition =
        Collections.singletonList(
            new CustomDefinition()); // Assuming CustomDefinition is a valid class
    TaskGroup taskGroup = new TaskGroup(); // Assuming TaskGroup is a valid class
    Boolean isLocked = true;
    Integer order = 1;
    TaskRelation relation = TaskRelation.FOLLOW;
    Integer relatedDays = 5;
    LocalDate fixedDueDate = LocalDate.now();
    Task relatedTask = new Task(); // Self-reference for simplicity
    String memo1 = "Memo1";
    String memo2 = "Memo2";
    String memo3 = "Memo3";
    String memo4 = "Memo4";
    String memo5 = "Memo5";

    task.setId(id);
    task.setTitle(title);
    task.setType(type);
    task.setBrief(brief);
    task.setCustomDefinition(customDefinition);
    task.setTaskGroup(taskGroup);
    task.setIsLocked(isLocked);
    task.setOrder(order);
    task.setRelation(relation);
    task.setRelatedDays(relatedDays);
    task.setFixedDueDate(fixedDueDate);
    task.setRelatedTask(relatedTask);
    task.setMemo1(memo1);
    task.setMemo2(memo2);
    task.setMemo3(memo3);
    task.setMemo4(memo4);
    task.setMemo5(memo5);

    assertEquals(id, task.getId());
    assertEquals(title, task.getTitle());
    assertEquals(type, task.getType());
    assertEquals(brief, task.getBrief());
    assertEquals(customDefinition, task.getCustomDefinition());
    assertEquals(taskGroup, task.getTaskGroup());
    assertEquals(isLocked, task.getIsLocked());
    assertEquals(order, task.getOrder());
    assertEquals(relation, task.getRelation());
    assertEquals(relatedDays, task.getRelatedDays());
    assertEquals(fixedDueDate, task.getFixedDueDate());
    assertEquals(relatedTask, task.getRelatedTask());
    assertEquals(memo1, task.getMemo1());
    assertEquals(memo2, task.getMemo2());
    assertEquals(memo3, task.getMemo3());
    assertEquals(memo4, task.getMemo4());
    assertEquals(memo5, task.getMemo5());
  }
}
