package com.sunsum.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.sunsum.model.entity.Organization;
import com.sunsum.model.entity.Project;
import com.sunsum.model.entity.Role;
import com.sunsum.model.entity.TaskField;
import com.sunsum.model.entity.TaskGroup;
import com.sunsum.model.entity.Token;
import com.sunsum.model.entity.UserProfile;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Test;

class UserProfileTest {

  @Test
  void testUserProfileEntity() {
    UserProfile userProfile = new UserProfile();

    Long id = 1L;
    String name = "John Doe";
    String email = "john.doe@example.com";
    Long phoneNo = 1234567890L;
    UserProfile reportingTo = new UserProfile(); // For simplicity, using a new UserProfile
    Boolean isActive = true;
    String password = "password123";
    String memo1 = "Memo1";
    String memo2 = "Memo2";
    String memo3 = "Memo3";
    String memo4 = "Memo4";
    String memo5 = "Memo5";

    Set<Project> projects = new HashSet<>();
    Set<Role> roles = new HashSet<>();
    Set<TaskGroup> taskGroups = new HashSet<>();
    Set<TaskField> taskFields = new HashSet<>();
    Organization organization = new Organization(); // Assuming Organization is a valid class
    List<Token> tokens = List.of(new Token()); // Assuming Token is a valid class

    userProfile.setId(id);
    userProfile.setName(name);
    userProfile.setEmail(email);
    userProfile.setPhoneNo(phoneNo);
    userProfile.setReportingTo(reportingTo);
    userProfile.setIsActive(isActive);
    userProfile.setPassword(password);
    userProfile.setProjects(projects);
    userProfile.setRoles(roles);
    userProfile.setTaskGroups(taskGroups);
    userProfile.setTaskFields(taskFields);
    userProfile.setOrganization(organization);
    userProfile.setTokens(tokens);
    userProfile.setMemo1(memo1);
    userProfile.setMemo2(memo2);
    userProfile.setMemo3(memo3);
    userProfile.setMemo4(memo4);
    userProfile.setMemo5(memo5);

    assertEquals(id, userProfile.getId());
    assertEquals(name, userProfile.getName());
    assertEquals(email, userProfile.getEmail());
    assertEquals(phoneNo, userProfile.getPhoneNo());
    assertEquals(reportingTo, userProfile.getReportingTo());
    assertEquals(isActive, userProfile.getIsActive());
    assertEquals(password, userProfile.getPassword());
    assertEquals(projects, userProfile.getProjects());
    assertEquals(roles, userProfile.getRoles());
    assertEquals(taskGroups, userProfile.getTaskGroups());
    assertEquals(taskFields, userProfile.getTaskFields());
    assertEquals(organization, userProfile.getOrganization());
    assertEquals(tokens, userProfile.getTokens());
    assertEquals(memo1, userProfile.getMemo1());
    assertEquals(memo2, userProfile.getMemo2());
    assertEquals(memo3, userProfile.getMemo3());
    assertEquals(memo4, userProfile.getMemo4());
    assertEquals(memo5, userProfile.getMemo5());

    // Test equals and hashCode
    UserProfile anotherUser = new UserProfile();
    anotherUser.setId(id);
    anotherUser.setName(name);
    anotherUser.setEmail(email);
    anotherUser.setPhoneNo(phoneNo);

    assertEquals(userProfile, anotherUser);
    assertEquals(userProfile.hashCode(), anotherUser.hashCode());
  }

  @Test
  void testSettersAndGetters() {
    UserProfile userProfile = new UserProfile();
    userProfile.setReportingTo(new UserProfile());
    userProfile.setProjects(new HashSet<>());
    userProfile.setPassword("password123");
    userProfile.setTaskGroups(new HashSet<>());
    userProfile.setTaskFields(new HashSet<>());
    userProfile.setTokens(List.of());

    assertNotNull(userProfile.getReportingTo());
    assertNotNull(userProfile.getProjects());
    assertEquals("password123", userProfile.getPassword());
    assertNotNull(userProfile.getTaskGroups());
    assertNotNull(userProfile.getTaskFields());
    assertNotNull(userProfile.getTokens());
  }
}
