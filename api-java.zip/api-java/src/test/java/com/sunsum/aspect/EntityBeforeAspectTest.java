package com.sunsum.aspect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.sunsum.model.entity.BaseEntity;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

@ExtendWith(MockitoExtension.class)
class EntityBeforeAspectTest {

  @Mock private Authentication authentication;

  @InjectMocks private EntityBeforeAspect entityBeforeAspect;

  @Mock private Logger log;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
    SecurityContextHolder.getContext().setAuthentication(authentication);
  }

  @Test
  void givenUserPrincipal_whenBeforeSaveEntity_thenBaseEntityUpdated() throws Exception {
    // given
    when(authentication.getPrincipal()).thenReturn(1L);

    BaseEntity entity = BaseEntity.builder().build();

    JoinPoint joinPoint = mock(JoinPoint.class);
    Signature signature = mock(MethodSignature.class);

    when(joinPoint.getArgs()).thenReturn(new Object[] {entity});

    // when
    Method privateMethod =
        EntityBeforeAspect.class.getDeclaredMethod("beforeSaveEntity", JoinPoint.class);
    privateMethod.setAccessible(true);
    privateMethod.invoke(entityBeforeAspect, joinPoint);

    // then
    assertNotNull(entity.getCreatedBy());
    assertNotNull(entity.getCreatedDate());
    assertNotNull(entity.getLastUpdatedBy());
    assertNotNull(entity.getLastUpdatedDate());
    assertEquals(1L, entity.getCreatedBy());
    assertEquals(1L, entity.getLastUpdatedBy());
  }

  @Test
  void givenUserPrincipalAndIterableEntities_whenBeforeSaveEntity_thenBaseEntitiesUpdated()
      throws Exception {
    // given
    when(authentication.getPrincipal()).thenReturn(1L);

    BaseEntity entity1 = BaseEntity.builder().build();
    BaseEntity entity2 = BaseEntity.builder().build();
    List<BaseEntity> entities = Arrays.asList(entity1, entity2);

    JoinPoint joinPoint = mock(JoinPoint.class);
    Signature signature = mock(MethodSignature.class);

    when(joinPoint.getArgs()).thenReturn(new Object[] {entities});

    // when
    Method privateMethod =
        EntityBeforeAspect.class.getDeclaredMethod("beforeSaveAllEntity", JoinPoint.class);
    privateMethod.setAccessible(true);
    privateMethod.invoke(entityBeforeAspect, joinPoint);

    // then
    for (BaseEntity entity : entities) {
      assertNotNull(entity.getCreatedBy());
      assertNotNull(entity.getCreatedDate());
      assertNotNull(entity.getLastUpdatedBy());
      assertNotNull(entity.getLastUpdatedDate());

      assertEquals(1L, entity.getCreatedBy());
      assertEquals(1L, entity.getLastUpdatedBy());
    }
  }

  @Test
  void givenExceptionThrown_whenBeforeSaveEntity_thenLogError() throws Exception {

    JoinPoint joinPoint = mock(JoinPoint.class);
    when(joinPoint.getArgs()).thenThrow(new RuntimeException("Test Exception"));

    // when
    Method privateMethod =
        EntityBeforeAspect.class.getDeclaredMethod("beforeSaveEntity", JoinPoint.class);
    privateMethod.setAccessible(true);
    privateMethod.invoke(entityBeforeAspect, joinPoint);
    Object result = privateMethod.invoke(entityBeforeAspect, joinPoint);

    // then
    assertNull(result);
  }

  @Mock private JoinPoint joinPoint;

  @Test
  void testBeforeSaveEntityExceptionHandling() throws Throwable {
    // given
    given(joinPoint.getArgs()).willReturn(new Object[] {new BaseEntity()});
    Method method = getPrivateMethod("beforeSaveEntity", JoinPoint.class);

    // when
    Object result = method.invoke(entityBeforeAspect, joinPoint);

    // then
    assertNull(result);
  }

  @Test
  void testBeforeSaveAllEntityExceptionHandling() throws Throwable {
    // given
    given(joinPoint.getArgs()).willReturn(new Object[] {mock(Iterable.class)});
    Method method = getPrivateMethod("beforeSaveAllEntity", JoinPoint.class);

    // when
    Object result = method.invoke(entityBeforeAspect, joinPoint);

    // then
    assertNull(result);
  }

  private Method getPrivateMethod(String methodName, Class<?>... parameterTypes)
      throws NoSuchMethodException {
    Method method = EntityBeforeAspect.class.getDeclaredMethod(methodName, parameterTypes);
    method.setAccessible(true);
    return method;
  }

  @Test
  void testSelectSaveEntityPointcut()
      throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
    // given
    Signature signature = mock(Signature.class);

    // when
    invokePrivateMethod(entityBeforeAspect, "selectSaveEntity");

    // then
    assertNotNull(entityBeforeAspect);
  }

  @Test
  void testSelectSaveAllEntityPointcut()
      throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
    // given
    Signature signature = mock(Signature.class);

    // when
    invokePrivateMethod(entityBeforeAspect, "selectSaveAllEntity");

    // then
    assertNotNull(entityBeforeAspect);
  }

  private void invokePrivateMethod(Object targetObject, String methodName)
      throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {

    Method method = targetObject.getClass().getDeclaredMethod(methodName);
    method.setAccessible(true);
    method.invoke(targetObject);
  }
}
