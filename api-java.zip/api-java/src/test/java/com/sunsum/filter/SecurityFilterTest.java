package com.sunsum.filter;

import static org.mockito.Mockito.*;

import com.sunsum.model.entity.Token;
import com.sunsum.service.TokenService;
import com.sunsum.util.JwtUtil;
import com.sunsum.util.RisocareCommonUtils;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import java.io.IOException;
import java.util.Collections;
import java.util.Optional;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;

@ExtendWith(MockitoExtension.class)
class SecurityFilterTest {

  @Mock private JwtUtil jwtUtil;

  @Mock private TokenService tokenService;

  @Mock private UserDetailsService userDetailsService;

  @InjectMocks private SecurityFilter securityFilter;

  @Mock private HttpServletRequest request;

  @Mock private HttpServletResponse response;

  @Mock private FilterChain filterChain;

  private String token;
  private String userId;

  @BeforeEach
  void setUp() {
    userId = "user1";
    token = "token";
  }

  @Test
  void givenValidToken_whenDoFilterInternal_thenProcessFilterChain() throws Exception {
    when(request.getHeader("Authorization")).thenReturn("Bearer " + token);
    when(jwtUtil.extractUserId(token)).thenReturn(userId);
    when(tokenService.findByToken(RisocareCommonUtils.hashString(token)))
        .thenReturn(Optional.of(new Token()));

    UserDetails userDetails = new User(userId, "", Collections.emptyList());
    when(userDetailsService.loadUserByUsername(userId)).thenReturn(userDetails);
    when(jwtUtil.isValid(token, userDetails)).thenReturn(true);

    securityFilter.doFilterInternal(request, response, filterChain);

    verify(filterChain).doFilter(request, response);
  }

  @Test
  void givenInvalidToken_whenDoFilterInternal_thenExpectForbiddenResponse()
      throws ServletException, IOException {
    // Arrange
    when(request.getHeader("Authorization")).thenReturn("Bearer invalid_token");
    when(request.getRequestURI()).thenReturn("/api/v1/test");

    // Act
    securityFilter.doFilterInternal(request, response, filterChain);

    // Assert
    verify(response).setStatus(HttpServletResponse.SC_UNAUTHORIZED);
    // Or, if you're sending an error:
    // verify(response).sendError(HttpServletResponse.SC_FORBIDDEN, "Expected error message");
  }

  @Test
  void givenNoAuthorizationHeader_whenDoFilterInternal_thenDoNothing()
      throws ServletException, IOException {
    // Arrange
    when(request.getHeader("Authorization")).thenReturn(null);

    // Act
    securityFilter.doFilterInternal(request, response, filterChain);

    // Assert
    verify(filterChain).doFilter(request, response);
    verify(response, never()).setStatus(anyInt());
  }

  @Test
  void givenExpiredToken_whenDoFilterInternal_thenExpectForbiddenResponse()
      throws ServletException, IOException {
    // Arrange
    when(request.getHeader("Authorization")).thenReturn("Bearer expired_token");
    when(jwtUtil.extractUserId("expired_token"))
        .thenThrow(new ExpiredJwtException(null, null, "Token expired"));

    // Act
    securityFilter.doFilterInternal(request, response, filterChain);

    // Assert
    verify(response).setStatus(HttpServletResponse.SC_FORBIDDEN);
  }

  @Test
  void givenMalformedToken_whenDoFilterInternal_thenExpectForbiddenResponse()
      throws ServletException, IOException {
    // Arrange
    when(request.getHeader("Authorization")).thenReturn("Bearer malformed_token");
    when(jwtUtil.extractUserId("malformed_token"))
        .thenThrow(new MalformedJwtException("Malformed token"));

    // Act
    securityFilter.doFilterInternal(request, response, filterChain);

    // Assert
    verify(response).setStatus(HttpServletResponse.SC_FORBIDDEN);
  }

  @Test
  void givenTokenWithInvalidSignature_whenDoFilterInternal_thenExpectForbiddenResponse()
      throws ServletException, IOException {
    // Arrange
    when(request.getHeader("Authorization")).thenReturn("Bearer token_with_invalid_signature");
    when(jwtUtil.extractUserId("token_with_invalid_signature"))
        .thenThrow(new SignatureException("Invalid signature"));

    // Act
    securityFilter.doFilterInternal(request, response, filterChain);

    // Assert
    verify(response).setStatus(HttpServletResponse.SC_FORBIDDEN);
  }
}
