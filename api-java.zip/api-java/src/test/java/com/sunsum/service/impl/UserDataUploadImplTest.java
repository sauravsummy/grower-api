package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

import com.sunsum.constants.AppConstants;
import com.sunsum.exception.BulkUploadException;
import com.sunsum.model.dto.RowIngestionResult;
import com.sunsum.model.entity.IngestionStatus;
import com.sunsum.model.entity.Organization;
import com.sunsum.model.entity.Role;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.OrganisationRepository;
import com.sunsum.repository.RoleRepository;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.service.DataUpload;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class UserDataUploadImplTest {

  private static final String ID = "Id";
  private static final String NAME = "Name";
  private static final String IS_ACTIVE = "Is Active";
  private static final String ROLE = "Role";
  private static final String EMAIL_ID = "Email Id";
  private static final String PHONE = "Phone";
  private static final String REPORTING_TO = "Reporting To";
  private static final String ORGANISATION_ID = "Organisation Id";
  private static final String MEMO_1 = "Memo_1";
  private static final String MEMO_2 = "Memo_2";
  private static final String MEMO_3 = "Memo_3";
  private static final String MEMO_4 = "Memo_4";
  private static final String MEMO_5 = "Memo_5";

  @Mock private UserProfileRepository userProfileRepository;

  @Mock private OrganisationRepository organisationRepository;

  @Mock private RoleRepository roleRepository;

  @Mock private UserProfile userProfile;

  @InjectMocks private UserDataUploadImpl userDataUpload;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void givenRowAndColumnNameToIndexMap_whenCreateFromRow_thenDataUploadIsCreatedSuccessfully() {
    // given
    Row row = mock(Row.class);
    Map<String, Integer> columnNameToIndex = createColumnNameToIndexMap();

    Cell idCell = mock(Cell.class);
    given(idCell.getNumericCellValue()).willReturn(1.0);
    given(idCell.getCellType()).willReturn(CellType.NUMERIC);

    given(row.getCell(columnNameToIndex.get(AppConstants.ID))).willReturn(idCell);

    Cell nameCell = mock(Cell.class);
    given(nameCell.getStringCellValue()).willReturn("name1");
    given(row.getCell(columnNameToIndex.get(NAME))).willReturn(nameCell);

    Cell isActiveCell = mock(Cell.class);
    given(isActiveCell.getBooleanCellValue()).willReturn(true);
    given(isActiveCell.getCellType()).willReturn(CellType.BOOLEAN);

    given(row.getCell(columnNameToIndex.get(AppConstants.IS_ACTIVE))).willReturn(isActiveCell);

    Cell roleCell = mock(Cell.class);
    given(roleCell.getStringCellValue()).willReturn("ROLE_USER");
    given(row.getCell(columnNameToIndex.get(ROLE))).willReturn(roleCell);

    Cell emailCell = mock(Cell.class);
    given(emailCell.getStringCellValue()).willReturn("name1@gmail.com");
    given(row.getCell(columnNameToIndex.get(EMAIL_ID))).willReturn(emailCell);

    Cell phoneCell = mock(Cell.class);
    given(phoneCell.getNumericCellValue()).willReturn(1234567890.0);
    given(phoneCell.getCellType()).willReturn(CellType.NUMERIC);
    given(row.getCell(columnNameToIndex.get(PHONE))).willReturn(phoneCell);

    Cell reportingToCell = mock(Cell.class);
    given(reportingToCell.getStringCellValue()).willReturn("reportingmail@gmail.com");
    given(row.getCell(columnNameToIndex.get(REPORTING_TO))).willReturn(reportingToCell);

    Cell orgIdCell = mock(Cell.class);
    given(orgIdCell.getNumericCellValue()).willReturn(2.0);
    given(orgIdCell.getCellType()).willReturn(CellType.NUMERIC);
    given(row.getCell(columnNameToIndex.get(AppConstants.ORGANISATION_ID))).willReturn(orgIdCell);

    given(userProfileRepository.findById(anyLong())).willReturn(Optional.of(new UserProfile()));
    given(userProfileRepository.findByEmail("reportingmail@gmail.com"))
        .willReturn(Optional.of(new UserProfile()));
    given(organisationRepository.findById(anyLong())).willReturn(Optional.of(new Organization()));
    given(roleRepository.findByName(any())).willReturn(Optional.of(new Role()));

    // when
    DataUpload result = userDataUpload.createFromRow(row, columnNameToIndex);

    // then
    assertNotNull(result);
    assertNotNull(userDataUpload.getUserProfileRepository());
    assertNotNull(userDataUpload.getOrganisationRepository());
    assertNotNull(userDataUpload.getRoleRepository());
    assertNotNull(userDataUpload.getUserProfile());
  }

  @Test
  void givenUserProfileExists_whenDataInjection_thenUserProfileIsSaved() {
    // given
    UserProfile userProfile = new UserProfile();
    userDataUpload.setUserProfile(userProfile);
    given(userProfileRepository.save(userProfile)).willReturn(userProfile);

    // when
    RowIngestionResult result = userDataUpload.dataInjection(1);

    // then
    Assertions.assertEquals(IngestionStatus.INSERTED, result.getStatus());
    verify(userProfileRepository, times(1)).save(userProfile);
  }

  @Test
  void givenRowWithoutIdColumn_whenCreateFromRow_thenDataUploadIsCreatedSuccessfully() {
    // given
    Row row = mock(Row.class);
    Map<String, Integer> columnNameToIndex = createColumnNameToIndexMap();

    given(row.getCell(columnNameToIndex.get(AppConstants.ID))).willReturn(null);

    Cell nameCell = mock(Cell.class);
    given(nameCell.getStringCellValue()).willReturn("name1");
    given(row.getCell(columnNameToIndex.get(NAME))).willReturn(nameCell);

    Cell isActiveCell = mock(Cell.class);
    given(isActiveCell.getBooleanCellValue()).willReturn(true);
    given(isActiveCell.getCellType()).willReturn(CellType.BOOLEAN);

    given(row.getCell(columnNameToIndex.get(AppConstants.IS_ACTIVE))).willReturn(isActiveCell);

    Cell roleCell = mock(Cell.class);
    given(roleCell.getStringCellValue()).willReturn("ROLE_USER");
    given(row.getCell(columnNameToIndex.get(ROLE))).willReturn(roleCell);

    Cell emailCell = mock(Cell.class);
    given(emailCell.getStringCellValue()).willReturn("name1@gmail.com");
    given(row.getCell(columnNameToIndex.get(EMAIL_ID))).willReturn(emailCell);

    Cell phoneCell = mock(Cell.class);
    given(phoneCell.getNumericCellValue()).willReturn(1234567890.0);
    given(phoneCell.getCellType()).willReturn(CellType.NUMERIC);
    given(row.getCell(columnNameToIndex.get(PHONE))).willReturn(phoneCell);

    Cell reportingToCell = mock(Cell.class);
    given(reportingToCell.getStringCellValue()).willReturn("reportingmail@gmail.com");
    given(row.getCell(columnNameToIndex.get(REPORTING_TO))).willReturn(reportingToCell);

    Cell orgIdCell = mock(Cell.class);
    given(orgIdCell.getNumericCellValue()).willReturn(2.0);
    given(orgIdCell.getCellType()).willReturn(CellType.NUMERIC);
    given(row.getCell(columnNameToIndex.get(AppConstants.ORGANISATION_ID))).willReturn(orgIdCell);

    given(userProfileRepository.findById(anyLong())).willReturn(Optional.of(new UserProfile()));
    given(userProfileRepository.findByEmail("reportingmail@gmail.com"))
        .willReturn(Optional.of(new UserProfile()));
    given(organisationRepository.findById(anyLong())).willReturn(Optional.of(new Organization()));
    given(roleRepository.findByName(any())).willReturn(Optional.of(new Role()));

    // when
    DataUpload result = userDataUpload.createFromRow(row, columnNameToIndex);

    // then
    assertNotNull(result);
    assertNotNull(userDataUpload.getUserProfileRepository());
    assertNotNull(userDataUpload.getOrganisationRepository());
    assertNotNull(userDataUpload.getRoleRepository());
  }

  private Map<String, Integer> createColumnNameToIndexMap() {
    Map<String, Integer> columnNameToIndex = new HashMap<>();
    columnNameToIndex.put(ID, 0);
    columnNameToIndex.put(NAME, 1);
    columnNameToIndex.put(IS_ACTIVE, 2);
    columnNameToIndex.put(ROLE, 3);
    columnNameToIndex.put(EMAIL_ID, 4);
    columnNameToIndex.put(PHONE, 5);
    columnNameToIndex.put(REPORTING_TO, 6);
    columnNameToIndex.put(ORGANISATION_ID, 7);
    columnNameToIndex.put(MEMO_1, 8);
    columnNameToIndex.put(MEMO_2, 9);
    columnNameToIndex.put(MEMO_3, 10);
    columnNameToIndex.put(MEMO_4, 11);
    columnNameToIndex.put(MEMO_5, 12);

    return columnNameToIndex;
  }

  @Test
  @SuppressWarnings("unchecked")
  void givenExceptionThrown_whenDataInjection_thenExceptionIsHandled() {
    // given
    UserProfile userProfile = new UserProfile();
    userDataUpload.setUserProfile(userProfile);
    given(userProfileRepository.save(userProfile))
        .willThrow(new BulkUploadException("Test exception"));

    // when
    assertThrows(BulkUploadException.class, () -> userDataUpload.dataInjection(1));
  }

  @Test
  void givenRowWithNullReportingTo_whenCreateFromRow_thenDataUploadIsCreatedSuccessfully() {
    // given
    Row row = mock(Row.class);
    Map<String, Integer> columnNameToIndex = createColumnNameToIndexMap();

    Cell idCell = mock(Cell.class);
    given(idCell.getNumericCellValue()).willReturn(1.0);
    given(idCell.getCellType()).willReturn(CellType.NUMERIC);

    given(row.getCell(columnNameToIndex.get(AppConstants.ID))).willReturn(idCell);

    Cell nameCell = mock(Cell.class);
    given(nameCell.getStringCellValue()).willReturn("name1");
    given(row.getCell(columnNameToIndex.get(NAME))).willReturn(nameCell);

    Cell isActiveCell = mock(Cell.class);
    given(isActiveCell.getBooleanCellValue()).willReturn(true);
    given(isActiveCell.getCellType()).willReturn(CellType.BOOLEAN);

    given(row.getCell(columnNameToIndex.get(AppConstants.IS_ACTIVE))).willReturn(isActiveCell);

    Cell roleCell = mock(Cell.class);
    given(roleCell.getStringCellValue()).willReturn("ROLE_USER");
    given(row.getCell(columnNameToIndex.get(ROLE))).willReturn(roleCell);

    Cell emailCell = mock(Cell.class);
    given(emailCell.getStringCellValue()).willReturn("name1@gmail.com");
    given(row.getCell(columnNameToIndex.get(EMAIL_ID))).willReturn(emailCell);

    Cell phoneCell = mock(Cell.class);
    given(phoneCell.getNumericCellValue()).willReturn(1234567890.0);
    given(phoneCell.getCellType()).willReturn(CellType.NUMERIC);
    given(row.getCell(columnNameToIndex.get(PHONE))).willReturn(phoneCell);

    // reportingTo cell with null value
    given(row.getCell(columnNameToIndex.get(REPORTING_TO))).willReturn(null);

    Cell orgIdCell = mock(Cell.class);
    given(orgIdCell.getNumericCellValue()).willReturn(2.0);
    given(orgIdCell.getCellType()).willReturn(CellType.NUMERIC);
    given(row.getCell(columnNameToIndex.get(AppConstants.ORGANISATION_ID))).willReturn(orgIdCell);

    given(userProfileRepository.findById(anyLong())).willReturn(Optional.of(new UserProfile()));
    given(organisationRepository.findById(anyLong())).willReturn(Optional.of(new Organization()));
    given(roleRepository.findByName(any())).willReturn(Optional.of(new Role()));

    // when
    DataUpload result = userDataUpload.createFromRow(row, columnNameToIndex);

    // then
    assertNotNull(result);
    assertNotNull(userDataUpload.getUserProfileRepository());
    assertNotNull(userDataUpload.getOrganisationRepository());
    assertNotNull(userDataUpload.getRoleRepository());
  }

  @Test
  void givenData_whenCreateFromRow_thenBulkUploadExceptionIsThrown() {
    // given
    Row row = mock(Row.class);
    Map<String, Integer> columnNameToIndex = createColumnNameToIndexMap();

    given(userProfileRepository.save(any())).willThrow(new RuntimeException("Test exception"));

    // when & then
    assertThrows(
        BulkUploadException.class, () -> userDataUpload.createFromRow(row, columnNameToIndex));
  }
}
