package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import com.sunsum.config.MasterDataProperties;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.BulkUploadTracker;
import com.sunsum.model.dto.RowIngestionResult;
import com.sunsum.model.dto.SheetIngestionResult;
import com.sunsum.model.entity.IngestionStatus;
import com.sunsum.model.entity.UploadTracker;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.UploadTrackerRepository;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.service.DataUpload;
import com.sunsum.util.CommonUtils;
import com.sunsum.util.UploadValidation;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.modelmapper.ModelMapper;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

class UploadServiceImplTest {

  @InjectMocks private UploadServiceImpl uploadService;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Mock private UserProfileRepository userProfileRepository;

  @Mock private UploadTrackerRepository uploadTrackerRepository;

  @Spy private ModelMapper modelMapper;

  @Mock private UploadValidation uploadValidation;

  @Mock private ApplicationContext applicationContext;

  @Mock private DataUpload dataUpload;

  @Test
  void givenUploadTrackerExists_whenGetUploadTrackerDetails_thenReturnListOfBulkUploadTrackers() {
    // Given
    UploadTracker uploadTracker = new UploadTracker();
    uploadTracker.setId(1L);
    uploadTracker.setFileType("FileType");
    uploadTracker.setTotal(10);
    uploadTracker.setFailed(2);
    uploadTracker.setSkipped(1);
    uploadTracker.setSuccess(7);
    uploadTracker.setCreatedBy(1L);
    uploadTracker.setCreatedDate(LocalDateTime.now());

    UserProfile userProfile = new UserProfile();
    userProfile.setId(1L);
    userProfile.setName("test@gmail.com");

    BulkUploadTracker expectedBulkUploadTracker = new BulkUploadTracker();
    expectedBulkUploadTracker.setFileType("FileType");
    expectedBulkUploadTracker.setTotal(10);
    expectedBulkUploadTracker.setFailed(2);
    expectedBulkUploadTracker.setSkipped(1);
    expectedBulkUploadTracker.setSuccess(7);
    expectedBulkUploadTracker.setCreatedBy("1");

    when(uploadTrackerRepository.findLatestRecordsForEachFileType())
        .thenReturn(Arrays.asList(uploadTracker));
    when(userProfileRepository.findById(anyLong())).thenReturn(Optional.of(userProfile));

    // When
    List<BulkUploadTracker> result = uploadService.getUploadTrackerDetails();

    // Then
    assertNotNull(result);
    assertEquals(1, result.size());
  }

  @Test
  void givenValidXLSXFileType_whenBulkInsert_shouldThrowBusinessRuleException() throws IOException {
    // given
    MultipartFile mockFile = mock(MockMultipartFile.class);

    UploadValidation uploadValidationSpy = spy(new UploadValidation());
    doReturn(true).when(uploadValidationSpy).checkFileType(mockFile);

    MasterDataProperties mockMasterDataProperties = mock(MasterDataProperties.class);
    ApplicationContext mockApplicationContext = mock(ApplicationContext.class);
    UploadTrackerRepository mockUploadTrackerRepository = mock(UploadTrackerRepository.class);
    ModelMapper mockModelMapper = mock(ModelMapper.class);
    CommonUtils mockCommonUtils = mock(CommonUtils.class);
    UserProfileRepository mockUserProfileRepository = mock(UserProfileRepository.class);

    InputStream inputStream = new ByteArrayInputStream("file-content".getBytes());
    if (mockFile instanceof MockMultipartFile) {
      when(((MockMultipartFile) mockFile).getInputStream()).thenReturn(inputStream);
    } else {
      throw new RuntimeException("Unexpected MultipartFile type");
    }

    UploadServiceImpl uploadServiceSpy =
        new UploadServiceImpl(
            uploadValidationSpy,
            mockMasterDataProperties,
            mockApplicationContext,
            mockUploadTrackerRepository,
            mockModelMapper,
            mockCommonUtils,
            mockUserProfileRepository);

    // when
    BusinessRuleException exception =
        assertThrows(BusinessRuleException.class, () -> uploadServiceSpy.bulkInsert(mockFile));

    // then
    assertEquals("UNABLE_TO_PROCESS_THE_UPLOADED_FILE", exception.getErrorMessage());
    assertEquals(HttpStatus.BAD_REQUEST, exception.getHttpStatus());
  }

  @Test
  void bulkInsert_invalidFileType_shouldThrowBusinessRuleException() throws IOException {
    // given
    MultipartFile mockFile = mock(MockMultipartFile.class);

    given(uploadValidation.checkFileType(mockFile)).willReturn(false);

    // when
    BusinessRuleException exception =
        assertThrows(BusinessRuleException.class, () -> uploadService.bulkInsert(mockFile));

    // then
    assertEquals("INVALID_FILE_FORMAT", exception.getErrorMessage());
    assertEquals(HttpStatus.BAD_REQUEST, exception.getHttpStatus());
  }

  @Test
  void bulkInsert_WithValidFile_ShouldReturnSheetIngestionResult() throws IOException {
    // given
    try (InputStream input = getClass().getClassLoader().getResourceAsStream("User1.xlsx")) {
      MultipartFile multipartFile =
          new MockMultipartFile(
              "User1.xlsx",
              "User1.xlsx",
              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
              input.readAllBytes());

      MasterDataProperties mockBulkUploadProperties = mock(MasterDataProperties.class);
      when(mockBulkUploadProperties.getFileTypes()).thenReturn(Map.of("user", "User1"));

      when(applicationContext.getBean(any(String.class), eq(DataUpload.class)))
          .thenReturn(dataUpload);

      when(uploadValidation.checkFileType(any())).thenReturn(true);
      when(uploadValidation.getMandatoryHeadersForFileType(any()))
          .thenReturn(List.of("Header1", "Header2"));
      when(uploadValidation.isSheetEmpty(any())).thenReturn(false);
      when(uploadValidation.validateHeaders(any(), any())).thenReturn(true);
      when(uploadValidation.removeEmptyRows(any())).thenCallRealMethod();

      UploadServiceImpl uploadServiceSpy =
          new UploadServiceImpl(
              uploadValidation,
              mockBulkUploadProperties,
              applicationContext,
              mock(UploadTrackerRepository.class),
              mock(ModelMapper.class),
              mock(CommonUtils.class),
              mock(UserProfileRepository.class));

      when(dataUpload.createFromRow(any(), any())).thenReturn(dataUpload);
      when(dataUpload.dataInjection(anyInt()))
          .thenReturn(RowIngestionResult.builder().status(IngestionStatus.INSERTED).build());

      // when
      assertDoesNotThrow(
          () -> {
            SheetIngestionResult result = uploadServiceSpy.bulkInsert(multipartFile);

            // then
            assertNotNull(result);
          });
    }
  }

  @Test
  void givenMissingMandatoryColumnsInSheet_whenBulkInsert_thenShouldThrowBusinessRuleException()
      throws IOException {
    // given
    try (InputStream input =
        getClass().getClassLoader().getResourceAsStream("User1_MissingHeaders.xlsx")) {
      MultipartFile multipartFile =
          new MockMultipartFile(
              "User1_MissingHeaders.xlsx",
              "User1_MissingHeaders.xlsx",
              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
              input.readAllBytes());

      MasterDataProperties mockBulkUploadProperties = mock(MasterDataProperties.class);
      when(mockBulkUploadProperties.getFileTypes()).thenReturn(Map.of("user", "User1"));

      when(applicationContext.getBean(anyString(), eq(DataUpload.class))).thenReturn(dataUpload);

      when(uploadValidation.checkFileType(any())).thenReturn(true);
      when(uploadValidation.getMandatoryHeadersForFileType(any()))
          .thenReturn(List.of("Header1", "Header2"));
      when(uploadValidation.isSheetEmpty(any())).thenReturn(false);
      when(uploadValidation.validateHeaders(any(), any()))
          .thenReturn(false); // Simulate missing headers
      when(uploadValidation.removeEmptyRows(any())).thenCallRealMethod();

      UploadServiceImpl uploadServiceSpy =
          new UploadServiceImpl(
              uploadValidation,
              mockBulkUploadProperties,
              applicationContext,
              mock(UploadTrackerRepository.class),
              mock(ModelMapper.class),
              mock(CommonUtils.class),
              mock(UserProfileRepository.class));

      // when
      BusinessRuleException exception =
          assertThrows(
              BusinessRuleException.class,
              () -> {
                SheetIngestionResult result = uploadServiceSpy.bulkInsert(multipartFile);
              });

      // then
      assertEquals("MANDATORY_COLUMNS_MISSING", exception.getErrorMessage());
      assertEquals(HttpStatus.BAD_REQUEST, exception.getHttpStatus());
    }
  }

  @Test
  void givenEmptySheet_whenBulkInsert_thenShouldThrowBusinessRuleException() throws IOException {
    // given
    try (InputStream input = getClass().getClassLoader().getResourceAsStream("empty.xlsx")) {
      MultipartFile multipartFile =
          new MockMultipartFile(
              "empty.xlsx",
              "empty.xlsx",
              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
              input.readAllBytes());

      MasterDataProperties mockBulkUploadProperties = mock(MasterDataProperties.class);
      when(mockBulkUploadProperties.getFileTypes()).thenReturn(Map.of("user", "User1"));

      when(applicationContext.getBean(anyString(), eq(DataUpload.class))).thenReturn(dataUpload);

      when(uploadValidation.checkFileType(any())).thenReturn(true);
      when(uploadValidation.getMandatoryHeadersForFileType(any()))
          .thenReturn(List.of("Header1", "Header2"));
      when(uploadValidation.isSheetEmpty(any())).thenReturn(true);
      when(uploadValidation.validateHeaders(any(), any())).thenReturn(true);
      when(uploadValidation.removeEmptyRows(any())).thenCallRealMethod();

      UploadServiceImpl uploadServiceSpy =
          new UploadServiceImpl(
              uploadValidation,
              mockBulkUploadProperties,
              applicationContext,
              mock(UploadTrackerRepository.class),
              mock(ModelMapper.class),
              mock(CommonUtils.class),
              mock(UserProfileRepository.class));

      // when
      BusinessRuleException exception =
          assertThrows(
              BusinessRuleException.class,
              () -> {
                SheetIngestionResult result = uploadServiceSpy.bulkInsert(multipartFile);
              });

      // then
      assertEquals("INVALID_SHEET_NAME", exception.getErrorMessage());
      assertEquals(HttpStatus.BAD_REQUEST, exception.getHttpStatus());
    }
  }
}
