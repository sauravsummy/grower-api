package com.sunsum.service.impl;

import static org.assertj.core.api.Assertions.fail;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.sunsum.constants.ChannelType;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.MessageBirdProperty;
import com.sunsum.model.dto.OtpVerifyRequest;
import com.sunsum.model.entity.OTPCountTracker;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.OtpCountRepository;
import com.sunsum.repository.UserProfileRepository;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.ReflectionUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@ExtendWith(SpringExtension.class)
class OtpServiceImplTest {

  @Mock private MessageBirdProperty messageBirdProperty;

  @Mock private OtpCountRepository otpCountRepo;

  @Mock private RestTemplate restTemplate;

  @Mock private UserProfileRepository userProfileRepository;

  @InjectMocks private OtpServiceImpl otpService;

  // for mobile otp success and failure
  @Test
  void givenSuccessfulRequest_WhenSendingOtpToMobile_ThenReturnOkStatus() {
    // given
    given(messageBirdProperty.getMockMobileNumber()).willReturn("9391693921");
    given(messageBirdProperty.getSendOtpMobileUrl()).willReturn("otp");
    given(restTemplate.postForEntity(eq("otp"), any(), eq(String.class)))
        .willReturn(new ResponseEntity<>(HttpStatus.NO_CONTENT));
    given(otpCountRepo.findByRecipientId(any()))
        .willReturn(
            Optional.of(
                new OTPCountTracker("9999999999", 3, Timestamp.valueOf(LocalDateTime.now()))));
    // when
    ResponseEntity<String> responseEntity = otpService.sendOtpToMobile("09999999999");

    // then
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }

  @Test
  void givenInValidMobileNo_WhenSendingOtpToMobile_ThenShouldThrow() {
    // given
    given(messageBirdProperty.getSendOtpMobileUrl()).willReturn("send_otp_mobile_url");
    given(restTemplate.postForEntity(eq("send_otp_mobile_url"), any(), eq(String.class)))
        .willThrow(new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

    // when
    Executable executable = () -> otpService.sendOtpToMobile("mobile_number");

    // then
    assertThrows(NumberFormatException.class, executable);
  }

  // validating the user

  @Test
  void givenValidUserEmail_WhenValidatingUser_ThenDoesNotThrowException() throws Exception {
    // given

    Method validateUserMethod =
        OtpServiceImpl.class.getDeclaredMethod("validateUser", String.class, ChannelType.class);
    validateUserMethod.setAccessible(true);

    UserProfileRepository userProfileRepository = mock(UserProfileRepository.class);
    ReflectionTestUtils.setField(otpService, "userProfileRepository", userProfileRepository);

    String recipientId = "existingUser";
    ChannelType channelType = ChannelType.EMAIL_ID;
    given(userProfileRepository.findByEmailIgnoreCase(recipientId))
        .willReturn(Optional.of(UserProfile.builder().isActive(true).build()));

    // when
    try {
      validateUserMethod.invoke(otpService, recipientId, channelType);
    } catch (InvocationTargetException e) {
      fail("Unexpected exception: " + e.getCause());
    }

    // then
    verify(userProfileRepository, times(1)).findByEmailIgnoreCase(recipientId);
  }

  @Test
  void givenUnknownUserEmail_WhenValidatingUser_ThenThrowsBusinessRuleException() throws Exception {
    // given

    Method validateUserMethod =
        OtpServiceImpl.class.getDeclaredMethod("validateUser", String.class, ChannelType.class);
    validateUserMethod.setAccessible(true);

    UserProfileRepository userProfileRepository = mock(UserProfileRepository.class);
    ReflectionTestUtils.setField(otpService, "userProfileRepository", userProfileRepository);

    String recipientId = "spalavajala@gmail.com";
    ChannelType channelType = ChannelType.EMAIL_ID;
    given(userProfileRepository.findByEmailIgnoreCase(recipientId)).willReturn(Optional.empty());

    // when
    try {
      validateUserMethod.invoke(otpService, recipientId, channelType);
      fail("Expected BusinessRuleException was not thrown");
    } catch (InvocationTargetException e) {
      Throwable cause = e.getCause();
      // then
      assertTrue(cause instanceof BusinessRuleException);
      assertEquals("Unknown User", cause.getMessage());
      assertEquals(HttpStatus.BAD_REQUEST, ((BusinessRuleException) cause).getHttpStatus());
    }
  }

  @Test
  void givenInvalidPhoneNumber_WhenValidatingUser_ThenThrowsException() throws Exception {
    // given

    Method validateUserMethod =
        OtpServiceImpl.class.getDeclaredMethod("validateUser", String.class, ChannelType.class);
    validateUserMethod.setAccessible(true);

    UserProfileRepository userProfileRepository = mock(UserProfileRepository.class);
    ReflectionTestUtils.setField(otpService, "userProfileRepository", userProfileRepository);

    String recipientId = "1L";
    ChannelType channelType = ChannelType.PHONE_NUMBER;
    given(userProfileRepository.findByPhoneNo(1L)).willReturn(Optional.empty());

    // when
    try {
      validateUserMethod.invoke(otpService, recipientId, channelType);
      fail("Expected BusinessRuleException was not thrown");
    } catch (InvocationTargetException e) {
      Throwable cause = e.getCause();
      // then
      assertNotNull(cause);
    }
  }

  @Test
  void givenOtpVerifyRequestForEmailChannel_WhenValidInput_ThenReturnsCorrectMap() {
    // given
    OtpVerifyRequest otpVerifyRequest = mock(OtpVerifyRequest.class);
    given(otpVerifyRequest.getChannelType()).willReturn(ChannelType.EMAIL_ID);
    given(otpVerifyRequest.getOtp()).willReturn("123456");
    given(otpVerifyRequest.getRecipientId()).willReturn("name@gmail.com");

    // when
    Map<String, String> result =
        ReflectionTestUtils.invokeMethod(otpService, "getRequestBody", otpVerifyRequest);

    // then
    assertEquals(Map.of("identifier", "name@gmail.com_123456"), result);
  }

  @Test
  void givenGetRequestBodyForPhoneNumberChannel_whenValidInput_thenReturnsCorrectMap() {
    // given
    OtpVerifyRequest otpVerifyRequest = mock(OtpVerifyRequest.class);
    given(otpVerifyRequest.getChannelType()).willReturn(ChannelType.PHONE_NUMBER);
    given(otpVerifyRequest.getOtp()).willReturn("1234");
    given(otpVerifyRequest.getRecipientId()).willReturn("9391693921");

    // when
    Map<String, String> result =
        ReflectionTestUtils.invokeMethod(otpService, "getRequestBody", otpVerifyRequest);

    // then
    assertEquals(Map.of("identifier", "9391693921_1234"), result);
  }

  @Test
  void givenOtpVerifyRequestForPhoneNumberChannel_WhenValidInput_ThenReturnsCorrectMap() {
    // given
    MessageBirdProperty messageBirdProperty = mock(MessageBirdProperty.class);
    OtpVerifyRequest otpVerifyRequest = mock(OtpVerifyRequest.class);

    given(otpVerifyRequest.getChannelType()).willReturn(ChannelType.PHONE_NUMBER);
    given(messageBirdProperty.getVerifyOtpMobileUrl()).willReturn("verify_otp_mobile_url");

    ReflectionTestUtils.setField(otpService, "messageBirdProperty", messageBirdProperty);

    // when
    String result = ReflectionTestUtils.invokeMethod(otpService, "getVerifyUrl", otpVerifyRequest);

    // then
    assertEquals("verify_otp_mobile_url", result);
  }

  @Test
  void givenOtpVerifyRequestForPhoneNumberChannel_WhenValidInput_ThenReturnsCorrectUrl() {
    // given
    MessageBirdProperty messageBirdProperty = mock(MessageBirdProperty.class);
    OtpVerifyRequest otpVerifyRequest = mock(OtpVerifyRequest.class);

    given(otpVerifyRequest.getChannelType()).willReturn(ChannelType.EMAIL_ID);
    given(messageBirdProperty.getVerifyOtpEmailUrl()).willReturn("verify_otp_email_url");

    ReflectionTestUtils.setField(otpService, "messageBirdProperty", messageBirdProperty);

    // when
    String result = ReflectionTestUtils.invokeMethod(otpService, "getVerifyUrl", otpVerifyRequest);

    // then
    assertEquals("verify_otp_email_url", result);
  }

  @Test
  void givenOtpVerifyRequestForEmailChannel_WhenValidInput_ThenReturnsCorrectUrl() {
    // given
    Method privateMethod =
        ReflectionUtils.findMethod(OtpServiceImpl.class, "validateEmailId", String.class);
    assert privateMethod != null;
    privateMethod.setAccessible(true);

    // when & then
    assertDoesNotThrow(() -> privateMethod.invoke(otpService, "name@gmail.com"));
  }

  @Test
  void givenValidEmailId_WhenValidatingEmailId_ThenDoesNotThrowException() {
    // given
    Method privateMethod =
        ReflectionUtils.findMethod(OtpServiceImpl.class, "validateEmailId", String.class);
    assert privateMethod != null;
    privateMethod.setAccessible(true);

    // when & then
    assertThrows(Exception.class, () -> privateMethod.invoke(otpService, "invalid_email"));
  }

  // checking for otp api call

  @Test
  void givenInvalidEmailId_WhenValidatingEmailId_ThenThrowsException() throws Exception {
    // given

    Method otpApiCallMethod =
        OtpServiceImpl.class.getDeclaredMethod("otpApiCall", Map.class, String.class);
    otpApiCallMethod.setAccessible(true);

    RestTemplate restTemplate = mock(RestTemplate.class);
    ReflectionTestUtils.setField(otpService, "restTemplate", restTemplate);

    Map<String, String> requestBody = new HashMap<>();
    requestBody.put("phone", "+9391693921");
    String url = "mock_url";

    given(restTemplate.postForEntity(Mockito.eq(url), Mockito.any(), Mockito.eq(String.class)))
        .willReturn(new ResponseEntity<>("Success", HttpStatus.OK));

    // when
    ResponseEntity<String> result =
        (ResponseEntity<String>) otpApiCallMethod.invoke(otpService, requestBody, url);

    // then
    assertEquals(HttpStatus.OK, result.getStatusCode());
    assertEquals("Success", result.getBody());
  }

  @Test
  void whenOtpApiCall_thenThrowsHttpClientErrorException() throws Exception {
    // given

    Method otpApiCallMethod =
        OtpServiceImpl.class.getDeclaredMethod("otpApiCall", Map.class, String.class);
    otpApiCallMethod.setAccessible(true);

    RestTemplate restTemplate = mock(RestTemplate.class);

    ReflectionTestUtils.setField(otpService, "restTemplate", restTemplate);

    Map<String, String> requestBody = new HashMap<>();
    requestBody.put("phone", "+9391693921");
    String url = "mock_url";

    given(restTemplate.postForEntity(Mockito.eq(url), Mockito.any(), Mockito.eq(String.class)))
        .willThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Bad Request"));

    // when && then
    try {
      otpApiCallMethod.invoke(otpService, requestBody, url);
    } catch (InvocationTargetException e) {
      Throwable cause = e.getCause();
      assertTrue(cause instanceof HttpClientErrorException);
      assertEquals(HttpStatus.BAD_REQUEST, ((HttpClientErrorException) cause).getStatusCode());
      assertEquals("Bad Request", ((HttpClientErrorException) cause).getMessage());
    }
  }

  @Test
  void whenOtpApiCall_thenThrowsException() throws Exception {
    // given

    Method otpApiCallMethod =
        OtpServiceImpl.class.getDeclaredMethod("otpApiCall", Map.class, String.class);
    otpApiCallMethod.setAccessible(true);

    RestTemplate restTemplate = mock(RestTemplate.class);
    ReflectionTestUtils.setField(otpService, "restTemplate", restTemplate);

    Map<String, String> requestBody = new HashMap<>();
    requestBody.put("phone", "+9391693921");
    String url = "mock_url";

    given(restTemplate.postForEntity(Mockito.eq(url), Mockito.any(), Mockito.eq(String.class)))
        .willThrow(new RuntimeException("Some unexpected exception"));

    // when and then
    assertThrows(
        InvocationTargetException.class,
        () -> otpApiCallMethod.invoke(otpService, requestBody, url));
  }

  // check for valid otp

  @Test
  void givenValidPhoneNumber_whenIsValidOtp_thenReturnTrue() {
    // given
    OtpVerifyRequest request = new OtpVerifyRequest();
    request.setChannelType(ChannelType.PHONE_NUMBER);
    request.setRecipientId("1234567890");
    request.setOtp("123456");

    ResponseEntity<String> mockResponse = new ResponseEntity<>("", HttpStatus.OK);
    given(restTemplate.postForEntity(anyString(), any(), eq(String.class)))
        .willReturn(new ResponseEntity<>("", HttpStatus.OK));

    given(messageBirdProperty.getMockMobileNumber()).willReturn("validRecipientId");
    given(messageBirdProperty.getVerifyOtpMobileUrl()).willReturn("123456");
    given(userProfileRepository.findByPhoneNo(anyLong()))
        .willReturn(Optional.of(UserProfile.builder().isActive(true).build()));

    // when
    boolean result = otpService.isValidOtp(request);

    // then
    assertTrue(result);
  }

  @Test
  void givenDummyAccountPhoneNumber_whenIsValidOtp_thenReturnTrue() {
    // given
    OtpVerifyRequest otpVerifyRequest = new OtpVerifyRequest();
    otpVerifyRequest.setChannelType(ChannelType.PHONE_NUMBER);
    otpVerifyRequest.setRecipientId("09999999999");
    otpVerifyRequest.setOtp("123456");

    ResponseEntity<String> mockResponse = new ResponseEntity<>("", HttpStatus.OK);
    given(restTemplate.postForEntity(any(String.class), any(), eq(String.class)))
        .willReturn(mockResponse);

    // when
    boolean isValid = otpService.isValidOtp(otpVerifyRequest);

    // then
    assertTrue(isValid);
  }

  @Test
  void givenValidPhoneNumber_whenSendOtpToMobile_thenReturnOkStatus() {
    // given
    given(userProfileRepository.findByPhoneNo(anyLong()))
        .willReturn(Optional.of(UserProfile.builder().isActive(true).build()));
    given(otpCountRepo.findByRecipientId(anyString())).willReturn(Optional.empty());
    given(restTemplate.postForEntity(anyString(), any(), eq(String.class)))
        .willReturn(new ResponseEntity<>(null, HttpStatus.NO_CONTENT));

    // when
    ResponseEntity<String> response = otpService.sendOtpToMobile("09999999999");

    // then
    assertEquals(HttpStatus.OK, response.getStatusCode());
  }

  @Test
  void givenMockMobileNumber_whenSendOtpToMobile_thenReturnOkStatus() {

    // when
    ResponseEntity<String> response = otpService.sendOtpToMobile("09999999999");

    // then
    assertEquals(HttpStatus.OK, response.getStatusCode());
  }

  @Test
  void givenInvalidUser_whenSendOtpToMobile_thenThrowBusinessRuleException() {
    // given
    given(messageBirdProperty.getMockMobileNumber()).willReturn("1234567890");
    given(userProfileRepository.findByPhoneNo(anyLong())).willReturn(Optional.empty());

    // when & then
    assertThrows(BusinessRuleException.class, () -> otpService.sendOtpToMobile("9876543210"));
  }

  @Test
  void givenSuccessfulOtpApiCall_whenOtpApiCall_thenReturnNoContent()
      throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
    // given
    String url = "http://url.com";
    Map<String, String> requestBody = Map.of("phone", "1234567890");

    given(restTemplate.postForEntity(anyString(), any(), any()))
        .willReturn(ResponseEntity.noContent().build());

    Method privateMethod =
        OtpServiceImpl.class.getDeclaredMethod("otpApiCall", Map.class, String.class);
    privateMethod.setAccessible(true);

    // when
    ResponseEntity<String> response =
        (ResponseEntity<String>) privateMethod.invoke(otpService, requestBody, url);

    // then
    assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
  }

  @Test
  void givenEmail_whenSendOtpToEmail_thenSuccessful() {
    // Given
    String emailId = "test@gmail.com";
    given(userProfileRepository.findByEmailIgnoreCase(emailId))
        .willReturn(Optional.of(UserProfile.builder().isActive(true).build()));
    given(otpCountRepo.findByRecipientId(emailId)).willReturn(Optional.empty());
    ResponseEntity<String> successResponse = ResponseEntity.noContent().build();
    given(
            restTemplate.postForEntity(
                eq(messageBirdProperty.getSendOtpEmailUrl()), any(), eq(String.class)))
        .willReturn(successResponse);

    // When
    ResponseEntity<String> response = otpService.sendOtpToEmail(emailId);

    // Then
    // verify(otpCountRepo, times(1)).save(any()); TODO
    assertEquals(200, response.getStatusCodeValue());
  }

  @Test
  void givenEmail_whenSendOtpToEmail_thenUserNotFound() {
    // given
    String emailId = "nonexistent@gmail.com";

    given(userProfileRepository.findByEmailIgnoreCase(emailId)).willReturn(Optional.empty());

    // when
    assertThrows(BusinessRuleException.class, () -> otpService.sendOtpToEmail(emailId));

    // then
    verify(otpCountRepo, never()).save(any());
  }

  @Test
  void givenEmail_whenSendOtpToEmail_thenOtpApiFailure() {
    // given
    String emailId = "test@gmail.com";

    given(userProfileRepository.findByEmailIgnoreCase(emailId))
        .willReturn(Optional.of(UserProfile.builder().isActive(true).build()));

    given(otpCountRepo.findByRecipientId(emailId)).willReturn(Optional.empty());

    ResponseEntity<String> failureResponse =
        ResponseEntity.status(HttpStatus.BAD_REQUEST).body("OtpApiFailure");
    given(
            restTemplate.postForEntity(
                eq(messageBirdProperty.getSendOtpEmailUrl()), any(), eq(String.class)))
        .willReturn(failureResponse);

    // when
    ResponseEntity<String> response = otpService.sendOtpToEmail(emailId);

    // then
    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getStatusCodeValue());
  }

  @Test
  void givenEmail_whenSendOtpToEmail_thenOtpCountIncremented_UserFound() {
    // given
    String emailId = "test@gmail.com";

    OTPCountTracker existingOtpCount = new OTPCountTracker();
    existingOtpCount.setRecipientId(emailId);
    existingOtpCount.setOtpCount(2);
    existingOtpCount.setLastOtpTimestamp(Timestamp.valueOf(LocalDateTime.now()));

    given(otpCountRepo.findByRecipientId(emailId)).willReturn(Optional.of(existingOtpCount));
    given(userProfileRepository.findByEmailIgnoreCase(emailId))
        .willReturn(Optional.of(UserProfile.builder().isActive(true).build()));

    // when
    assertThrows(Exception.class, () -> otpService.sendOtpToEmail(emailId));

    // then
    verify(otpCountRepo, never()).save(any());
  }

  @Test
  void checkOTPLimit_OldRecipientIdDifferentDay() throws Exception {
    // given
    String recipientId = "old@gmail.com";
    OtpServiceImpl spyOtpService = spy(otpService);

    OTPCountTracker existingOtpCount = new OTPCountTracker();
    existingOtpCount.setRecipientId(recipientId);
    existingOtpCount.setOtpCount(1);
    existingOtpCount.setLastOtpTimestamp(Timestamp.valueOf(LocalDateTime.now().minusDays(1)));

    given(otpCountRepo.findByRecipientId(recipientId)).willReturn(Optional.of(existingOtpCount));

    // when
    Method privateMethod = OtpServiceImpl.class.getDeclaredMethod("checkOTPLimit", String.class);
    privateMethod.setAccessible(true);
    privateMethod.invoke(spyOtpService, recipientId);

    // then
    assertEquals(1, existingOtpCount.getOtpCount());
  }
}
