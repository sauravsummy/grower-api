package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.willThrow;
import static org.mockito.Mockito.verify;

import com.sunsum.exception.BusinessRuleException;
import com.sunsum.util.AwsS3Util;
import java.io.IOException;
import java.lang.reflect.Field;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.multipart.MultipartFile;

class S3ServiceImplTest {

  @Mock private AwsS3Util awsS3Util;

  @InjectMocks private S3ServiceImpl s3Service;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    String mockBucketName = "testBucket";
    ReflectionTestUtils.setField(s3Service, "bucketName", mockBucketName);
  }

  @Test
  void givenMultipartFilewhenUploadObject_thenSuccess()
      throws IOException, NoSuchFieldException, IllegalAccessException {
    // given
    MultipartFile mockFile = new MockMultipartFile("testFile", "testContent".getBytes());
    String key = "testKey";

    Field bucketNameField = S3ServiceImpl.class.getDeclaredField("bucketName");
    bucketNameField.setAccessible(true);
    String bucketName = (String) bucketNameField.get(s3Service);

    // when
    s3Service.uploadObject(mockFile, key);

    // then
    verify(awsS3Util).uploadFileToS3(mockFile, bucketName, key);
  }

  @Test
  void givenMultipartFilewhenUploadObject_thenExceptionHandling()
      throws IOException, NoSuchFieldException, IllegalAccessException {
    // given
    MultipartFile mockFile =
        new MockMultipartFile(
            "testFile", // Name of the file
            "testContent".getBytes() // Content of the file as a byte array
            );
    String key = "testKey";

    Field bucketNameField = S3ServiceImpl.class.getDeclaredField("bucketName");
    bucketNameField.setAccessible(true);
    String bucketName = (String) bucketNameField.get(s3Service);

    willThrow(new IOException("Simulated IOException"))
        .given(awsS3Util)
        .uploadFileToS3(any(), anyString(), anyString());

    // when & then
    BusinessRuleException exception =
        assertThrows(BusinessRuleException.class, () -> s3Service.uploadObject(mockFile, key));

    assertEquals("Error occurred while uploading image to S3", exception.getMessage());

    verify(awsS3Util).uploadFileToS3(mockFile, bucketName, key);
  }

  @Test
  void givenFilename_whenDelete_thenSuccess() throws NoSuchFieldException, IllegalAccessException {
    // given
    String fileName = "testFile";
    Field bucketNameField = S3ServiceImpl.class.getDeclaredField("bucketName");
    bucketNameField.setAccessible(true);
    String bucketName = (String) bucketNameField.get(s3Service);

    // when and then
    assertDoesNotThrow(() -> s3Service.delete(fileName));
    verify(awsS3Util).delete(bucketName, fileName);
  }

  @Test
  void givenFilename_wheDelete_thenException() {
    // given
    String fileName = "testFile";

    willThrow(new RuntimeException("Simulated Exception"))
        .given(awsS3Util)
        .delete(anyString(), anyString());

    // when & then
    assertDoesNotThrow(() -> s3Service.delete(fileName));
    verify(awsS3Util).delete(anyString(), anyString());
  }
}
