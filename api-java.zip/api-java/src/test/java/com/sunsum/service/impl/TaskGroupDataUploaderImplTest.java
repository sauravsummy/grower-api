package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.*;

import com.sunsum.exception.BulkUploadException;
import com.sunsum.model.dto.RowIngestionResult;
import com.sunsum.model.entity.IngestionStatus;
import com.sunsum.model.entity.TaskGroup;
import com.sunsum.repository.ProjectRepository;
import com.sunsum.repository.TaskGroupRepository;
import com.sunsum.repository.UserProfileRepository;
import java.util.HashMap;
import java.util.Map;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

class TaskGroupDataUploaderImplTest {

  @Mock private Row row;

  @InjectMocks private TaskGroupDataUploaderImpl taskGroupUploader;

  @Mock private ProjectRepository projectRepository;

  @Mock private UserProfileRepository userProfileRepository;

  @Mock private TaskGroupRepository taskGroupRepository;

  private static final String ID = "Id";
  private static final String TITLE = "Title";
  private static final String PROJECT_ID = "Project Id";
  private static final String STATUS = "Status";
  private static final String MEMO = "Memo";
  private static final String OWNER = "Owner";
  private static final String ORDER = "Order";
  private static final String IS_LOCKED = "is Locked";
  private static final String MEMO_1 = "Memo_1";
  private static final String MEMO_2 = "Memo_2";
  private static final String MEMO_3 = "Memo_3";
  private static final String MEMO_4 = "Memo_4";
  private static final String MEMO_5 = "Memo_5";

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  private Map<String, Integer> initializeColumnNameToIndex() {
    Map<String, Integer> columnNameToIndex = new HashMap<>();
    columnNameToIndex.put(TITLE, 0);
    columnNameToIndex.put(PROJECT_ID, 1);
    columnNameToIndex.put(ID, 2);
    columnNameToIndex.put(STATUS, 3);
    columnNameToIndex.put(MEMO, 4);
    columnNameToIndex.put(OWNER, 5);
    columnNameToIndex.put(ORDER, 6);
    columnNameToIndex.put(IS_LOCKED, 7);
    columnNameToIndex.put(MEMO_1, 8);
    columnNameToIndex.put(MEMO_2, 9);
    columnNameToIndex.put(MEMO_3, 10);
    columnNameToIndex.put(MEMO_4, 11);
    columnNameToIndex.put(MEMO_5, 12);
    return columnNameToIndex;
  }

  @Test
  void givenValidRowData_whenCreateFromRow_thenShouldCreateTaskGroupEntitySuccessfully() {
    // given
    Map<String, Integer> columnNameToIndex = initializeColumnNameToIndex();

    given(row.getRowNum()).willReturn(1);

    Cell idCell = Mockito.mock(Cell.class);
    given(row.getCell(2)).willReturn(idCell);
    given(idCell.getCellType()).willReturn(CellType.NUMERIC);

    Long projectId = 1L;
    Cell projectIdCell = Mockito.mock(Cell.class);
    given(row.getCell(columnNameToIndex.get(PROJECT_ID))).willReturn(projectIdCell);
    given(projectIdCell.getCellType()).willReturn(CellType.NUMERIC);
    given(projectIdCell.getNumericCellValue()).willReturn((double) projectId);

    String ownerEmail = "owner@example.com";
    Cell ownerCell = Mockito.mock(Cell.class);
    given(row.getCell(5)).willReturn(ownerCell);
    given(ownerCell.getCellType()).willReturn(CellType.STRING);
    given(ownerCell.getStringCellValue()).willReturn(ownerEmail);

    Long temp = 2L;
    Cell orderCell = Mockito.mock(Cell.class);
    given(row.getCell(columnNameToIndex.get(ORDER))).willReturn(orderCell);
    given(orderCell.getCellType()).willReturn(CellType.NUMERIC);
    doReturn((double) temp).when(orderCell).getNumericCellValue();

    Boolean isLockedValue = true;
    Cell isLockedCell = Mockito.mock(Cell.class);
    given(row.getCell(columnNameToIndex.get(IS_LOCKED))).willReturn(isLockedCell);
    given(isLockedCell.getCellType()).willReturn(CellType.BOOLEAN);
    given(isLockedCell.getBooleanCellValue()).willReturn(isLockedValue);
    // when
    taskGroupUploader.createFromRow(row, columnNameToIndex);

    // then
    // assertEquals(Integer.valueOf(1), taskGroupUploader.getRowNum());
    TaskGroup taskGroupEntity = taskGroupUploader.getTaskGroupEntity();
    assertNotNull(taskGroupEntity);
    assertNotNull(taskGroupUploader.getTaskGroupRepository());
    assertNotNull(taskGroupUploader.getUserProfileRepository());
    assertNotNull(taskGroupUploader.getProjectRepository());
  }

  @Test
  void givenUpdateTaskGroup_whenDataInjection_thenSuccess() {
    // Arrange
    TaskGroup taskGroup = new TaskGroup();
    taskGroup.setId(1L);
    ReflectionTestUtils.setField(taskGroupUploader, "taskGroupEntity", taskGroup);

    given(taskGroupRepository.save(any())).willReturn(taskGroup);

    // Act
    RowIngestionResult result = taskGroupUploader.dataInjection(1);

    // Assert
    assertEquals(1, result.getRowNumber());
    Assertions.assertEquals(IngestionStatus.UPDATED, result.getStatus());
  }

  @Test
  void givenData_whenCreateFromRow_thenBulkUploadExceptionIsThrown() {
    // given
    Row row = mock(Row.class);
    Map<String, Integer> columnNameToIndex = initializeColumnNameToIndex();

    doThrow(new RuntimeException("Test exception")).when(row).getRowNum();

    // when and then
    BulkUploadException exception =
        assertThrows(
            BulkUploadException.class,
            () -> taskGroupUploader.createFromRow(row, columnNameToIndex));

    assertEquals(
        "Exception occurred while creating a Task Group entity from the excel row",
        exception.getMessage());
    assertNotNull(exception.getCause());
  }

  @Test
  void givenData_whenDataInjection_thenBulkUploadExceptionIsThrown2() {
    // given
    taskGroupUploader =
        new TaskGroupDataUploaderImpl(
            projectRepository, userProfileRepository, taskGroupRepository);
    taskGroupUploader.setTaskGroupEntity(new TaskGroup());
    given(taskGroupRepository.save(any())).willThrow(new RuntimeException("Test exception"));

    // when and then
    Exception exception = assertThrows(Exception.class, () -> taskGroupUploader.dataInjection(1));

    assertNotNull(exception);
  }
}
