package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;

import com.sunsum.constants.UserRole;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.entity.Role;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.UserProfileRepository;
import java.util.Collection;
import java.util.Collections;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
class UserDetailsServiceImplTest {

  @Mock private UserProfileRepository userProfileRepository;

  @InjectMocks private UserDetailsServiceImpl userDetailsService;

  @Test
  void givenExistingUser_whenLoadUserByUsername_thenShouldReturnUserDetails() {
    // given
    UserProfile userProfile = new UserProfile();
    userProfile.setId(1L);
    userProfile.setRoles(Collections.singleton(new Role(1L, UserRole.ROLE_USER, null)));
    given(userProfileRepository.findById(anyLong())).willReturn(Optional.of(userProfile));

    // when
    UserDetails userDetails = userDetailsService.loadUserByUsername("1");

    // then
    assertNotNull(userDetails);
    assertEquals("1", userDetails.getUsername());
    Collection<? extends GrantedAuthority> authorities = userDetails.getAuthorities();
    assertNotNull(authorities);
    assertEquals(1, authorities.size());
    assertTrue(authorities.contains(new SimpleGrantedAuthority("ROLE_USER")));
  }

  @Test
  void givenNonExistingUser_whenLoadUserByUsername_thenShouldThrowBusinessRuleException() {
    // given
    given(userProfileRepository.findById(anyLong())).willReturn(Optional.empty());

    // when & then
    assertThrows(BusinessRuleException.class, () -> userDetailsService.loadUserByUsername("1"));
  }
}
