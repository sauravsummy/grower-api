package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willThrow;
import static org.mockito.Mockito.*;

import com.sunsum.constants.AppConstants;
import com.sunsum.constants.OrgType;
import com.sunsum.constants.Status;
import com.sunsum.model.entity.Organization;
import com.sunsum.repository.OrganisationRepository;
import com.sunsum.service.DataDownload;
import com.sunsum.util.ExcelUtils;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
class OrganisationDataDownloadImplTest {

  @Mock private OrganisationRepository organisationRepository;

  @Mock private ExcelUtils excelUtils;

  @InjectMocks private OrganisationDataDownloadImpl organisationDownloader;

  private List<Organization> mockOrganizations;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    mockOrganizations =
        Arrays.asList(
            new Organization(
                1L,
                "Org1",
                OrgType.SYNGENTA,
                Status.ACTIVE,
                new HashSet<>(),
                new HashSet<>(),
                "Memo1",
                "Memo2",
                "Memo3",
                "Memo4",
                "Memo5"),
            new Organization(
                2L,
                "Org2",
                OrgType.CHANNEL_PARTNER,
                Status.INACTIVE,
                new HashSet<>(),
                new HashSet<>(),
                "Memo6",
                "Memo7",
                "Memo8",
                "Memo9",
                "Memo10"));
    organisationDownloader = new OrganisationDataDownloadImpl(organisationRepository, excelUtils);
  }

  @Test
  void givenOrganisationsExist_whenPrepareSheet_thenShouldSuccessfullyPrepareOrganisationSheet()
      throws IOException {
    // given
    XSSFWorkbook mockWorkbook = mock(XSSFWorkbook.class);
    XSSFSheet mockSheet = mock(XSSFSheet.class);

    given(organisationRepository.findAllByOrderByIdAsc()).willReturn(mockOrganizations);
    given(mockWorkbook.createSheet(AppConstants.SHEET_ORGANISATION)).willReturn(mockSheet);

    // when
    ByteArrayInputStream result =
        organisationDownloader.fetch().prepareSheet("column1,column2,column3", "column1,column3");

    // then
    assertNotNull(result);
    verify(organisationRepository, times(1)).findAllByOrderByIdAsc();
  }

  @Test
  void givenOrganisationsExist_whenFetch_thenShouldSuccessfullyFetchOrganizations() {
    // given
    List<Organization> mockOrgData =
        Arrays.asList(
            createOrganization(
                1L,
                "Org1",
                OrgType.CHANNEL_PARTNER,
                Status.ACTIVE,
                "Memo1",
                "Memo2",
                "Memo3",
                "Memo4",
                "Memo5"),
            createOrganization(
                2L,
                "Org2",
                OrgType.FARM_HOLDINGS,
                Status.INACTIVE,
                "Memo1",
                "Memo2",
                "Memo3",
                "Memo4",
                "Memo5"));

    given(organisationRepository.findAllByOrderByIdAsc()).willReturn(mockOrgData);

    // when
    DataDownload result = organisationDownloader.fetch();

    // then
    assertNotNull(result);
    assertSame(organisationDownloader, result);
    verify(organisationRepository, times(1)).findAllByOrderByIdAsc();
    // assertEquals(mockOrgData, organisationDownloader.orgData);
  }

  private Organization createOrganization(
      Long id,
      String title,
      OrgType type,
      Status status,
      String memo1,
      String memo2,
      String memo3,
      String memo4,
      String memo5) {
    Organization org = new Organization();
    org.setId(id);
    org.setTitle(title);
    org.setType(type);
    org.setStatus(status);
    org.setMemo1(memo1);
    org.setMemo2(memo2);
    org.setMemo3(memo3);
    org.setMemo4(memo4);
    org.setMemo5(memo5);
    return org;
  }

  @Test
  void givenOrganisation_whenPrepareSheet_thenThrowRuntimeException() throws IOException {
    // given
    given(organisationRepository.findAllByOrderByIdAsc()).willReturn(mock(List.class));

    Workbook mockWorkbook = mock(Workbook.class);
    given(mockWorkbook.createSheet(any())).willThrow(new RuntimeException("Test Exception"));

    OrganisationDataDownloadImpl spyOrganisationDataDownload = spy(organisationDownloader);

    // when & then
    assertThrows(
        RuntimeException.class,
        () -> spyOrganisationDataDownload.prepareSheet("columns", "mandatoryColumns"));
  }

  @Test
  void
      givenOrganisationRepositoryDataAndExcelUtils_whenPrepareSheet_thenSimulateErrorAndReturnResult() {
    // given
    List<Organization> mockOrgData = Arrays.asList(new Organization(), new Organization());

    given(organisationRepository.findAllByOrderByIdAsc()).willReturn(mockOrgData);
    organisationDownloader.fetch();
    willThrow(new RuntimeException("Simulated error"))
        .given(excelUtils)
        .createCell(any(), anyInt(), any(), any());

    // when
    ByteArrayInputStream result =
        organisationDownloader.prepareSheet("columns", "mandatoryColumns");

    // then
    assertNotNull(result);
    verify(excelUtils, times(mockOrgData.size())).createCell(any(), anyInt(), any(), any());
  }
}
