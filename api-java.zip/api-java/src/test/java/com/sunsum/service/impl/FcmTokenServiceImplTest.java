package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.FcmTokenRequest;
import com.sunsum.model.dto.UserFcmTokenDto;
import com.sunsum.model.entity.UserFcmToken;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.UserFcmTokenRepository;
import com.sunsum.repository.UserProfileRepository;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class FcmTokenServiceImplTest {

  @Mock private UserFcmTokenRepository userNotificationRepository;

  @Mock private UserProfileRepository userProfileRepository;

  @InjectMocks private FcmTokenServiceImpl fcmTokenService;

  @BeforeEach
  void setUp() {
    // Additional setup if needed
  }

  @Test
  void whenGetActiveUserFcmTokensByUserId_thenReturnActiveTokensForUser() {
    // Given
    Long userId = 1L;
    UserProfile userProfile = new UserProfile();
    userProfile.setId(userId);

    UserFcmToken userFcmToken = new UserFcmToken();
    userFcmToken.setUser(userProfile);
    userFcmToken.setToken("token123");

    List<UserFcmToken> mockTokens = List.of(userFcmToken);
    when(userProfileRepository.findById(userId)).thenReturn(Optional.of(userProfile));
    when(userNotificationRepository.findByUserAndIsActive(userProfile, true))
        .thenReturn(mockTokens);

    // When
    List<UserFcmTokenDto> result = fcmTokenService.getActiveUserFcmTokensByUserId(userId);

    // Then
    assertFalse(result.isEmpty());
    assertEquals(1, result.size());
    assertEquals(userId, result.get(0).getUserId());
    assertEquals("token123", result.get(0).getFcmToken());
  }

  @Test
  void whenSaveFcmToken_thenSaveOrUpdateToken() {
    // Given
    Long userId = 1L; // Example user ID
    String deviceType = "Android"; // Example device type
    String fcmToken = "exampleFcmToken";

    FcmTokenRequest request = new FcmTokenRequest();
    request.setUserId(userId);
    request.setDeviceType(deviceType);
    request.setFcmToken(fcmToken);

    UserProfile mockUser = new UserProfile();
    mockUser.setId(userId);
    when(userProfileRepository.findById(userId)).thenReturn(Optional.of(mockUser));
    when(userNotificationRepository.findByUserAndDeviceType(mockUser, deviceType))
        .thenReturn(Optional.empty());

    // When
    fcmTokenService.saveFcmToken(request);

    // Then
    verify(userNotificationRepository, times(1)).save(any(UserFcmToken.class));
  }

  @Test
  void givenUserNotFound_whenSaveFcmToken_thenThrowException() {
    // Given
    FcmTokenRequest request = new FcmTokenRequest(); // Populate the request
    when(userProfileRepository.findById(request.getUserId())).thenReturn(Optional.empty());

    // When & Then
    Exception exception =
        assertThrows(RuntimeException.class, () -> fcmTokenService.saveFcmToken(request));
    assertEquals("User not found", exception.getMessage());
  }

  @Test
  void whenUpdateFcmToken_thenUpdateToken() {
    // Given
    FcmTokenRequest request = new FcmTokenRequest(); // Populate the request
    UserProfile mockUser = new UserProfile(); // Mock user
    UserFcmToken existingToken = new UserFcmToken(); // Existing token
    existingToken.setUser(mockUser);
    existingToken.setToken("existingToken");

    when(userProfileRepository.findById(request.getUserId())).thenReturn(Optional.of(mockUser));
    when(userNotificationRepository.findByUserAndDeviceType(mockUser, request.getDeviceType()))
        .thenReturn(Optional.of(existingToken));

    // When
    fcmTokenService.saveFcmToken(request);

    // Then
    verify(userNotificationRepository, times(1)).save(existingToken);
    assertEquals(request.getFcmToken(), existingToken.getToken()); // Verify token update
  }

  @Test
  void givenUserProfileRepositoryThrowsException_whenSaveFcmToken_thenHandleException() {
    // Given
    FcmTokenRequest request = new FcmTokenRequest(); // Populate the request
    when(userProfileRepository.findById(request.getUserId()))
        .thenThrow(new RuntimeException("Database error"));

    // When & Then
    Exception exception =
        assertThrows(RuntimeException.class, () -> fcmTokenService.saveFcmToken(request));
    assertEquals("Database error", exception.getMessage());
  }

  @Test
  void whenGetActiveUserFcmTokensByNullUserId_thenReturnActiveTokensForUser() {
    // given
    Long userId = 1L;
    String deviceType = "Android";
    String fcmToken = "exampleFcmToken";

    FcmTokenRequest request = new FcmTokenRequest();
    request.setUserId(userId);
    request.setDeviceType(deviceType);
    request.setFcmToken(fcmToken);

    UserProfile mockUser = new UserProfile();
    mockUser.setId(userId);

    // when
    List<UserFcmTokenDto> result = fcmTokenService.getActiveUserFcmTokensByUserId(null);

    // then
    assertNotNull(result);
    assertTrue(result.isEmpty());
  }

  @Test
  void whenGetActiveUserFcmTokensByUserId_throwBusinessRuleExceptionIfUserNotFound() {
    // Given
    Long userId = 1L;
    given(userProfileRepository.findById(userId)).willReturn(Optional.empty());

    // When & Then
    BusinessRuleException exception =
        assertThrows(
            BusinessRuleException.class,
            () -> fcmTokenService.getActiveUserFcmTokensByUserId(userId));

    assertEquals("User not found with ID: " + userId, exception.getMessage());
  }
}
