package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.sunsum.constants.AppConstants;
import com.sunsum.constants.OrgType;
import com.sunsum.constants.Status;
import com.sunsum.exception.BulkUploadException;
import com.sunsum.model.dto.RowIngestionResult;
import com.sunsum.model.entity.Field;
import com.sunsum.model.entity.FieldTaskGroup;
import com.sunsum.model.entity.IngestionStatus;
import com.sunsum.model.entity.Organization;
import com.sunsum.model.entity.TaskGroup;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.FieldRepository;
import com.sunsum.repository.FieldTaskGroupRepository;
import com.sunsum.repository.OrganisationRepository;
import com.sunsum.repository.TaskFieldRepository;
import com.sunsum.repository.TaskGroupRepository;
import com.sunsum.repository.TaskRepository;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.service.DataUpload;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class FieldDataUploaderImplTest {

  @Mock private FieldRepository fieldRepository;

  @InjectMocks private FieldDataUploaderImpl fieldDataUploader;

  @Mock private TaskGroupRepository taskGroupRepository;

  @Mock private UserProfileRepository userProfileRepositoryMock;

  @Mock private OrganisationRepository organisationRepositoryMock;

  @Mock private FieldTaskGroupRepository fieldTaskGroupRepositoryMock;

  @Mock private TaskRepository taskRepository;

  @Mock private TaskFieldRepository taskFieldRepository;

  private static final String ID = "Id";
  private static final String TITLE = "Title";
  private static final String FARM_HOLDING_ID = "Farm Holding Id";
  private static final String ACREAGE = "Acreage";
  private static final String GPS_COORD = "GPS COORD";
  private static final String ZIP_CODE = "Zip Code";
  private static final String PHOTO_PATH = "Photo Path";
  private static final String MEMO = "Memo";
  private static final String TASK_GROUP_ID = "Task Group Id";
  private static final String FIELD_TASK_GROUP_STATUS = "Field Task Group Status";
  private static final String MEMO_1 = "Memo_1";
  private static final String MEMO_2 = "Memo_2";
  private static final String MEMO_3 = "Memo_3";
  private static final String MEMO_4 = "Memo_4";
  private static final String MEMO_5 = "Memo_5";

  private static final String STATUS = "Status";

  private static final String FIELD_TASK_GROUP_MEMO = "Field Task Group Memo";

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    fieldRepository = mock(FieldRepository.class);
    userProfileRepositoryMock = mock(UserProfileRepository.class);
    taskGroupRepository = mock(TaskGroupRepository.class);
    organisationRepositoryMock = mock(OrganisationRepository.class);
    fieldTaskGroupRepositoryMock = mock(FieldTaskGroupRepository.class);
    taskRepository = mock(TaskRepository.class);
    taskFieldRepository = mock(TaskFieldRepository.class);

    fieldDataUploader =
        new FieldDataUploaderImpl(
            fieldRepository,
            userProfileRepositoryMock,
            taskGroupRepository,
            organisationRepositoryMock,
            fieldTaskGroupRepositoryMock,
            taskRepository,
            taskFieldRepository);

    Organization mockedOrganization =
        new Organization(
            1l,
            "abcd",
            OrgType.FARM_HOLDINGS,
            Status.ACTIVE,
            new HashSet<UserProfile>(),
            new HashSet<Field>(),
            "",
            "",
            "",
            "",
            "");

    given(organisationRepositoryMock.findByIdAndType(any(), any()))
        .willReturn(Optional.of(mockedOrganization));
  }

  @Test
  void givenRowAndColumnNameToIndexMap_whenCreateFromRow_thenDataUploadIsCreatedSuccessfully() {
    // Given
    Row row = mock(Row.class);
    Map<String, Integer> columnNameToIndex = createColumnNameToIndexMap();

    Cell idCell = mock(Cell.class);
    given(idCell.getNumericCellValue()).willReturn(1.0);
    given(idCell.getCellType()).willReturn(CellType.NUMERIC);
    given(row.getCell(columnNameToIndex.get(ID))).willReturn(idCell);

    Cell titleCell = mock(Cell.class);
    given(titleCell.getStringCellValue()).willReturn("Field Title");
    given(titleCell.getCellType()).willReturn(CellType.STRING);
    given(row.getCell(columnNameToIndex.get(TITLE))).willReturn(titleCell);

    Cell farmHoldingIdCell = mock(Cell.class);
    given(farmHoldingIdCell.getNumericCellValue()).willReturn(2.0);
    given(farmHoldingIdCell.getCellType()).willReturn(CellType.NUMERIC);
    given(row.getCell(columnNameToIndex.get(FARM_HOLDING_ID))).willReturn(farmHoldingIdCell);

    Cell acreageCell = mock(Cell.class);
    given(acreageCell.getNumericCellValue()).willReturn(10.5);
    given(acreageCell.getCellType()).willReturn(CellType.NUMERIC);
    given(row.getCell(columnNameToIndex.get(ACREAGE))).willReturn(acreageCell);

    Cell gpsCoordinatesCell = mock(Cell.class);
    given(gpsCoordinatesCell.getStringCellValue()).willReturn("12.345,67.890");
    given(row.getCell(columnNameToIndex.get(GPS_COORD))).willReturn(gpsCoordinatesCell);

    Cell numericZipCodeCell = mock(Cell.class);
    given(numericZipCodeCell.getNumericCellValue()).willReturn(1234567d); // or any numeric value
    given(numericZipCodeCell.getCellType()).willReturn(CellType.NUMERIC);
    given(row.getCell(columnNameToIndex.get(ZIP_CODE))).willReturn(numericZipCodeCell);

    Cell memoCell = mock(Cell.class);
    given(memoCell.getStringCellValue()).willReturn("Sample Memo");
    given(memoCell.getCellType()).willReturn(CellType.STRING);
    given(row.getCell(columnNameToIndex.get(MEMO))).willReturn(memoCell);

    Cell photoPathCell = mock(Cell.class);
    given(photoPathCell.getStringCellValue()).willReturn("path1,path2,path3");
    given(row.getCell(columnNameToIndex.get(PHOTO_PATH))).willReturn(photoPathCell);

    Cell taskGroupIdCell = mock(Cell.class);
    given(taskGroupIdCell.getNumericCellValue()).willReturn(2.0);
    given(taskGroupIdCell.getCellType()).willReturn(CellType.NUMERIC);
    given(row.getCell(columnNameToIndex.get(TASK_GROUP_ID))).willReturn(taskGroupIdCell);

    Cell geoCoordinatesCell = mock(Cell.class);
    given(geoCoordinatesCell.getStringCellValue())
        .willReturn("invalid_value"); // or any invalid value
    given(geoCoordinatesCell.getCellType()).willReturn(CellType.STRING);
    given(row.getCell(columnNameToIndex.get(GPS_COORD))).willReturn(geoCoordinatesCell);

    Long taskGroupId = 2L;
    TaskGroup mockTaskGroup = new TaskGroup();
    given(taskGroupRepository.findById(taskGroupId)).willReturn(Optional.of(mockTaskGroup));

    given(fieldRepository.findById(anyLong())).willReturn(java.util.Optional.of(new Field()));
    given(fieldRepository.save(any(Field.class))).willReturn(new Field());

    // When
    fieldDataUploader.createFromRow(row, columnNameToIndex);
    DataUpload result = fieldDataUploader;

    // Then
    assertNotNull(result);
    assertNotNull(fieldDataUploader.getFieldRepository());
    assertNotNull(fieldDataUploader.getOrganisationRepository());
    assertNotNull(fieldDataUploader);
    assertNotNull(fieldDataUploader.getFieldRepository());
    assertNotNull(fieldDataUploader.getOrganisationRepository());

    assertNotNull(fieldDataUploader.getCurrentRow());
    assertNotNull(fieldDataUploader.getCurrentColumnNameToIndex());
    assertNotNull(fieldDataUploader.getUserProfileRepository());
    assertNotNull(fieldDataUploader.getTaskGroupRepository());
    assertNotNull(fieldDataUploader.getFieldTaskGroupRepository());
    assertNotNull(fieldDataUploader.getFieldEntity());
    assertNotNull(fieldDataUploader.getTaskRepository());
    assertNotNull(fieldDataUploader.getTaskFieldRepository());
  }

  private Map<String, Integer> createColumnNameToIndexMap() {
    Map<String, Integer> columnNameToIndex = new HashMap<>();
    columnNameToIndex.put(ID, 0);
    columnNameToIndex.put(TITLE, 1);
    columnNameToIndex.put(FARM_HOLDING_ID, 2);
    columnNameToIndex.put(ACREAGE, 3);
    columnNameToIndex.put(GPS_COORD, 4);
    columnNameToIndex.put(ZIP_CODE, 5);
    columnNameToIndex.put(PHOTO_PATH, 6);
    columnNameToIndex.put(MEMO, 7);
    columnNameToIndex.put(TASK_GROUP_ID, 8);
    columnNameToIndex.put(FIELD_TASK_GROUP_STATUS, 9);
    columnNameToIndex.put(MEMO_1, 10);
    columnNameToIndex.put(MEMO_2, 11);
    columnNameToIndex.put(MEMO_3, 12);
    columnNameToIndex.put(MEMO_4, 13);
    columnNameToIndex.put(MEMO_5, 14);
    columnNameToIndex.put(FIELD_TASK_GROUP_MEMO, 15);
    columnNameToIndex.put(STATUS, 16);

    return columnNameToIndex;
  }

  @Test
  void givenSuccessfulDataInjection_whenDataInjection_thenFieldIsSaved() {
    // Given
    Row row = mock(Row.class);
    Map<String, Integer> columnNameToIndex = createColumnNameToIndexMap();

    Field field = new Field();
    fieldDataUploader.setFieldEntity(field);
    given(fieldRepository.save(field)).willReturn(field);
    fieldDataUploader.setCurrentRow(row);
    fieldDataUploader.setCurrentColumnNameToIndex(columnNameToIndex);

    Cell taskGroupIdCell = mock(Cell.class);
    given(taskGroupIdCell.getNumericCellValue()).willReturn(2.0);
    given(taskGroupIdCell.getCellType()).willReturn(CellType.NUMERIC);
    given(row.getCell(columnNameToIndex.get(TASK_GROUP_ID))).willReturn(taskGroupIdCell);

    Long taskGroupId = 2L;
    TaskGroup mockTaskGroup = new TaskGroup();
    given(taskGroupRepository.findById(taskGroupId)).willReturn(Optional.of(mockTaskGroup));

    // Populate TaskGroups in fieldEntity
    List<TaskGroup> taskGroups = new ArrayList<>();
    taskGroups.add(mockTaskGroup);
    fieldDataUploader.getFieldEntity().setTaskGroups(taskGroups);

    // When
    RowIngestionResult result = fieldDataUploader.dataInjection(1);

    // Then
    Assertions.assertEquals(IngestionStatus.INSERTED, result.getStatus());
    verify(fieldRepository, times(1)).save(field);
    assertNotNull(result);
  }

  @Test
  void givenFailedDataInjection_whenDataInjection_thenFailedStatusReturned() {
    // Given
    Field field = new Field();
    fieldDataUploader.setFieldEntity(field);
    given(fieldRepository.save(field))
        .willThrow(new RuntimeException("Some error occurred during save"));

    // when and Then
    assertThrows(BulkUploadException.class, () -> fieldDataUploader.dataInjection(1));
    verify(fieldRepository, times(1)).save(field);
  }

  @Test
  void givenExceptionDuringTransformation_whenCreateFromRow_thenBulkUploadExceptionThrown() {
    // Given
    Row row = mock(Row.class);
    Map<String, Integer> columnNameToIndex = createColumnNameToIndexMap();

    Cell idCell = mock(Cell.class);
    given(idCell.getNumericCellValue()).willThrow(new RuntimeException("Test exception"));
    given(row.getCell(columnNameToIndex.get("Id"))).willReturn(idCell);

    // When and Then
    assertThrows(
        BulkUploadException.class, () -> fieldDataUploader.createFromRow(row, columnNameToIndex));
  }

  @Test
  void givenZipCodeCellWithTypeString_whenCreateFromRow_thenZipCodeSetFromString() {
    // Given
    Row row = mock(Row.class);
    Map<String, Integer> columnNameToIndex = createColumnNameToIndexMap();

    Cell zipCodeCell = mock(Cell.class);
    when(zipCodeCell.getCellType()).thenReturn(CellType.STRING);
    when(zipCodeCell.getStringCellValue()).thenReturn("54321"); // or any string value
    when(row.getCell(columnNameToIndex.get(AppConstants.ZIP_CODE))).thenReturn(zipCodeCell);

    // When and Then
    assertThrows(
        BulkUploadException.class, () -> fieldDataUploader.createFromRow(row, columnNameToIndex));
  }

  @Test
  void givenValidGeoCoordinatesLength_whenCreateFromRow_thenGpsCoordinatesSet() {
    // Given
    Row row = mock(Row.class);
    Map<String, Integer> columnNameToIndex = createColumnNameToIndexMap();

    Cell geoCoordinatesCell = mock(Cell.class);
    given(geoCoordinatesCell.getStringCellValue()).willReturn("12.345, 13.456");
    given(geoCoordinatesCell.getCellType()).willReturn(CellType.STRING);
    given(row.getCell(columnNameToIndex.get(AppConstants.GPS_COORD)))
        .willReturn(geoCoordinatesCell);

    // When
    fieldDataUploader.createFromRow(row, columnNameToIndex);

    // Then
    assertNotNull(fieldDataUploader.getFieldEntity().getGpsCoordinates());
  }

  @Test
  void givenInvalidGeoCoordinatesLength_whenCreateFromRow_thenGpsCoordinatesNotSet() {
    // Given
    Row row = mock(Row.class);
    Map<String, Integer> columnNameToIndex = createColumnNameToIndexMap();

    Cell geoCoordinatesCell = mock(Cell.class);
    given(geoCoordinatesCell.getStringCellValue()).willReturn("12.345,13.456");
    given(geoCoordinatesCell.getCellType()).willReturn(CellType.STRING);
    given(row.getCell(columnNameToIndex.get(AppConstants.GPS_COORD)))
        .willReturn(geoCoordinatesCell);

    // When
    fieldDataUploader.createFromRow(row, columnNameToIndex);

    // Then
    assertNull(fieldDataUploader.getFieldEntity().getGpsCoordinates());
  }

  @Test
  void givenInvalidGeoCoordinatesParsing_whenCreateFromRow_thenGpsCoordinatesNotSet() {
    // given
    Row row = mock(Row.class);
    Map<String, Integer> columnNameToIndex = createColumnNameToIndexMap();

    Cell geoCoordinatesCell = mock(Cell.class);
    given(geoCoordinatesCell.getStringCellValue()).willReturn("invalid, nonnumeric");
    given(geoCoordinatesCell.getCellType()).willReturn(CellType.STRING);
    given(row.getCell(columnNameToIndex.get(AppConstants.GPS_COORD)))
        .willReturn(geoCoordinatesCell);

    // When
    fieldDataUploader.createFromRow(row, columnNameToIndex);

    // Then
    assertNull(fieldDataUploader.getFieldEntity().getGpsCoordinates());
  }

  private List<FieldTaskGroup> createFieldTaskGroups() {
    FieldTaskGroup fieldTaskGroup1 = new FieldTaskGroup();
    fieldTaskGroup1.setFiledTaskGroupStatus(Status.INACTIVE);
    FieldTaskGroup fieldTaskGroup2 = new FieldTaskGroup();
    fieldTaskGroup2.setFiledTaskGroupStatus(Status.INACTIVE);
    FieldTaskGroup fieldTaskGroup3 = new FieldTaskGroup();
    fieldTaskGroup3.setFiledTaskGroupStatus(Status.INACTIVE);
    return Arrays.asList(fieldTaskGroup1, fieldTaskGroup2, fieldTaskGroup3);
  }

  @Test
  void givenInactiveFieldStatus_whenCreateFromRow_thenDeactivateAssociatedFieldTaskGroups() {
    // Given
    Row row = mock(Row.class);
    Map<String, Integer> columnNameToIndex = createColumnNameToIndexMap();

    Cell statusCell = mock(Cell.class);
    given(statusCell.getStringCellValue()).willReturn("INACTIVE");
    given(statusCell.getCellType()).willReturn(CellType.STRING);
    given(row.getCell(columnNameToIndex.get(AppConstants.STATUS))).willReturn(statusCell);

    List<FieldTaskGroup> fieldTaskGroups = createFieldTaskGroups();
    given(fieldTaskGroupRepositoryMock.findByFieldId(anyLong())).willReturn(fieldTaskGroups);
    // When
    fieldDataUploader.createFromRow(row, columnNameToIndex);

    // Then
    for (FieldTaskGroup fieldTaskGroup : fieldTaskGroups) {
      Assertions.assertEquals(Status.INACTIVE, fieldTaskGroup.getFiledTaskGroupStatus());
    }
  }
}
