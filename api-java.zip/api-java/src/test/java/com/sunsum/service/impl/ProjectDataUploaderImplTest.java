package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.when;

import com.sunsum.constants.AppConstants;
import com.sunsum.exception.BulkUploadException;
import com.sunsum.model.dto.RowIngestionResult;
import com.sunsum.model.entity.IngestionStatus;
import com.sunsum.model.entity.Project;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.ProjectRepository;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.service.DataUpload;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

class ProjectDataUploaderImplTest {

  @Mock private ProjectRepository projectRepository;

  @Mock private UserProfileRepository userProfileRepository;

  @InjectMocks private ProjectDataUploaderImpl projectDataUploader;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void whenCreateFromRow_givenValidRow_thenSuccess() {
    // given
    Row row = Mockito.mock(Row.class);
    Map<String, Integer> columnNameToIndex = new HashMap<>();
    columnNameToIndex.put(AppConstants.TITLE, 0);
    columnNameToIndex.put(AppConstants.AREA, 1);
    columnNameToIndex.put(AppConstants.YEAR, 2);
    columnNameToIndex.put(AppConstants.ID, 3);
    columnNameToIndex.put(AppConstants.OWNER, 4);
    columnNameToIndex.put(AppConstants.STATUS, 5);
    columnNameToIndex.put(AppConstants.MEMO_1, 6);
    columnNameToIndex.put(AppConstants.MEMO_2, 7);
    columnNameToIndex.put(AppConstants.MEMO_3, 8);
    columnNameToIndex.put(AppConstants.MEMO_4, 9);
    columnNameToIndex.put(AppConstants.MEMO_5, 10);

    when(userProfileRepository.findByEmail(any())).thenReturn(Optional.of(new UserProfile()));

    Cell titleCell = Mockito.mock(Cell.class);
    when(row.getCell(0)).thenReturn(titleCell);
    when(titleCell.getCellType())
        .thenReturn(CellType.STRING); // Assuming TITLE is a string, adjust accordingly

    // when
    DataUpload result = projectDataUploader.createFromRow(row, columnNameToIndex);

    // then
    assertNotNull(result);
    assertEquals(projectDataUploader, result);
  }

  @Test
  void givenProject_whenDataInjection_thenSuccess() {
    // given
    Project project = new Project();
    ReflectionTestUtils.setField(projectDataUploader, "projectEntity", project);

    given(projectRepository.save(any())).willReturn(project);

    // when
    RowIngestionResult result = projectDataUploader.dataInjection(1);

    // then
    assertEquals(1, result.getRowNumber());
    Assertions.assertEquals(IngestionStatus.INSERTED, result.getStatus());
  }

  @Test
  void givenProject_whenDataInjection_thenFailureResult() {
    // given
    Project project = new Project();
    ReflectionTestUtils.setField(projectDataUploader, "projectEntity", project);

    given(projectRepository.save(any())).willThrow(new RuntimeException("Save failed"));

    // when
    assertThrows(BulkUploadException.class, () -> projectDataUploader.dataInjection(1));
  }
}
