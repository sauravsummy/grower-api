package com.sunsum.service.impl; // package


import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import com.sunsum.config.MasterDataDownloadProperties;
import com.sunsum.config.MasterDataProperties;
import com.sunsum.constants.AppConstants;
import com.sunsum.service.DataDownload;
import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class DownloadServiceImplTest {

  @Mock private DataDownload mockDataDownload;

  @Mock private MasterDataDownloadProperties mockMasterDataDownloadProperties;

  @Mock private MasterDataProperties mockMasterDataProperties;

  @InjectMocks private DownloadServiceImpl downloadService;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    Map<String, DataDownload> dataUploadMap = new HashMap<>();
    dataUploadMap.put("category" + AppConstants.DOWNLOADER, mockDataDownload);

    downloadService =
        new DownloadServiceImpl(
            dataUploadMap, mockMasterDataDownloadProperties, mockMasterDataProperties);
  }

  @Test
  void givenExistingCategory_whenDownload_thenShouldReturnByteArrayInputStream() {
    // given
    given(mockDataDownload.fetch()).willReturn(mockDataDownload);
    given(mockDataDownload.prepareSheet(anyString(), anyString()))
        .willReturn(new ByteArrayInputStream(new byte[0]));
    given(mockMasterDataDownloadProperties.getFileTypes()).willReturn(createFileTypeMap());
    given(mockMasterDataProperties.getFileTypes()).willReturn(createFileTypeMap());

    // when
    ByteArrayInputStream result = downloadService.download("category");

    // then
    assertNotNull(result, "Result should not be null");

    verify(mockDataDownload).fetch();
    verify(mockMasterDataDownloadProperties).getFileTypes();
    verify(mockMasterDataProperties).getFileTypes();
    verify(mockDataDownload).prepareSheet(anyString(), anyString());
  }

  private Map<String, String> createFileTypeMap() {
    // Mock data for file types
    Map<String, String> fileTypes = new HashMap<>();
    fileTypes.put("category", "fileType");
    return fileTypes;
  }
}
