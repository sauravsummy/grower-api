package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

import com.sunsum.constants.Status;
import com.sunsum.model.entity.Project;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.ProjectRepository;
import com.sunsum.util.ExcelUtils;
import java.io.ByteArrayInputStream;
import java.util.Arrays;
import java.util.List;
import org.apache.poi.ss.usermodel.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

class ProjectDataDownloadImplTest {

  @Mock private ProjectRepository projectRepository;

  @InjectMocks private ProjectDataDownloadImpl projectDataDownloader;

  @Mock private ExcelUtils excelUtils;

  private List<Project> mockProjects;

  @InjectMocks private ProjectDataDownloadImpl projectDataDownload;
  @Mock private Logger log;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    Project project1 = createMockProject(1L, "Project 1", "Area 1", 2022, "Active");
    Project project2 = createMockProject(2L, "Project 2", "Area 2", 2023, "Inactive");

    mockProjects = Arrays.asList(project1, project2);
  }

  private Project createMockProject(
      Long id, String title, String area, Integer year, String status) {
    Project project = new Project();
    project.setId(id);
    project.setTitle(title);
    project.setArea(area);
    project.setYear(year);
    project.setStatus(Status.fromString(status));

    UserProfile owner = new UserProfile();
    owner.setEmail("owner@example.com");
    project.setOwner(owner);

    return project;
  }

  @Test
  void givenProjectsExist_whenPrepareSheet_thenSheetIsPrepared() {
    // given
    given(projectRepository.findAllByOrderByIdAsc()).willReturn(mockProjects);

    // when
    projectDataDownloader.fetch();
    projectDataDownloader.prepareSheet("columns", "mandatoryColumns");

    // then
    verify(excelUtils, times(22)).createCell(any(Row.class), anyInt(), any(), any());
  }

  @Test
  void givenExceptionInRowCreation_whenPrepareSheet_thenExceptionIsLogged() {
    // given
    List<Project> mockProjects = Arrays.asList(new Project(), new Project());
    given(projectRepository.findAllByOrderByIdAsc()).willReturn(mockProjects);

    projectDataDownloader.fetch();
    doThrow(new RuntimeException("Simulated error"))
        .when(excelUtils)
        .createCell(any(), anyInt(), any(), any());

    // when
    ByteArrayInputStream result = projectDataDownloader.prepareSheet("columns", "mandatoryColumns");

    // then
    assertNotNull(result);
    verify(excelUtils, times(mockProjects.size())).createCell(any(), anyInt(), any(), any());
  }

  @Test
  void givenProject_whenPrepareSheet_thenShouldHandleException() {
    // given
    when(projectRepository.findAllByOrderByIdAsc()).thenReturn(mock(List.class));
    doThrow(new RuntimeException("Test exception"))
        .when(excelUtils)
        .writeHeaderRow(anyString(), anyString(), any(), any());

    // when & then
    projectDataDownload.fetch();
    assertThrows(
        RuntimeException.class,
        () -> {
          projectDataDownload.prepareSheet("columns", "mandatoryColumns");
        });
  }
}
