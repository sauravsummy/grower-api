package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.BDDMockito.given;

import com.sunsum.constants.UserRole;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.FarmHolding;
import com.sunsum.model.dto.FarmHoldingResponse;
import com.sunsum.model.dto.TaskCounts;
import com.sunsum.model.dto.UserDetails;
import com.sunsum.model.dto.UserSubDetails;
import com.sunsum.model.entity.Field;
import com.sunsum.model.entity.Role;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.FieldRepository;
import com.sunsum.repository.OrganisationRepository;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.util.CommonUtils;
import java.util.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.context.SecurityContext;

@ExtendWith(MockitoExtension.class)
class FarmHoldingServiceImplTest {

  @Spy private UserProfileRepository userProfileRepository;

  @Mock private CommonUtils commonUtils;

  @Mock private OrganisationRepository organisationRepository;

  @InjectMocks private FarmHoldingServiceImpl farmHoldingService;

  @Mock private TaskServiceImpl taskService;

  private SecurityContext securityContext;

  @Test
  void givenProjectAdmin_whenFarmHoldingsForUser_thenReturnsFarmHoldings() {
    // given
    long userId = 1L;
    UserProfile userProfile = createUserProfileWithRole(UserRole.ROLE_PROJECT_ADMIN);
    UserDetails userDetails =
        new UserDetails(userProfile.getId(), userProfile.getName(), userProfile.getRoles());
    given(commonUtils.getCurrentLoggedInUserDetails()).willReturn(userDetails);
    given(organisationRepository.findByProjectAdmin(userId)).willReturn(createFarmHoldings());

    // when
    FarmHoldingResponse farmHoldingResponse = farmHoldingService.getFarmHoldingsForUser();

    // then
    assertNotNull(farmHoldingResponse);
    assertEquals(
        createFarmHoldings().size(),
        Objects.requireNonNull(farmHoldingResponse).getFarmHoldings().size());
  }

  @Test
  void givenFieldSupporter_whenGetFarmHoldingsForUser_thenReturnsFarmHoldings() {
    // given
    long userId = 1L;
    UserProfile userProfile = createUserProfileWithRole(UserRole.ROLE_FIELD_SUPPORTER);
    UserDetails userDetails =
        new UserDetails(userProfile.getId(), userProfile.getName(), userProfile.getRoles());
    given(commonUtils.getCurrentLoggedInUserDetails()).willReturn(userDetails);
    given(organisationRepository.findByFieldSupporter(userId)).willReturn(createFarmHoldings());

    // when
    FarmHoldingResponse farmHoldingResponse = farmHoldingService.getFarmHoldingsForUser();

    // then
    assertNotNull(farmHoldingResponse);
    assertEquals(
        createFarmHoldings().size(),
        Objects.requireNonNull(farmHoldingResponse).getFarmHoldings().size());
  }

  @Test
  void givenFieldManager_whenGetFarmHoldingsForUser_thenReturnsFarmHoldings() {
    // given
    long userId = 1L;
    UserProfile userProfile = createUserProfileWithRole(UserRole.ROLE_FIELD_MANAGER);
    UserDetails userDetails =
        new UserDetails(userProfile.getId(), userProfile.getName(), userProfile.getRoles());
    given(commonUtils.getCurrentLoggedInUserDetails()).willReturn(userDetails);
    given(organisationRepository.findByFieldManager(userId)).willReturn(createFarmHoldings());

    // when
    FarmHoldingResponse farmHoldingResponse = farmHoldingService.getFarmHoldingsForUser();

    // then
    assertNotNull(farmHoldingResponse);
    assertEquals(
        createFarmHoldings().size(),
        Objects.requireNonNull(farmHoldingResponse).getFarmHoldings().size());
  }

  @Test
  void givenInvalidUser_whenGetFarmHoldingsForUser_thenThrowsException() {
    // given
    long userId = 1L;
    given(commonUtils.getCurrentLoggedInUserDetails()).willThrow(new NullPointerException());

    // when
    Executable executable = () -> farmHoldingService.getFarmHoldingsForUser();

    // then
    assertThrows(BusinessRuleException.class, executable);
  }

  @Test
  void givenUserAsProjectAdmin_whenCheckUserPermissionForFarm_thenShouldReturnTrue() {

    // given
    UserProfile userProfile = createUserProfileWithRole(UserRole.ROLE_PROJECT_ADMIN);
    UserDetails userDetails =
        new UserDetails(userProfile.getId(), userProfile.getName(), userProfile.getRoles());
    given(commonUtils.getCurrentLoggedInUserDetails()).willReturn(userDetails);
    given(organisationRepository.findByProjectAdmin(userProfile.getId()))
        .willReturn(getMockFarmHoldings());

    // when
    boolean isUserBelongsToFarm = farmHoldingService.hasUserPermissionForFarmHolding(1L);

    // then
    assertTrue(isUserBelongsToFarm);
  }

  @Test
  void givenUserAsFieldSupporter_whenCheckUserPermissionForFarm_thenShouldReturnTrue() {

    // given
    UserProfile userProfile = createUserProfileWithRole(UserRole.ROLE_FIELD_SUPPORTER);
    UserDetails userDetails =
        new UserDetails(userProfile.getId(), userProfile.getName(), userProfile.getRoles());
    given(commonUtils.getCurrentLoggedInUserDetails()).willReturn(userDetails);
    given(organisationRepository.findByFieldSupporter(userProfile.getId()))
        .willReturn(getMockFarmHoldings());

    // when
    boolean isUserBelongsToFarm = farmHoldingService.hasUserPermissionForFarmHolding(1L);

    // then
    assertTrue(isUserBelongsToFarm);
  }

  @Test
  void givenUserAsFieldManager_whenCheckUserPermissionForFarm_thenShouldReturnTrue() {

    // given
    UserProfile userProfile = createUserProfileWithRole(UserRole.ROLE_FIELD_MANAGER);
    UserDetails userDetails =
        new UserDetails(userProfile.getId(), userProfile.getName(), userProfile.getRoles());
    given(commonUtils.getCurrentLoggedInUserDetails()).willReturn(userDetails);
    given(organisationRepository.findByFieldManager(userProfile.getId()))
        .willReturn(getMockFarmHoldings());

    // when
    boolean isUserBelongsToFarm = farmHoldingService.hasUserPermissionForFarmHolding(1L);

    // then
    assertTrue(isUserBelongsToFarm);
  }

  @Test
  void givenUnAuthorizedUser_whenCheckUserPermissionForFarm_thenShouldReturnFalse() {

    // given
    UserProfile userProfile = createUserProfileWithRole(UserRole.ROLE_FIELD_MANAGER);
    UserDetails userDetails =
        new UserDetails(userProfile.getId(), userProfile.getName(), userProfile.getRoles());
    given(commonUtils.getCurrentLoggedInUserDetails()).willReturn(userDetails);
    given(organisationRepository.findByFieldManager(userProfile.getId()))
        .willReturn(getMockFarmHoldings());

    // when
    boolean isUserBelongsToFarm = farmHoldingService.hasUserPermissionForFarmHolding(3L);

    // then
    assertFalse(isUserBelongsToFarm);
  }

  private UserProfile createUserProfileWithRole(UserRole role) {
    UserProfile userProfile = new UserProfile();
    userProfile.setId(1L);
    userProfile.setName("TestUser");
    userProfile.setRoles(Collections.singleton(new Role(1L, role, null)));
    return userProfile;
  }

  private List<FarmHolding> createFarmHoldings() {
    FarmHolding farmHolding1 =
        new FarmHolding() {
          @Override
          public Long getId() {
            return 1L;
          }

          @Override
          public String getTitle() {
            return "Farm Holding 1";
          }
        };

    FarmHolding farmHolding2 =
        new FarmHolding() {
          @Override
          public Long getId() {
            return 2L;
          }

          @Override
          public String getTitle() {
            return "Farm Holding 2";
          }
        };

    return Arrays.asList(farmHolding1, farmHolding2);
  }

  private List<FarmHolding> getMockFarmHoldings() {
    FarmHolding farmHolding =
        new FarmHolding() {
          @Override
          public Long getId() {
            return 1L;
          }

          @Override
          public String getTitle() {
            return "Test-FarmHolding";
          }
        };
    return List.of(farmHolding);
  }

  @Mock private FieldRepository fieldRepository;

  @Spy private ModelMapper modelMapper;

  @Test
  void
      givenActiveUserProfiles_whenGetCountOfUpcomingInTwoDaysAndOverdueTasks_thenReturnsTaskCountsForEachUser() {
    // given

    given(userProfileRepository.findAllByIsActive(Boolean.TRUE)).willReturn(getUserProfiles());

    List<FarmHolding> farmHoldingsForUser1 = createFarmHoldings();
    given(organisationRepository.findByProjectAdmin(1L)).willReturn(farmHoldingsForUser1);

    FarmHolding farmHolding = createFarmHolding();
    List<Field> mockFields = createMockFields();
    given(fieldRepository.findByFarmHoldingId(farmHolding.getId())).willReturn(mockFields);

    // when
    Map<UserSubDetails, Map<Long, Map<Long, TaskCounts>>> result =
        farmHoldingService.getCountOfUpcomingInTwoDaysAndOverdueTasks();

    // then
    assertNotNull(result);
    assertEquals(4, result.size());
  }

  private List<UserProfile> getUserProfiles() {
    UserProfile userProfile1 =
        getUserProfile(1L, "user1@gmail.com", "User 1", UserRole.ROLE_PROJECT_ADMIN);

    UserProfile userProfile2 =
        getUserProfile(2L, "user2@gmail.com", "User 2", UserRole.ROLE_FIELD_SUPPORTER);

    UserProfile userProfile3 =
        getUserProfile(3L, "user3@gmail.com", "User 3", UserRole.ROLE_FIELD_MANAGER);

    UserProfile userProfile4 = getUserProfile(4L, "user4@gmail.com", "User 4", UserRole.ROLE_USER);

    return List.of(userProfile1, userProfile2, userProfile3, userProfile4);
  }

  private UserProfile getUserProfile(Long id, String email, String name, UserRole userRole) {
    return UserProfile.builder()
        .id(id)
        .email(email)
        .name(name)
        .roles(Collections.singleton(new Role(1L, userRole, null)))
        .build();
  }

  private FarmHolding createFarmHolding() {
    FarmHolding farmHolding =
        new FarmHolding() {
          @Override
          public Long getId() {
            return 1L;
          }

          @Override
          public String getTitle() {
            return "Farm Holding 1";
          }
        };

    return farmHolding;
  }

  private List<Field> createMockFields() {
    Field field1 =
        new Field() {
          @Override
          public Long getId() {
            return 1L;
          }
        };

    Field field2 =
        new Field() {
          @Override
          public Long getId() {
            return 2L;
          }
        };

    return Arrays.asList(field1, field2);
  }
}
