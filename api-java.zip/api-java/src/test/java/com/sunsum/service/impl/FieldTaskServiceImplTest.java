package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;

import com.sunsum.constants.TaskFieldStatus;
import com.sunsum.constants.TaskRelation;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.FieldTaskDetails;
import com.sunsum.model.dto.FieldTasksStatus;
import com.sunsum.model.dto.FieldsTaskInfo;
import com.sunsum.model.entity.Field;
import com.sunsum.model.entity.Task;
import com.sunsum.model.entity.TaskField;
import com.sunsum.repository.FieldRepository;
import com.sunsum.repository.TaskFieldRepository;
import com.sunsum.util.DateUtil;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.data.geo.Point;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
class FieldTaskServiceImplTest {

  @Mock
  FieldRepository fieldRepository;

  @Mock
  TaskFieldRepository taskFieldRepository;

  @InjectMocks FieldTaskServiceImpl fieldTaskService;

  @Test
  void givenValidField_whenAllTask_thenShouldReturnAllTask() {

    // given
    List<TaskField> taskFields = getTaskField();
    given(fieldRepository.findIdByFarmHoldingId(1L)).willReturn(List.of(1L, 2L));
    given(taskFieldRepository.findFieldAndTasksByFieldIdIn(List.of(1L, 2L)))
        .willReturn(getMockFieldTaskDetails());
    given(taskFieldRepository.findByFieldIdIn(List.of(1L, 2L))).willReturn(taskFields);

    // when
    List<FieldTasksStatus> fieldTasksStatuses = fieldTaskService.getAllFieldsTask(1L);
    List<FieldsTaskInfo> fieldsTaskInfo = fieldTasksStatuses.get(1).getTaskStatus();

    // then
    assertNotNull(fieldTasksStatuses);
    assertEquals(2, fieldTasksStatuses.size());
    assertEquals(5, fieldsTaskInfo.size());
  }

  @Test
  void givenValidField_whenGetUpComingTask_thenShouldReturnUpComingTask() {

    // given
    List<TaskField> taskFields = getTaskField();
    given(fieldRepository.findIdByFarmHoldingId(1L)).willReturn(List.of(1L, 2L));
    given(taskFieldRepository.findFieldAndTasksByFieldIdIn(List.of(1L, 2L)))
        .willReturn(getMockFieldTaskDetails());
    given(taskFieldRepository.findByFieldIdIn(List.of(1L, 2L))).willReturn(taskFields);

    // when
    List<FieldTasksStatus> fieldTasksStatuses = fieldTaskService.getUpcomingFieldTasks(1L);
    List<FieldsTaskInfo> fieldsTaskInfo = fieldTasksStatuses.get(0).getTaskStatus();

    // then
    assertNotNull(fieldTasksStatuses);
    assertEquals(2, fieldTasksStatuses.size());
    assertEquals(3, fieldsTaskInfo.size());
    assertTrue(fieldsTaskInfo.stream().noneMatch(it -> it.getStatus().equals("completed")));
  }

  @Test
  void givenFieldWithAllCompletedTask_whenGetUpComingTask_thenShouldReturnEmptyFieldTask() {

    // given
    List<TaskField> taskFields = getTaskField();
    List<FieldTaskDetails> fieldTaskDetails =
        getMockFieldTaskDetails().stream().filter(it -> it.getFieldId().equals(1L)).toList();
    taskFields.forEach(
        it -> {
          it.setCompletionDate(LocalDate.now());
          it.setTaskStatus(TaskFieldStatus.COMPLETED);
        });
    given(fieldRepository.findIdByFarmHoldingId(1L)).willReturn(List.of(1L));
    given(taskFieldRepository.findFieldAndTasksByFieldIdIn(List.of(1L)))
        .willReturn(fieldTaskDetails);
    given(taskFieldRepository.findByFieldIdIn(List.of(1L))).willReturn(taskFields);

    // when
    List<FieldTasksStatus> fieldTasksStatuses = fieldTaskService.getUpcomingFieldTasks(1L);

    // then
    assertNotNull(fieldTasksStatuses);
    assertEquals(0, fieldTasksStatuses.size());
  }

  private List<TaskField> getTaskField() {

    Field field = new Field();
    field.setId(1L);
    field.setTitle("Test_Field-1");
    field.setGpsCoordinates(new Point(1.11, 2.23));

    TaskField taskField1 = getTaskField(field, getInitialTask(), 7);
    taskField1.setCompletionDate(LocalDate.now().minusDays(1));
    taskField1.setTaskStatus(TaskFieldStatus.COMPLETED);
    TaskField taskField2 = getTaskField(field, getTaskWithDueDate(), 8);
    TaskField taskField3 = getTaskField(field, getTaskWithRelationFollow(getInitialTask()), 8);
    TaskField taskField4 = getTaskField(field, getTaskWithRelationBlockedBy(getInitialTask()), 9);
    TaskField taskField5 = getTaskField(field, getTaskWithRelationWithin(getInitialTask()), 10);
    TaskField taskField6 = getTaskField(field, getTaskWithRelationNone(), 1);
    taskField6.setCompletionDate(LocalDate.now());
    taskField6.setTaskStatus(TaskFieldStatus.COMPLETED);

    return List.of(taskField1, taskField2, taskField3, taskField4, taskField5, taskField6);
  }

  private TaskField getTaskField(Field field1, Task task, Integer executionDays) {
    TaskField taskField1 = new TaskField();
    taskField1.setField(field1);
    taskField1.setTask(task);
    if (executionDays == null) {
      taskField1.setExecutableDate(DateUtil.MIN_DATE);
    } else {
      taskField1.setExecutableDate(LocalDate.now().plusDays(executionDays));
    }
    return taskField1;
  }

  private FieldTaskDetails getMockFieldTaskDetails(Task task, Long fieldId, String fieldTitle) {
    return new FieldTaskDetails() {
      @Override
      public Task getTask() {
        return task;
      }

      @Override
      public Long getFieldId() {
        return fieldId;
      }

      @Override
      public Point getGps() {
        return new Point(1.11, 2.23);
      }

      @Override
      public String getFieldTitle() {
        return fieldTitle;
      }
    };
  }

  private List<FieldTaskDetails> getMockFieldTaskDetails() {
    Task task1 = getInitialTask();
    Task task2 = getTaskWithDueDate();
    Task task3 = getTaskWithRelationFollow(task1);
    Task task4 = getTaskWithRelationBlockedBy(task1);
    Task task5 = getTaskWithRelationNone();
    return List.of(
        getMockFieldTaskDetails(task1, 1L, "Test_Field-1"),
        getMockFieldTaskDetails(task2, 1L, "Test_Field-1"),
        getMockFieldTaskDetails(task3, 1L, "Test_Field-1"),
        getMockFieldTaskDetails(task4, 1L, "Test_Field-1"),
        getMockFieldTaskDetails(task5, 1L, "Test_Field-1"),
        getMockFieldTaskDetails(task1, 2L, "Test_Field-2"),
        getMockFieldTaskDetails(task2, 2L, "Test_Field-2"),
        getMockFieldTaskDetails(task3, 2L, "Test_Field-2"),
        getMockFieldTaskDetails(task4, 2L, "Test_Field-2"),
        getMockFieldTaskDetails(task5, 2L, "Test_Field-2"));
  }

  private Task getTaskWithRelationBlockedBy(Task initialTask) {
    Task task = new Task();
    task.setId(6L);
    task.setTitle("Test-Task-6");
    task.setOrder(6);
    task.setRelatedTask(initialTask);
    task.setRelation(TaskRelation.BLOCKED_BY);
    return task;
  }

  private Task getTaskWithRelationWithin(Task initialTask) {
    Task task = new Task();
    task.setId(5L);
    task.setTitle("Test-Task-5");
    task.setOrder(5);
    task.setRelatedTask(initialTask);
    task.setRelation(TaskRelation.WITH_IN);
    task.setRelatedDays(3);
    return task;
  }

  private Task getTaskWithRelationFollow(Task initialTask) {
    Task task = new Task();
    task.setId(4L);
    task.setTitle("Test-Task-4");
    task.setOrder(4);
    task.setRelatedTask(initialTask);
    task.setRelation(TaskRelation.FOLLOW);
    task.setRelatedDays(4);
    return task;
  }

  private Task getTaskWithDueDate() {
    Task task = new Task();
    task.setId(2L);
    task.setTitle("Test-Task-2");
    task.setOrder(2);
    task.setFixedDueDate(LocalDate.now().plusDays(4));
    return task;
  }

  private Task getTaskWithRelationNone() {
    Task task = new Task();
    task.setId(3L);
    task.setTitle("Test-Task-3");
    task.setRelation(TaskRelation.NONE);
    task.setOrder(3);
    return task;
  }

  private Task getInitialTask() {
    Task task = new Task();
    task.setId(1L);
    task.setTitle("Test-Task-1");
    task.setOrder(1);
    return task;
  }

  @Test
  void givenFarmHolding_WhenGettingAllTasks_thenShouldThrowBusinessRuleException() {

    // given
    given(fieldRepository.findIdByFarmHoldingId(anyLong())).willReturn(List.of(1L, 2L));
    given(taskFieldRepository.findFieldAndTasksByFieldIdIn(List.of(1L, 2L)))
        .willThrow(new RuntimeException("Simulated error"));

    // when
    Throwable exception =
        assertThrows(BusinessRuleException.class, () -> fieldTaskService.getAllFieldsTask(1L));

    // then
    // assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, exception.getStatus());
    assertEquals("error occurred while getting tasks for farmholding", exception.getMessage());
  }

  @Test
  void givenFarmHolding_WhenGettingUpcomingTasks_thenShouldThrowBusinessRuleException() {

    // given
    given(fieldRepository.findIdByFarmHoldingId(anyLong())).willReturn(List.of(1L, 2L));
    given(taskFieldRepository.findFieldAndTasksByFieldIdIn(List.of(1L, 2L)))
        .willThrow(new RuntimeException("Simulated error"));

    // when
    BusinessRuleException exception =
        assertThrows(BusinessRuleException.class, () -> fieldTaskService.getUpcomingFieldTasks(1L));

    // then
    assertEquals("error occurred while getting tasks for farmholding", exception.getMessage());
  }
}
