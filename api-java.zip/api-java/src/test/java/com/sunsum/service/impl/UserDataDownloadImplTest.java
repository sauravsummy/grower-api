package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

import com.sunsum.constants.UserRole;
import com.sunsum.model.entity.Organization;
import com.sunsum.model.entity.Role;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.util.ExcelUtils;
import java.io.ByteArrayInputStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

class UserDataDownloadImplTest {

  @Mock private UserProfileRepository userProfileRepository;

  @InjectMocks private UserDataDownloadImpl userDataDownloader;

  private List<UserProfile> mockUserProfiles;
  @Mock private Logger log;

  @Mock private ExcelUtils excelUtils;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    Role role1 = Role.builder().id(1L).name(UserRole.ROLE_PROJECT_ADMIN).build();

    Role role2 = Role.builder().id(2L).name(UserRole.ROLE_FIELD_SUPPORTER).build();

    UserProfile user1 =
        UserProfile.builder()
            .id(1L)
            .name("first")
            .email("first@gmail.com")
            .phoneNo(1234567890L)
            .roles(new HashSet<>(Arrays.asList(role1, role2)))
            .isActive(true)
            .organization(createMockOrganization(1L))
            .memo1("Memo1")
            .memo2("Memo2")
            .memo3("Memo3")
            .memo4("Memo4")
            .memo5("Memo5")
            .build();

    UserProfile user2 =
        UserProfile.builder()
            .id(2L)
            .name("second")
            .email("second@gmail.com")
            .phoneNo(9876543210L)
            .roles(new HashSet<>(Arrays.asList(role2)))
            .isActive(false)
            .organization(createMockOrganization(2L))
            .memo1("Memo1")
            .memo2("Memo2")
            .memo3("Memo3")
            .memo4("Memo4")
            .memo5("Memo5")
            .build();

    mockUserProfiles = Arrays.asList(user1, user2);
  }

  private Organization createMockOrganization(Long id) {
    Organization organization = new Organization();
    organization.setId(id);
    return organization;
  }

  @Test
  void givenUserProfilesExist_whenPrepareSheet_thenSheetIsPrepared() {
    // given
    UserProfile userProfile = createMockUserProfile();
    given(userProfileRepository.findAllByOrderByIdAsc())
        .willReturn(Collections.singletonList(userProfile));

    // when
    userDataDownloader.fetch();
    userDataDownloader.prepareSheet("columns", "mandatoryColumns");

    // then
    verify(excelUtils, times(3)).createCell(any(), anyInt(), any(), any(), any(), any());
  }

  private UserProfile createMockUserProfile() {
    UserProfile userProfile = new UserProfile();
    userProfile.setId(1L);
    userProfile.setName("Test User");
    userProfile.setEmail("test@example.com");
    userProfile.setPhoneNo(1234567890L);
    userProfile.setRoles(new HashSet<>(Collections.singleton(createMockRole())));
    userProfile.setIsActive(true);
    userProfile.setOrganization(createMockOrganization(1L));
    userProfile.setMemo1("Memo1");
    userProfile.setMemo2("Memo2");
    userProfile.setMemo3("Memo3");
    userProfile.setMemo4("Memo4");
    userProfile.setMemo5("Memo5");
    return userProfile;
  }

  private Role createMockRole() {
    Role role = new Role();
    role.setId(1L);
    role.setName(UserRole.ROLE_USER);
    return role;
  }

  @Test
  void givenUserProfile_whenPrepareSheet_thenRuntimeExceptionIsThrown() {
    // given
    UserProfile userProfile = createMockUserProfile();
    given(userProfileRepository.findAllByOrderByIdAsc())
        .willReturn(Collections.singletonList(userProfile));

    doThrow(new RuntimeException("Test exception"))
        .when(excelUtils)
        .writeHeaderRow(any(), any(), any(), any());

    // when
    userDataDownloader.fetch();

    // then
    assertThrows(
        RuntimeException.class,
        () -> userDataDownloader.prepareSheet("columns", "mandatoryColumns"));
  }

  @Test
  void givenUserProfile_whenWriteDataRows_thenRuntimeExceptionIsThrown() {
    // given
    List<UserProfile> mockUserProfiles = Arrays.asList(new UserProfile(), new UserProfile());
    given(userProfileRepository.findAllByOrderByIdAsc()).willReturn(mockUserProfiles);
    userDataDownloader.fetch();

    doThrow(new RuntimeException("Test exception"))
        .when(excelUtils)
        .createCell(any(), anyInt(), any(), any(), any(), any());

    // when
    ByteArrayInputStream result = userDataDownloader.prepareSheet("columns", "mandatoryColumns");

    // then
    assertNotNull(result);
  }
}
