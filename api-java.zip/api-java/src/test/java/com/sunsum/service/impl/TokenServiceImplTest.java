package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

import com.sunsum.model.entity.Token;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.TokenRepository;
import com.sunsum.util.RisocareCommonUtils;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TokenServiceImplTest {

  private TokenServiceImpl tokenService;
  private TokenRepository tokenRepository;

  @BeforeEach
  void setUp() {
    tokenRepository = mock(TokenRepository.class);
    tokenService = new TokenServiceImpl(tokenRepository);
  }

  @Test
  void givenInvalidToken_whenLogoff_thenExpectTrue() {
    // Arrange
    String nonExistentTokenString = "invalid_token";
    when(tokenRepository.findByValue(RisocareCommonUtils.hashString(nonExistentTokenString)))
        .thenReturn(Optional.empty());

    // Act
    boolean result = tokenService.logoff(nonExistentTokenString);

    // Assert
    assertTrue(result);
    verify(tokenRepository, never()).delete(any(Token.class));
  }

  @Test
  void givenToken_whenSave_thenTokenIsSaved() {
    // Arrange
    Token token = new Token();

    // Act
    tokenService.save(token);

    // Assert
    verify(tokenRepository, times(1)).save(token);
  }

  @Test
  void givenUserProfileExists_whenFindByUserProfile_thenReturnToken() {
    // given
    UserProfile userProfile = new UserProfile();
    Token expectedToken = new Token();
    given(tokenRepository.findByUserProfile(any())).willReturn(List.of(expectedToken));

    // when
    List<Token> actualToken = tokenService.findByUserProfile(userProfile);

    // then
    assertEquals(expectedToken, actualToken.get(0));
  }

  @Test
  void givenUserProfileNotExists_whenFindByUserProfile_thenReturnNull() {
    // given
    UserProfile userProfile = new UserProfile();
    given(tokenRepository.findByUserProfile(any())).willReturn(List.of());

    // when
    List<Token> actualToken = tokenService.findByUserProfile(userProfile);

    // then
    assertEquals(0, actualToken.size());
  }

  @Test
  void givenTokenExists_whenFindByToken_thenReturnToken() {
    // given
    String tokenString = "exampleToken";
    Token expectedToken = new Token();
    given(tokenRepository.findByValue(any())).willReturn(Optional.of(expectedToken));

    // when
    Optional<Token> actualToken = tokenService.findByToken(tokenString);

    // then
    assertEquals(Optional.of(expectedToken), actualToken);
  }

  @Test
  void givenTokenNotExists_whenFindByToken_thenReturnEmptyOptional() {
    // given
    String tokenString = "nonExistentToken";
    given(tokenRepository.findByValue(any())).willReturn(Optional.empty());

    // when
    Optional<Token> actualToken = tokenService.findByToken(tokenString);

    // then
    Assertions.assertTrue(actualToken.isEmpty());
  }
}
