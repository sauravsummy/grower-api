package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

import com.sunsum.constants.Status;
import com.sunsum.model.entity.Project;
import com.sunsum.model.entity.TaskGroup;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.TaskGroupRepository;
import com.sunsum.util.ExcelUtils;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class TaskGroupDownloadImplTest {

  @Mock private TaskGroupRepository taskGroupRepository;

  @InjectMocks private TaskGroupDownloadImpl taskGroupDownloader;

  @Mock private ExcelUtils excelUtils;

  private List<TaskGroup> mockTaskGroups;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    TaskGroup taskGroup1 = createMockTaskGroup(1L, "TaskGroup 1", Status.ACTIVE, true, 1);
    TaskGroup taskGroup2 = createMockTaskGroup(2L, "TaskGroup 2", Status.INACTIVE, false, 2);

    mockTaskGroups = Arrays.asList(taskGroup1, taskGroup2);
  }

  private TaskGroup createMockTaskGroup(
      Long id, String title, Status status, boolean isLocked, int order) {
    TaskGroup taskGroup = new TaskGroup();
    taskGroup.setId(id);
    taskGroup.setTitle(title);
    taskGroup.setStatus(status);
    taskGroup.setIsLocked(isLocked);
    taskGroup.setOrder(order);

    taskGroup.setTaskGroupOwner(new UserProfile());

    taskGroup.setProject(new Project());

    return taskGroup;
  }

  @Test
  void givenTaskGroupsExist_whenPrepareSheet_thenSheetIsPrepared() {
    // given
    given(taskGroupRepository.findAllByOrderByIdAsc()).willReturn(mockTaskGroups);

    // when
    taskGroupDownloader.fetch();
    taskGroupDownloader.prepareSheet("columns", "mandatoryColumns");

    // then
    verify(excelUtils, times(1))
        .writeHeaderRow(eq("columns"), eq("mandatoryColumns"), any(XSSFWorkbook.class), any());
    verify(excelUtils, times(26)).createCell(any(Row.class), anyInt(), any(), any());
  }

  @Test
  void givenData_WhenWriteDataRows_thenLogErrorAndContinue() {
    // given
    given(taskGroupRepository.findAllByOrderByIdAsc()).willReturn(mockTaskGroups);
    doThrow(new RuntimeException("Test Exception"))
        .when(excelUtils)
        .createCell(any(Row.class), anyInt(), any(), any());

    // when
    taskGroupDownloader.fetch();
    taskGroupDownloader.prepareSheet("columns", "mandatoryColumns");

    // then
    verify(excelUtils, times(1))
        .writeHeaderRow(eq("columns"), eq("mandatoryColumns"), any(XSSFWorkbook.class), any());
  }

  @Test
  void givenTaskGroups_WhenPrepareSheet_thenException() throws IOException {
    given(taskGroupRepository.findAllByOrderByIdAsc()).willReturn(mock(List.class));

    Workbook mockWorkbook = mock(Workbook.class);
    given(mockWorkbook.createSheet(any())).willThrow(new RuntimeException("Test Exception"));

    TaskGroupDownloadImpl spyTaskDataDownload = spy(taskGroupDownloader);

    assertThrows(
        RuntimeException.class,
        () -> spyTaskDataDownload.prepareSheet("columns", "mandatoryColumns"));
  }
}
