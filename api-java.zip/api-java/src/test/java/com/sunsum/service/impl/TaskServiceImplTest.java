package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;

import com.sunsum.constants.AppConstants;
import com.sunsum.constants.TaskFieldStatus;
import com.sunsum.constants.TaskRelation;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.FieldTaskDetails;
import com.sunsum.model.dto.TaskStatus;
import com.sunsum.model.dto.TaskStatusResponse;
import com.sunsum.model.dto.TaskStatusUpdateRequest;
import com.sunsum.model.dto.TaskView;
import com.sunsum.model.entity.Field;
import com.sunsum.model.entity.Task;
import com.sunsum.model.entity.TaskField;
import com.sunsum.repository.FieldRepository;
import com.sunsum.repository.TaskFieldRepository;
import com.sunsum.repository.TaskRepository;
import com.sunsum.util.DateUtil;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.data.geo.Point;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
class TaskServiceImplTest {

  @Mock
  FieldRepository fieldRepository;
  @Mock
  TaskRepository taskRepository;

  @Mock
  TaskFieldRepository taskFieldRepository;

  @Mock S3ServiceImpl s3Service;

  @Captor ArgumentCaptor<TaskField> taskFieldArgumentCaptor;

  @InjectMocks TaskServiceImpl taskService;

  @Test
  void givenValidField_whenGetAllTask_thenShouldReturnAllTask() {

    // given
    List<Task> tasks = getMockDataForTasks();
    List<TaskField> taskFields = getMockDataForTaskField();
    given(taskRepository.findTasksByFieldId(1L)).willReturn(tasks);
    given(taskFieldRepository.findByFieldId(1L)).willReturn(taskFields);

    // when
    TaskStatusResponse taskStatusResponse = taskService.getAllTasks("1");

    // then
    List<TaskStatus> taskStatus = taskStatusResponse.getTaskStatus();
    assertNotNull(taskStatus);
    assertTrue(taskStatus.size() > 0);
    verifyTaskStatus(taskStatus);
  }

  @Test
  void givenValidField_whenGetUpComingTask_thenShouldReturnUpComingTask() {

    // given
    List<Task> tasks = getMockDataForTasks();
    List<TaskField> taskFields = getMockDataForTaskField();
    given(taskRepository.findTasksByFieldId(1L)).willReturn(tasks);
    given(taskFieldRepository.findByFieldId(1L)).willReturn(taskFields);

    // when
    TaskStatusResponse taskStatusResponse = taskService.getUpcomingTasks("1");

    // then
    List<TaskStatus> taskStatus = taskStatusResponse.getTaskStatus();
    assertNotNull(taskStatus);
    assertEquals(4, taskStatus.size());
  }

  @Test
  void givenFieldWithNoUpcomingTask_whenGetUpComingTask_thenShouldReturnUpComingTask() {

    // given
    List<Task> tasks = getMockDataForTasks();
    List<TaskField> taskFields = getTaskField();
    given(taskRepository.findTasksByFieldId(1L)).willReturn(tasks);
    given(taskFieldRepository.findByFieldId(1L)).willReturn(taskFields);

    // when
    TaskStatusResponse taskStatusResponse = taskService.getUpcomingTasks("1");

    // then
    List<TaskStatus> taskStatus = taskStatusResponse.getTaskStatus();
    assertNotNull(taskStatus);
    assertEquals(4, taskStatus.size());
  }

  @Test
  void givenFieldWithNOExecutableTask_whenGetUpComingTask_thenShouldReturnUpComingTask() {

    // given
    List<Task> tasks = getMockDataForTasks();
    List<TaskField> taskFields = getTaskField();
    taskFields.stream()
        .limit(2)
        .forEach(
            it -> {
              it.setCompletionDate(LocalDate.now());
              it.setTaskStatus(TaskFieldStatus.COMPLETED);
            });

    given(taskRepository.findTasksByFieldId(1L)).willReturn(tasks);
    given(taskFieldRepository.findByFieldId(1L)).willReturn(taskFields);

    // when
    TaskStatusResponse taskStatusResponse = taskService.getUpcomingTasks("1");

    // then
    List<TaskStatus> taskStatus = taskStatusResponse.getTaskStatus();
    assertNotNull(taskStatus);
    assertEquals(3, taskStatus.size());
  }

  @Test
  void givenValidTaskAndFieldId_whenGetTaskView_thenShouldReturnTaskView() {

    // given
    Task task = getInitialTask();
    given(taskRepository.findById(1L)).willReturn(Optional.of(task));
    given(taskFieldRepository.findByTaskIdAndFieldId(1L, 1L)).willReturn(Optional.ofNullable(null));

    // when
    TaskView taskView = taskService.getTaskView(1L, 1L);

    // then
    assertNotNull(taskView);
  }

  @Test
  void givenTaskField_whenGetTaskView_thenShouldReturnTaskView() {

    // given
    Field field1 = new Field();
    field1.setId(1L);
    Task task = getInitialTask();
    Task taskWithRelationFollow = getTaskWithRelationFollow(getInitialTask());
    TaskField taskField = getTaskField(field1, taskWithRelationFollow, 4);
    given(taskRepository.findById(4L)).willReturn(Optional.of(taskWithRelationFollow));
    given(taskFieldRepository.findByTaskIdAndFieldId(4L, 1L)).willReturn(Optional.of(taskField));

    // when
    TaskView taskView = taskService.getTaskView(4L, 1L);

    // then
    assertNotNull(taskView);
  }

  @Test
  void givenUpdateRequest_whenUpdateTaskStatus_thenShouldUpdate() {

    // given
    Field field = new Field();
    field.setId(1L);
    Task task = getInitialTask();
    TaskField taskField = getTaskField(field, task, 4);
    TaskField updatedTaskField = new TaskField();
    updatedTaskField.setTaskStatus(TaskFieldStatus.COMPLETED);
    TaskStatusUpdateRequest updateRequest = getUpdateRequest();
    given(fieldRepository.findById(1L)).willReturn(Optional.of(field));
    given(taskFieldRepository.findByTaskIdAndFieldId(1L, 1L)).willReturn(Optional.of(taskField));
    given(taskFieldRepository.save(taskFieldArgumentCaptor.capture())).willReturn(updatedTaskField);
    willDoNothing()
        .given(s3Service)
        .uploadObject(updateRequest.images().get(0), "task" + AppConstants.FILE_PATH_SEPARATOR + task.getId());

    // when
    String status = taskService.updateTaskStatus(1L, updateRequest);

    // then
    assertNotNull(status);
    assertEquals(TaskFieldStatus.COMPLETED, taskFieldArgumentCaptor.getValue().getTaskStatus());
    assertEquals(2, taskFieldArgumentCaptor.getValue().getCustomInput().size());
  }

  @Test
  void givenUpdateRequestWithAcknowledge_whenUpdateTaskStatus_thenShouldUpdate() {

    // given
    Field field = new Field();
    field.setId(1L);
    Task task = getInitialTask();
    Task taskWithRelationFollow = getTaskWithRelationFollow(task);
    TaskField updatedTaskField = new TaskField();
    updatedTaskField.setTaskStatus(TaskFieldStatus.ACKNOWLEDGED);
    TaskStatusUpdateRequest updateRequest =
        new TaskStatusUpdateRequest(TaskFieldStatus.ACKNOWLEDGED, null, null, 1L, null);
    given(fieldRepository.findById(1L)).willReturn(Optional.of(field));
    given(taskRepository.findById(4L)).willReturn(Optional.of(taskWithRelationFollow));
    given(taskFieldRepository.findByTaskIdAndFieldId(4L, 1L)).willReturn(Optional.ofNullable(null));
    given(taskFieldRepository.save(taskFieldArgumentCaptor.capture())).willReturn(updatedTaskField);

    // when
    String status = taskService.updateTaskStatus(4L, updateRequest);

    // then
    assertNotNull(status);
    assertEquals(TaskFieldStatus.ACKNOWLEDGED, taskFieldArgumentCaptor.getValue().getTaskStatus());
  }

  @Test
  void givenTaskWithOverdueStatus_whenUpdateTaskStatus_thenShouldUpdate() {

    // given
    Field field = new Field();
    field.setId(1L);
    Task task = getTaskWithDueDate();
    TaskField taskField = getTaskField(field, task, 0);
    TaskField updatedTaskField = new TaskField();
    updatedTaskField.setTaskStatus(TaskFieldStatus.ACKNOWLEDGED);
    TaskStatusUpdateRequest updateRequest =
        new TaskStatusUpdateRequest(TaskFieldStatus.ACKNOWLEDGED, null, null, 1L, null);
    given(fieldRepository.findById(1L)).willReturn(Optional.of(field));
    given(taskFieldRepository.findByTaskIdAndFieldId(2L, 1L)).willReturn(Optional.of(taskField));
    given(taskFieldRepository.save(taskFieldArgumentCaptor.capture())).willReturn(updatedTaskField);

    // when
    String status = taskService.updateTaskStatus(2L, updateRequest);

    // then
    assertNotNull(status);
    assertEquals(TaskFieldStatus.ACKNOWLEDGED, taskFieldArgumentCaptor.getValue().getTaskStatus());
    assertEquals(LocalDate.now().plusDays(4), taskFieldArgumentCaptor.getValue().getDueDate());
  }

  @Test
  void givenInvalidUpdateRequest_whenUpdateTaskStatus_thenShouldFail() {

    // given
    Field field = new Field();
    field.setId(1L);
    Task task = getTaskWithDueDate();
    TaskField taskField = getTaskField(field, task, 0);
    TaskField updatedTaskField = new TaskField();
    updatedTaskField.setTaskStatus(TaskFieldStatus.ACKNOWLEDGED);
    TaskStatusUpdateRequest updateRequest =
        new TaskStatusUpdateRequest(TaskFieldStatus.ACKNOWLEDGED, null, null, null, null);
    given(fieldRepository.findById(1L)).willReturn(Optional.of(field));
    given(taskFieldRepository.findByTaskIdAndFieldId(2L, 1L)).willReturn(Optional.of(taskField));
    given(taskFieldRepository.save(taskFieldArgumentCaptor.capture())).willReturn(updatedTaskField);

    // when
    Executable executable = () -> taskService.updateTaskStatus(2L, updateRequest);

    // then
    assertThrows(BusinessRuleException.class, executable);
  }

  private TaskStatusUpdateRequest getUpdateRequest() {
    return new TaskStatusUpdateRequest(
        TaskFieldStatus.COMPLETED,
        "2023/12/06",
        """
            [
              {
                "attributeName": "Report item(single selection)",
                "type": "SINGLE_SELECTION",
                "value": [
                  "Good",
                  "Bad"
                ]
              },
              {
                "attributeName": "Report item (Image option)",
                "type": "PHOTO_ATTACHMENT",
                "value": []
              }
            ]
            """,
        1L,
        List.of(new MockMultipartFile("image", "image.jpg", "jpg", "image".getBytes())));
  }

  private static void verifyTaskStatus(List<TaskStatus> taskStatus) {
    taskStatus.stream()
        .forEach(
            it -> {
              if (it.getTaskId().equals("4")) {
                assertEquals("inexecutable", it.getStatus());
              } else if (it.getTaskId().equals("3")) {
                assertEquals("completed", it.getStatus());
              } else {
                assertEquals("executable", it.getStatus());
              }
            });
  }

  private List<Task> getMockDataForTasks() {

    Task task1 = getInitialTask();
    Task task2 = getTaskWithDueDate();
    Task task3 = getTaskWithRelationNone();
    Task task4 = getTaskWithRelationFollow(task3);
    Task task5 = getTaskWithRelationWithin(task3);
    Task task6 = getTaskWithRelationBlockedBy(task3);

    return List.of(task1, task2, task3, task4, task5, task6);
  }

  private List<TaskField> getMockDataForTaskField() {
    TaskField taskField1 = new TaskField();
    Field field1 = new Field();
    field1.setId(1L);
    taskField1.setField(field1);
    taskField1.setTask(getTaskWithRelationNone());
    taskField1.setCompletionDate(LocalDate.now());
    taskField1.setTaskStatus(TaskFieldStatus.COMPLETED);

    return List.of(taskField1);
  }

  private List<TaskField> getTaskField() {

    Field field1 = new Field();
    field1.setId(1L);

    TaskField taskField1 = getTaskField(field1, getInitialTask(), 7);
    TaskField taskField2 = getTaskField(field1, getTaskWithDueDate(), 8);
    TaskField taskField3 = getTaskField(field1, getTaskWithRelationFollow(getInitialTask()), 8);
    TaskField taskField4 = getTaskField(field1, getTaskWithRelationBlockedBy(getInitialTask()), 9);
    TaskField taskField5 = getTaskField(field1, getTaskWithRelationWithin(getInitialTask()), 10);
    TaskField taskField6 = getTaskField(field1, getTaskWithRelationNone(), 1);
    taskField6.setCompletionDate(LocalDate.now());
    taskField6.setTaskStatus(TaskFieldStatus.COMPLETED);

    return List.of(taskField1, taskField2, taskField3, taskField4, taskField5, taskField6);
  }

  private TaskField getTaskField(Field field1, Task task, Integer executionDays) {
    TaskField taskField1 = new TaskField();
    taskField1.setField(field1);
    taskField1.setTask(task);
    if (executionDays == null) {
      taskField1.setExecutableDate(DateUtil.MIN_DATE);
    } else {
      taskField1.setExecutableDate(LocalDate.now().plusDays(executionDays));
    }
    return taskField1;
  }

  private FieldTaskDetails getMockFieldTaskDetails(Task task, Long fieldId, String fieldTitle) {
    return new FieldTaskDetails() {
      @Override
      public Task getTask() {
        return task;
      }

      @Override
      public Long getFieldId() {
        return fieldId;
      }

      @Override
      public Point getGps() {
        return new Point(1.11, 2.23);
      }

      @Override
      public String getFieldTitle() {
        return fieldTitle;
      }
    };
  }

  private Task getTaskWithRelationBlockedBy(Task initialTask) {
    Task task = new Task();
    task.setId(6L);
    task.setTitle("Test-Task-6");
    task.setOrder(6);
    task.setRelatedTask(initialTask);
    task.setRelation(TaskRelation.BLOCKED_BY);
    return task;
  }

  private Task getTaskWithRelationWithin(Task initialTask) {
    Task task = new Task();
    task.setId(5L);
    task.setTitle("Test-Task-5");
    task.setOrder(5);
    task.setRelatedTask(initialTask);
    task.setRelation(TaskRelation.WITH_IN);
    task.setRelatedDays(3);
    return task;
  }

  private Task getTaskWithRelationFollow(Task initialTask) {
    Task task = new Task();
    task.setId(4L);
    task.setTitle("Test-Task-4");
    task.setOrder(4);
    task.setRelatedTask(initialTask);
    task.setRelation(TaskRelation.FOLLOW);
    task.setRelatedDays(4);
    return task;
  }

  private Task getTaskWithDueDate() {
    Task task = new Task();
    task.setId(2L);
    task.setTitle("Test-Task-2");
    task.setOrder(2);
    task.setFixedDueDate(LocalDate.now().plusDays(4));
    return task;
  }

  private Task getTaskWithRelationNone() {
    Task task = new Task();
    task.setId(3L);
    task.setTitle("Test-Task-3");
    task.setRelation(TaskRelation.NONE);
    task.setOrder(3);
    return task;
  }

  private Task getInitialTask() {
    Task task = new Task();
    task.setId(1L);
    task.setTitle("Test-Task-1");
    task.setOrder(1);
    return task;
  }

  @Test
  void givenFieldId_whenGetAllTasks_thenShouldThrowBusinessRuleException() {
    // given
    given(taskRepository.findTasksByFieldId(anyLong()))
        .willThrow(new RuntimeException("Simulated exception"));

    // when & then
    assertThrows(BusinessRuleException.class, () -> taskService.getAllTasks("1"));
  }

  @Test
  void givenFieldId_whenCountOverdueAndExecutableTasks_thenShouldReturnTaskCounts() {
    // given
    List<Task> tasks = getMockDataForTasks();
    List<TaskField> taskFields = getMockDataForTaskFields();
    given(taskRepository.findTasksByFieldId(1L)).willReturn(tasks);
    given(taskFieldRepository.findByFieldId(1L)).willReturn(taskFields);

    // when
    Map<String, Long> taskCounts = taskService.countOverdueAndExecutableTasks("1");

    // then
    assertNotNull(taskCounts);
  }

  public static List<TaskField> getMockDataForTaskFields() {
    List<TaskField> taskFields = new ArrayList<>();

    taskFields.add(createMockTaskField(1L, 1L, "CONFIRMED", LocalDate.now().minusDays(2)));
    return taskFields;
  }

  private static TaskField createMockTaskField(
      Long taskId, Long fieldId, String status, LocalDate dueDate) {
    TaskField taskField = new TaskField();
    taskField.setId(taskId);
    taskField.setField(new Field());
    taskField.setTask(new Task());
    taskField.setTaskStatus(TaskFieldStatus.valueOf(status));
    taskField.setDueDate(dueDate);
    return taskField;
  }
}
