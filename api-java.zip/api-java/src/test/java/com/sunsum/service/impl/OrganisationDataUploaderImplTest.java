package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.sunsum.constants.OrgType;
import com.sunsum.exception.BulkUploadException;
import com.sunsum.model.dto.RowIngestionResult;
import com.sunsum.model.entity.IngestionStatus;
import com.sunsum.model.entity.Organization;
import com.sunsum.repository.OrganisationRepository;
import java.util.HashMap;
import java.util.Map;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.dao.DataAccessException;
import org.springframework.test.util.ReflectionTestUtils;

class OrganisationDataUploaderImplTest {

  @Mock private Row row;

  @InjectMocks private OrganisationDataUploaderImpl organisationUploader;

  @Mock private OrganisationRepository organisationRepository;

  private static final String ID = "Id";
  private static final String TITLE = "Title";
  private static final String TYPE = "Type";
  private static final String STATUS = "Status";
  private static final String MEMO_1 = "Memo_1";
  private static final String MEMO_2 = "Memo_2";
  private static final String MEMO_3 = "Memo_3";
  private static final String MEMO_4 = "Memo_4";
  private static final String MEMO_5 = "Memo_5";

  private static final String ACTIVE = "Active";

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  private Map<String, Integer> initializeColumnNameToIndex() {
    Map<String, Integer> columnNameToIndex = new HashMap<>();
    columnNameToIndex.put(TITLE, 0);
    columnNameToIndex.put(TYPE, 1);
    columnNameToIndex.put(ID, 2);
    columnNameToIndex.put(STATUS, 3);
    columnNameToIndex.put(MEMO_1, 4);
    columnNameToIndex.put(MEMO_2, 5);
    columnNameToIndex.put(MEMO_3, 6);
    columnNameToIndex.put(MEMO_4, 7);
    columnNameToIndex.put(MEMO_5, 8);
    return columnNameToIndex;
  }

  @Test
  void givenValidRowData_whenCreateFromRow_thenShouldCreateOrganizationEntitySuccessfully() {
    // given
    Map<String, Integer> columnNameToIndex = initializeColumnNameToIndex();

    given(row.getRowNum()).willReturn(1);

    Cell idCell = mock(Cell.class);
    when(row.getCell(2)).thenReturn(idCell);
    when(idCell.getCellType()).thenReturn(CellType.NUMERIC);

    String typeValue = "Syngenta";
    Cell typeCell = mock(Cell.class);
    when(row.getCell(1)).thenReturn(typeCell);
    when(typeCell.getCellType()).thenReturn(CellType.STRING);
    when(typeCell.getStringCellValue()).thenReturn(typeValue);

    // when
    organisationUploader.createFromRow(row, columnNameToIndex);

    // then
    // assertEquals(Integer.valueOf(1), organisationUploader.getRowNum());

    Assertions.assertEquals(
        OrgType.fromString(typeValue), organisationUploader.getOrganizationEntity().getType());
    Assertions.assertEquals(ACTIVE, organisationUploader.getOrganizationEntity().getStatus().getValue());
  }

  @Test
  void givenOrganization_whendataInjection_thenSuccess() {
    // given
    Organization organisation = new Organization();
    ReflectionTestUtils.setField(organisationUploader, "organizationEntity", organisation);
    given(organisationRepository.save(any())).willReturn(organisation);

    // when
    RowIngestionResult result = organisationUploader.dataInjection(1);

    // then
    assertEquals(1, result.getRowNumber());
    Assertions.assertEquals(IngestionStatus.INSERTED, result.getStatus());
  }

  @Test
  void givenUpdateOrganisation_whenDataInjection_Success() {
    // given
    Organization organisation = new Organization();
    organisation.setId(1L);
    ReflectionTestUtils.setField(organisationUploader, "organizationEntity", organisation);
    given(organisationRepository.save(any())).willReturn(organisation);

    // when
    RowIngestionResult result = organisationUploader.dataInjection(1);

    // then
    assertEquals(1, result.getRowNumber());
    Assertions.assertEquals(IngestionStatus.UPDATED, result.getStatus());
  }

  @Test
  void givenExceptionWhenSavingData_thenShouldReturnFailedStatus() {
    // Given
    given(row.getRowNum()).willReturn(1);

    Cell idCell = mock(Cell.class);
    when(row.getCell(2)).thenReturn(idCell);
    when(idCell.getCellType()).thenReturn(CellType.NUMERIC);

    Map<String, Integer> columnNameToIndex = initializeColumnNameToIndex();

    // Mocking the organisationRepository to throw an exception
    when(organisationRepository.save(any())).thenThrow(new RuntimeException("Simulated exception"));

    // When
    // Set the ID to null to ensure IngestionStatus.FAILED
    OrganisationDataUploaderImpl organisationUploader =
        new OrganisationDataUploaderImpl(organisationRepository);
    ReflectionTestUtils.setField(organisationUploader, "organizationEntity", new Organization());

    assertThrows(
        BulkUploadException.class,
        () -> organisationUploader.createFromRow(row, columnNameToIndex));
  }

  @Test
  void givenOrganization_whendataInjection_thenThrowException() {
    // given
    given(organisationRepository.save(any()))
        .willThrow(new DataAccessException("Test exception") {});

    // when & then
    assertThrows(
        Exception.class,
        () -> organisationUploader.dataInjection(1),
        "Exception Occurred while saving the organisation data");
  }
}
