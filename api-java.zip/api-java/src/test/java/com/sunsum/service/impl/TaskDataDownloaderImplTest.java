package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;
import static org.mockito.BDDMockito.willThrow;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.sunsum.constants.CustomType;
import com.sunsum.constants.TaskRelation;
import com.sunsum.constants.TaskType;
import com.sunsum.exception.BulkDownloadException;
import com.sunsum.model.entity.CustomDefinition;
import com.sunsum.model.entity.Task;
import com.sunsum.model.entity.TaskGroup;
import com.sunsum.repository.TaskRepository;
import com.sunsum.service.DataDownload;
import com.sunsum.util.ExcelUtils;
import java.io.ByteArrayInputStream;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.apache.poi.ss.usermodel.Row;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

class TaskDataDownloaderImplTest {

  @Mock private TaskRepository taskRepository;

  @Mock private ExcelUtils excelUtils;

  @InjectMocks private TaskDataDownloaderImpl taskDataDownloader;

  private List<Task> mockTasks;
  @Mock private Logger log;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    TaskGroup taskGroup = new TaskGroup();
    taskGroup.setId(1L);
    taskGroup.setTaskGroupMemo("TaskGroup Memo");

    Task task1 = new Task();
    task1.setId(1L);
    task1.setTitle("Task 1");
    task1.setType(TaskType.ACTION);
    task1.setTaskGroup(taskGroup);
    task1.setIsLocked(false);
    task1.setOrder(1);
    task1.setRelation(TaskRelation.FOLLOW);
    task1.setRelatedDays(5);
    task1.setCustomDefinition(
        Collections.singletonList(
            CustomDefinition.builder()
                .attributeName("attribute")
                .type(CustomType.TEXT)
                .value(Collections.singletonList("value"))
                .build()));
    task1.setFixedDueDate(LocalDate.now().plusDays(7));
    task1.setRelatedTask(null);
    task1.setMemo1("Memo 1");
    task1.setMemo2("Memo 2");
    task1.setMemo3("Memo 3");
    task1.setMemo4("Memo 4");
    task1.setMemo5("Memo 5");

    mockTasks = Collections.singletonList(task1);

    given(taskRepository.findAllByOrderByIdAsc()).willReturn(mockTasks);
  }

  @Test
  void whenFetch_thenDataDownload() {
    // when
    DataDownload result = taskDataDownloader.fetch();

    // then
    assertNotNull(result);
  }

  @Test
  void givenExcelUtilsMocked_whenFetch_thenPrepareSheet() {
    // given
    willDoNothing().given(excelUtils).writeHeaderRow(any(), any(), any(), any());

    // when
    taskDataDownloader.fetch();
    ByteArrayInputStream result = taskDataDownloader.prepareSheet("columns", "mandatoryColumns");

    // then
    assertNotNull(result);
    verify(excelUtils, atLeastOnce()).writeHeaderRow(anyString(), anyString(), any(), any());
    verify(excelUtils, atLeastOnce()).createCell(any(Row.class), anyInt(), any(), any());
    verify(excelUtils, atLeastOnce()).createCell(any(Row.class), anyInt(), anyLong(), any());
    verify(excelUtils, atLeastOnce()).createCell(any(Row.class), anyInt(), anyString(), any());
  }

  @Test
  void givenExcelUtils_whenFetch_thenPrepareSheetShouldThrowRuntimeException() {
    // given
    willThrow(new RuntimeException("Simulated error"))
        .given(excelUtils)
        .writeHeaderRow(any(), any(), any(), any());

    // when
    Executable executable =
        () -> {
          taskDataDownloader.fetch();
          taskDataDownloader.prepareSheet("columns", "mandatoryColumns");
        };

    // then
    assertThrows(BulkDownloadException.class, executable);
  }

  @Test
  void givenException_WhenWriteDataRows_thenLogErrorAndContinue() {
    // given
    List<Task> mockTasks = Arrays.asList(new Task(), new Task());
    given(taskRepository.findAllByOrderByIdAsc()).willReturn(mockTasks);

    // when
    taskDataDownloader.fetch();
    RuntimeException exception =
        assertThrows(
            RuntimeException.class,
            () -> taskDataDownloader.prepareSheet("columns", "mandatoryColumns"));

    // then
    verify(excelUtils, times(mockTasks.size())).createCell(any(), anyInt(), any(), any());
  }
}
