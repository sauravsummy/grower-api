package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willAnswer;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.sunsum.constants.Status;
import com.sunsum.exception.BulkDownloadException;
import com.sunsum.model.entity.Field;
import com.sunsum.model.entity.FieldTaskGroup;
import com.sunsum.model.entity.TaskGroup;
import com.sunsum.repository.FieldRepository;
import com.sunsum.repository.FieldTaskGroupRepository;
import com.sunsum.service.DataDownload;
import com.sunsum.util.ExcelUtils;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.apache.poi.ss.usermodel.Row;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.Answer;
import org.springframework.data.geo.Point;

class FieldDataDownloadImplTest {

  @Mock private FieldRepository fieldRepository;

  @Mock private FieldTaskGroupRepository fieldTaskGroupRepository;

  @Mock private ExcelUtils excelUtils;

  @InjectMocks private FieldDataDownloadImpl fieldDataDownloadImpl;

  private List<Field> mockFields;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    TaskGroup taskGroup = new TaskGroup();
    taskGroup.setId(1L);
    taskGroup.setTaskGroupMemo("TaskGroup Memo");

    Field field1 = new Field();
    field1.setId(1L);
    field1.setTitle("Field 1");
    field1.setTaskGroups(Collections.singletonList(taskGroup));

    mockFields = Collections.singletonList(field1);

    given(fieldRepository.findAllByOrderByIdAsc()).willReturn(mockFields);

    FieldTaskGroup fieldTaskGroup = new FieldTaskGroup();
    fieldTaskGroup.setFieldTaskGroupMemo("FieldTaskGroup Memo");
    fieldTaskGroup.setFiledTaskGroupStatus(Status.ACTIVE);
    given(
            fieldTaskGroupRepository.findByFieldIdAndTaskGroupIdAndFiledTaskGroupStatus(
                anyLong(), anyLong(), eq(Status.ACTIVE)))
        .willReturn(Optional.of(fieldTaskGroup));
  }

  @Test
  void givenRepositoryWithData_whenFetchIsCalled_thenFieldsArePopulated()
      throws NoSuchFieldException, IllegalAccessException {
    // Arrange
    List<Field> expectedFields = Arrays.asList(new Field(), new Field());
    when(fieldRepository.findAllByOrderByIdAsc()).thenReturn(expectedFields);

    // Act
    DataDownload result = fieldDataDownloadImpl.fetch();

    // Assert
    assertEquals(expectedFields.size(), getPrivateFields(fieldDataDownloadImpl).size());
    assertEquals(expectedFields, getPrivateFields(fieldDataDownloadImpl));
  }

  @Test
  void givenEmptyRepository_whenFetchIsCalled_thenFieldsAreEmpty()
      throws NoSuchFieldException, IllegalAccessException {
    // Arrange
    when(fieldRepository.findAllByOrderByIdAsc()).thenReturn(Collections.emptyList());

    // Act
    DataDownload result = fieldDataDownloadImpl.fetch();

    // Assert
    assertTrue(getPrivateFields(fieldDataDownloadImpl).isEmpty());
  }

  private List<Field> getPrivateFields(FieldDataDownloadImpl obj)
      throws NoSuchFieldException, IllegalAccessException {
    java.lang.reflect.Field field = FieldDataDownloadImpl.class.getDeclaredField("fields");
    field.setAccessible(true);
    return (List<Field>) field.get(obj);
  }

  private Field createMockField() {
    Field field = new Field();
    field.setId(1L);
    field.setTitle("Test Field");
    field.setAcreage(BigDecimal.valueOf(10.5));
    return field;
  }

  @Test
  void givenFieldsExistWithTaskGroups_whenPrepareSheet_thenSheetIsPrepared() {
    // Given
    Field field = createMockField();
    given(fieldRepository.findAllByOrderByIdAsc()).willReturn(Collections.singletonList(field));

    FieldTaskGroup fieldTaskGroup = new FieldTaskGroup();
    fieldTaskGroup.setFieldTaskGroupMemo("FieldTaskGroup Memo");
    fieldTaskGroup.setFiledTaskGroupStatus(Status.INACTIVE);
    given(
            fieldTaskGroupRepository.findByFieldIdAndTaskGroupIdAndFiledTaskGroupStatus(
                anyLong(), anyLong(), eq(Status.ACTIVE)))
        .willReturn(Optional.of(fieldTaskGroup));

    // when
    fieldDataDownloadImpl.fetch();
    fieldDataDownloadImpl.prepareSheet("columnsString", "mandatoryColumns");

    // Then
    verify(excelUtils, atLeastOnce()).writeHeaderRow(anyString(), anyString(), any(), any());
    verify(excelUtils, atLeastOnce()).createCell(any(Row.class), anyInt(), any(), any());
    verify(excelUtils, atLeastOnce()).createCell(any(Row.class), anyInt(), anyLong(), any());
    verify(excelUtils, atLeastOnce())
        .createCell(any(Row.class), anyInt(), any(BigDecimal.class), any());
  }

  @Test
  void givenFieldsExist_whenPrepareSheet_thenSheetIsPrepared2() {
    // Given
    Field field = createMockField();
    field.setStatus(Status.ACTIVE);
    given(fieldRepository.findAllByOrderByIdAsc()).willReturn(Collections.singletonList(field));

    // When
    fieldDataDownloadImpl.fetch();
    fieldDataDownloadImpl.prepareSheet("columnsString", "mandatoryColumns");

    // Then
    verify(excelUtils, atLeastOnce()).writeHeaderRow(anyString(), anyString(), any(), any());
    verify(excelUtils, atLeastOnce()).createCell(any(Row.class), anyInt(), any(), any());
    verify(excelUtils, atLeastOnce()).createCell(any(Row.class), anyInt(), anyLong(), any());
    verify(excelUtils, atLeastOnce())
        .createCell(any(Row.class), anyInt(), any(BigDecimal.class), any());
  }

  @Test
  void givenFieldsExistWithTaskGroups_whenSetFieldTaskGroup_thenColumnsAreSet() {
    // Given
    Field field = createMockField();
    TaskGroup taskGroup = new TaskGroup();
    taskGroup.setId(1L);
    taskGroup.setTaskGroupMemo("TaskGroup Memo");
    field.setGpsCoordinates(new Point(123.456, -78.90));
    field.setTaskGroups(Collections.singletonList(taskGroup));
    field.setStatus(Status.ACTIVE);

    field.setPhotoPath(new String[] {"path1", "path2", "path3"});

    given(fieldRepository.findAllByOrderByIdAsc()).willReturn(Collections.singletonList(field));

    FieldTaskGroup fieldTaskGroup = new FieldTaskGroup();
    fieldTaskGroup.setFieldTaskGroupMemo("FieldTaskGroup Memo");
    fieldTaskGroup.setFiledTaskGroupStatus(Status.ACTIVE);
    given(
            fieldTaskGroupRepository.findByFieldIdAndTaskGroupIdAndFiledTaskGroupStatus(
                anyLong(), anyLong(), eq(Status.ACTIVE)))
        .willReturn(Optional.of(fieldTaskGroup));

    // When
    fieldDataDownloadImpl.fetch();
    fieldDataDownloadImpl.prepareSheet("columnsString", "mandatoryColumns");

    // Then
    verify(excelUtils, atLeastOnce()).createCell(any(Row.class), anyInt(), anyLong(), any());
    verify(excelUtils, atLeastOnce()).createCell(any(Row.class), anyInt(), anyString(), any());
    verify(excelUtils, atLeastOnce()).createCell(any(Row.class), anyInt(), anyString(), any());
    verify(excelUtils, atLeastOnce()).createCell(any(Row.class), anyInt(), anyString(), any());
  }

  @Test
  void givenEmptyTaskGroups_whenSetFieldTaskGroup_thenColumnsAreSet() {
    // Given
    Field field = createMockField();
    TaskGroup taskGroup = new TaskGroup();
    taskGroup.setId(1L);
    taskGroup.setTaskGroupMemo("TaskGroup Memo");
    field.setGpsCoordinates(new Point(123.456, -78.90));
    field.setTaskGroups(Collections.singletonList(taskGroup));
    field.setStatus(Status.ACTIVE);
    field.setZipCode("12345");

    field.setPhotoPath(new String[] {"path1", "path2", "path3"});

    given(fieldRepository.findAllByOrderByIdAsc()).willReturn(Collections.singletonList(field));

    given(
            fieldTaskGroupRepository.findByFieldIdAndTaskGroupIdAndFiledTaskGroupStatus(
                anyLong(), anyLong(), eq(Status.ACTIVE)))
        .willReturn(Optional.empty());

    // When
    fieldDataDownloadImpl.fetch();
    fieldDataDownloadImpl.prepareSheet("columnsString", "mandatoryColumns");

    // Then
    verify(excelUtils, atLeastOnce()).createCell(any(Row.class), anyInt(), anyLong(), any());
    verify(excelUtils, atLeastOnce()).createCell(any(Row.class), anyInt(), anyString(), any());
    verify(excelUtils, atLeastOnce()).createCell(any(Row.class), anyInt(), anyString(), any());
    verify(excelUtils, atLeastOnce()).createCell(any(Row.class), anyInt(), anyString(), any());
  }

  @Test
  void WhenPrepareSheet_thenUncheckedIOExceptionIsThrown() throws IOException {
    // given
    MockitoAnnotations.openMocks(this);
    willAnswer(
            (Answer<Void>)
                invocation -> {
                  throw new IOException("Mocked IO Exception");
                })
        .given(excelUtils)
        .writeHeaderRow(any(), any(), any(), any());

    // when & then
    assertThrows(
        BulkDownloadException.class,
        () -> fieldDataDownloadImpl.prepareSheet("columnsString", "mandatoryColumns"));
  }

  @Test
  void givenTaskGroupsStatusActive_whenSetFieldTaskGroup_thenColumnsAreSet() {
    // Given
    Field field = createMockField();
    TaskGroup taskGroup = new TaskGroup();
    taskGroup.setId(1L);
    taskGroup.setTaskGroupMemo("TaskGroup Memo");
    taskGroup.setStatus(Status.ACTIVE);
    field.setGpsCoordinates(new Point(123.456, -78.90));
    field.setTaskGroups(Collections.singletonList(taskGroup));
    field.setStatus(Status.ACTIVE);
    field.setZipCode("12345");

    field.setPhotoPath(new String[] {"path1", "path2", "path3"});

    given(fieldRepository.findAllByOrderByIdAsc()).willReturn(Collections.singletonList(field));

    given(
            fieldTaskGroupRepository.findByFieldIdAndTaskGroupIdAndFiledTaskGroupStatus(
                anyLong(), anyLong(), eq(Status.ACTIVE)))
        .willReturn(Optional.empty());

    // When
    fieldDataDownloadImpl.fetch();
    fieldDataDownloadImpl.prepareSheet("columnsString", "mandatoryColumns");

    // Then
    verify(excelUtils, atLeastOnce()).createCell(any(Row.class), anyInt(), anyLong(), any());
  }

  @Test
  void
      givenFieldIdAndTaskGroupIdAndFieldTaskGroupStatus_whenSetFieldTaskGroup_thenColumnsAreSetx2() {
    // Given
    Field field = createMockField();
    TaskGroup taskGroup = new TaskGroup();
    taskGroup.setId(1L);
    taskGroup.setTaskGroupMemo("TaskGroup Memo");
    taskGroup.setStatus(Status.ACTIVE);
    field.setGpsCoordinates(new Point(123.456, -78.90));
    field.setTaskGroups(Collections.singletonList(taskGroup));
    field.setStatus(Status.ACTIVE);
    field.setZipCode("12345");

    field.setPhotoPath(new String[] {"path1", "path2", "path3"});

    given(fieldRepository.findAllByOrderByIdAsc()).willReturn(Collections.singletonList(field));

    FieldTaskGroup fieldTaskGroup = new FieldTaskGroup();
    fieldTaskGroup.setFieldTaskGroupMemo("FieldTaskGroup Memo");
    fieldTaskGroup.setFiledTaskGroupStatus(Status.ACTIVE);

    given(
            fieldTaskGroupRepository.findByFieldIdAndTaskGroupIdAndFiledTaskGroupStatus(
                anyLong(), anyLong(), eq(Status.ACTIVE)))
        .willReturn(Optional.of(fieldTaskGroup));

    // When
    fieldDataDownloadImpl.fetch();
    fieldDataDownloadImpl.prepareSheet("columnsString", "mandatoryColumns");

    // Then
    verify(excelUtils, atLeastOnce()).createCell(any(Row.class), anyInt(), anyLong(), any());
  }
}
