package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.sunsum.constants.TaskType;
import com.sunsum.exception.BulkUploadException;
import com.sunsum.model.dto.RowIngestionResult;
import com.sunsum.model.entity.IngestionStatus;
import com.sunsum.model.entity.Task;
import com.sunsum.model.entity.TaskGroup;
import com.sunsum.repository.TaskGroupRepository;
import com.sunsum.repository.TaskRepository;
import com.sunsum.service.DataUpload;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

class TaskDataUploaderImplTest {

  @Mock private TaskRepository taskRepository;

  @Mock private TaskGroupRepository taskGroupRepository;

  @Mock private Row row;

  @InjectMocks private TaskDataUploaderImpl taskDataUploader;

  private Map<String, Integer> columnNameToIndex;

  private static final String TITLE = "Title";
  private static final String TYPE = "Type";
  private static final String TASKGROUP_ID = "TaskGroup Id";
  private static final String ID = "Id";
  private static final String BRIEF = "Brief";
  private static final String RELATED_TASK_TITLE = "Related Task Title";
  private static final String RELATION = "Relation";
  private static final String RELATION_DAYS = "Relation Days";
  private static final String FIXED_DUE_DATE = "Fixed Due Date";
  private static final String CUSTOM_DEFINITION = "Custom Definition";
  private static final String COMMA = ",";
  private static final String ORDER = "Order";
  private static final String IS_LOCKED = "is Locked";

  private static final String MEMO_1 = "Memo_1";
  private static final String MEMO_2 = "Memo_2";
  private static final String MEMO_3 = "Memo_3";
  private static final String MEMO_4 = "Memo_4";
  private static final String MEMO_5 = "Memo_5";

  @BeforeEach
  public void setup() {
    MockitoAnnotations.openMocks(this);

    columnNameToIndex = new HashMap<>();
    columnNameToIndex.put(TITLE, 0);
    columnNameToIndex.put(TYPE, 1);
    columnNameToIndex.put(TASKGROUP_ID, 2);
    columnNameToIndex.put(ID, 3);
    columnNameToIndex.put(BRIEF, 4);
    columnNameToIndex.put(RELATED_TASK_TITLE, 5);
    columnNameToIndex.put(RELATION, 6);
    columnNameToIndex.put(RELATION_DAYS, 7);
    columnNameToIndex.put(FIXED_DUE_DATE, 8);
    columnNameToIndex.put(CUSTOM_DEFINITION, 9);
    columnNameToIndex.put(COMMA, 10);
    columnNameToIndex.put(ORDER, 11);
    columnNameToIndex.put(IS_LOCKED, 12);
    columnNameToIndex.put(MEMO_1, 13);
    columnNameToIndex.put(MEMO_2, 14);
    columnNameToIndex.put(MEMO_3, 15);
    columnNameToIndex.put(MEMO_4, 16);
    columnNameToIndex.put(MEMO_5, 17);
  }

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    taskDataUploader = new TaskDataUploaderImpl(taskRepository, taskGroupRepository);
  }

  @ParameterizedTest
  @CsvSource({
    "123.0, Action, SomeRelatedTask, attribute:value, Follow",
    "123.0, Action, SomeRelatedTask, attributevalue, Follow",
    "123.0, Action, SomeRelatedTask, color:SINGLE_SELECTION|red|blue, Follow",
    "123.0, Action, SomeRelatedTask, color:TEXT, Follow"
  })
  void givenRowWithValidData_whenCreateFromRow_thenTaskEntityCreatedSuccessfully(
      double id, String type, String relatedTaskTitle, String customDefinition, String relation) {
    given(row.getRowNum()).willReturn(1);
    given(row.getCell(anyInt())).willReturn(null);

    TaskGroup mockTaskGroup = new TaskGroup();
    given(taskGroupRepository.findById(anyLong())).willReturn(java.util.Optional.of(mockTaskGroup));

    Cell idCell = mock(Cell.class);
    given(idCell.getCellType()).willReturn(CellType.NUMERIC);
    given(idCell.getNumericCellValue()).willReturn(id);
    given(row.getCell(columnNameToIndex.get(ID))).willReturn(idCell);

    Cell typeCell = mock(Cell.class);
    given(row.getCell(1)).willReturn(typeCell);
    given(typeCell.getCellType()).willReturn(CellType.STRING);
    given(typeCell.getStringCellValue()).willReturn(type);

    Cell relatedTaskTitleCell = mock(Cell.class);
    given(row.getCell(columnNameToIndex.get(RELATED_TASK_TITLE))).willReturn(relatedTaskTitleCell);
    given(relatedTaskTitleCell.getCellType()).willReturn(CellType.STRING);
    given(relatedTaskTitleCell.getStringCellValue()).willReturn(relatedTaskTitle);

    Cell customDefinitionCell = mock(Cell.class);
    given(row.getCell(columnNameToIndex.get(CUSTOM_DEFINITION))).willReturn(customDefinitionCell);
    given(customDefinitionCell.getCellType()).willReturn(CellType.STRING);
    given(customDefinitionCell.getStringCellValue()).willReturn(customDefinition);

    Cell relationCell = mock(Cell.class);
    given(row.getCell(columnNameToIndex.get(RELATION))).willReturn(relationCell);
    given(relationCell.getCellType()).willReturn(CellType.STRING);
    given(relationCell.getStringCellValue()).willReturn(relation);

    given(taskRepository.findByTitleAndTaskGroup_Id(anyString(), anyLong()))
        .willReturn(java.util.Optional.of(new Task()));

    TaskDataUploaderImpl uploader = new TaskDataUploaderImpl(taskRepository, taskGroupRepository);

    DataUpload dataUpload = uploader.createFromRow(row, columnNameToIndex);

    assertNotNull(dataUpload);
  }

  @Test
  void givenSuccessfulDataInjection_whenDataInjection_thenRowIngestionResultHasInsertedStatus() {
    // given
    Task taskEntity = new Task();
    taskEntity.setTitle("Test Task");
    taskEntity.setType(TaskType.ACTION);
    taskEntity.setTaskGroup(new TaskGroup());
    taskEntity.setFixedDueDate(LocalDate.now());

    given(taskRepository.save(any(Task.class))).willReturn(taskEntity);

    taskDataUploader = new TaskDataUploaderImpl(taskRepository, taskGroupRepository);
    ReflectionTestUtils.setField(taskDataUploader, "taskEntity", taskEntity);
    // when
    RowIngestionResult result = taskDataUploader.dataInjection(1);

    // then
    verify(taskRepository, times(1)).save(any(Task.class));

    Assertions.assertEquals(IngestionStatus.INSERTED, result.getStatus());
    assertNull(result.getFailureReason());
  }

  @Test
  void givenFailedDataInjection_whenDataInjection_thenRowIngestionResultHasFailedStatus() {
    // given
    Task taskEntity = new Task();
    taskEntity.setTitle("Test Task");
    taskEntity.setType(TaskType.ACTION);
    taskEntity.setTaskGroup(new TaskGroup());
    taskEntity.setFixedDueDate(LocalDate.now());

    taskDataUploader = new TaskDataUploaderImpl(taskRepository, taskGroupRepository);

    given(taskRepository.save(any(Task.class))).willThrow(new RuntimeException("Simulated error"));
    ReflectionTestUtils.setField(taskDataUploader, "taskEntity", taskEntity);
    // when
    assertThrows(BulkUploadException.class, () -> taskDataUploader.dataInjection(1));

    // then
    verify(taskRepository, times(1)).save(any(Task.class));
  }

  @Test
  void givenExceptionInCreateFromRow_whenCreateFromRow_thenExceptionHandled() {
    try {
      // given
      given(row.getRowNum()).willReturn(1);
      given(row.getCell(anyInt())).willReturn(null);

      String typeValue = null;
      Cell typeCell = mock(Cell.class);
      given(row.getCell(columnNameToIndex.get(TYPE))).willReturn(typeCell);
      given(typeCell.getCellType()).willReturn(CellType.STRING);
      given(typeCell.getStringCellValue()).willReturn(typeValue);

      TaskGroup mockTaskGroup = new TaskGroup();
      given(taskGroupRepository.findById(anyLong()))
          .willReturn(java.util.Optional.of(mockTaskGroup));

      TaskDataUploaderImpl uploader = new TaskDataUploaderImpl(taskRepository, taskGroupRepository);

      // when
      uploader.createFromRow(row, columnNameToIndex);

      // then
      verify(row, times(1)).getRowNum();
    } catch (Exception e) {
      assertNotNull(e);
    }
  }
}
