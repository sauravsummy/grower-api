package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sunsum.model.dto.PushNotificationReqDto;
import com.sunsum.model.dto.PushNotificationRespDto;
import java.net.URI;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
class FirebaseServiceImplTest {

  private static final String FIREBASE_API_URL = "https://fcm.googleapis.com/fcm/send";

  @Mock private RestTemplate restTemplate;

  @Mock private ObjectMapper objectMapper;

  @InjectMocks private FirebaseServiceImpl firebaseService;

  @BeforeEach
  void setUp() {
    firebaseService =
        new FirebaseServiceImpl(
            restTemplate, objectMapper, FIREBASE_API_URL, "mockFirebaseAuthKey");
  }

  @Test
  void givenValidRequest_whenSendNotification_thenReturnResponse() throws Exception {
    // Given
    PushNotificationReqDto requestDto = new PushNotificationReqDto();
    String jsonPayload = "{\"example\":\"payload\"}";
    String responsePayload = "{\"success\":true}";
    URI uri = new URI(FIREBASE_API_URL);

    when(objectMapper.writeValueAsString(requestDto)).thenReturn(jsonPayload);
    when(restTemplate.exchange(
            eq(uri), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
        .thenReturn(new ResponseEntity<>(responsePayload, HttpStatus.OK));
    when(objectMapper.readValue(responsePayload, PushNotificationRespDto.class))
        .thenReturn(new PushNotificationRespDto());

    // When
    PushNotificationRespDto response = firebaseService.sendNotification(requestDto);

    // Then
    assertNotNull(response);
    verify(objectMapper).writeValueAsString(requestDto); // Verifies it's called at least once
    verify(restTemplate)
        .exchange(eq(uri), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class));
  }

  @Test
  void givenJsonProcessingException_whenSendNotification_thenHandleException() throws Exception {
    // Given
    PushNotificationReqDto requestDto = new PushNotificationReqDto();
    when(objectMapper.writeValueAsString(requestDto))
        .thenThrow(new JsonProcessingException("Error") {});

    // When
    PushNotificationRespDto response = firebaseService.sendNotification(requestDto);

    // Then
    assertNull(response);
    verify(restTemplate, never())
        .exchange(any(URI.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class));
  }
}
