package com.sunsum.service.impl;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;

import com.sunsum.constants.UserRole;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.FarmHolding;
import com.sunsum.model.dto.FieldBasicInfo;
import com.sunsum.model.dto.FieldDetails;
import com.sunsum.model.dto.FieldRequest;
import com.sunsum.model.dto.FieldResponse;
import com.sunsum.model.dto.FieldTitle;
import com.sunsum.model.dto.FieldUpdateRequest;
import com.sunsum.model.dto.FieldsResponse;
import com.sunsum.model.dto.UserDetails;
import com.sunsum.model.entity.Field;
import com.sunsum.model.entity.Organization;
import com.sunsum.model.entity.Role;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.FieldRepository;
import com.sunsum.repository.OrganisationRepository;
import com.sunsum.util.CommonUtils;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.modelmapper.ModelMapper;
import org.springframework.data.geo.Point;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class FieldServiceTest {

  public static final String TEST_FIELD_2 = "Test-Field-2";
  public static final String TEST_TITLE_1 = "Test-Title-1";
  public static final Point GPS_COORDINATE = new Point(23.23d, 43.44d);
  public static final String GPS_COORDINATES_STRING = "23.23 43.44";
  public static final String TEST_MEMO = "test-memo";
  public static final String TEST_FIELD = "test-field";
  public static final String TEST_TITLE_2 = "Test-Title-2";
  private MockMultipartFile file;
  private Organization org;
  private FieldRequest fieldRequest;

  private FieldUpdateRequest fieldUpdateRequest;

  @Mock
  FieldRepository fieldRepository;
  @Mock
  OrganisationRepository farmRepository;
  @Mock S3ServiceImpl s3Service;

  @Mock CommonUtils commonUtils;

  @Spy ModelMapper modelMapper;

  @InjectMocks FieldServiceImpl fieldService;
  @Captor ArgumentCaptor<Field> fieldArgumentCaptor;

  @DisplayName("Unit test for createField method when valid request body is provided")
  @Test
  void givenValidFieldRequest_whenCreateField_thenFieldShouldBeCreated() {

    // given
    prepareMockData();
    given(fieldRepository.save(fieldArgumentCaptor.capture())).willReturn(new Field());
    given(farmRepository.findById(1L)).willReturn(Optional.of(org));
    willDoNothing().given(s3Service).uploadObject(file, TEST_FIELD);

    // when
    ResponseEntity<String> resp = fieldService.createField(fieldRequest);

    // then
    assertEquals(TEST_FIELD, fieldArgumentCaptor.getValue().getTitle());
    assertEquals(GPS_COORDINATE, fieldArgumentCaptor.getValue().getGpsCoordinates());
    assertEquals(BigDecimal.ZERO, fieldArgumentCaptor.getValue().getAcreage());
    assertEquals(HttpStatus.CREATED, resp.getStatusCode());
  }

  @DisplayName(
      "Unit test for createField method when request body is provided with mandatory field attribute")
  @Test()
  void givenMandatoryFieldAttribute_whenCreateField_thenFieldShouldBeCreated() {

    // given
    prepareMockDataForMandatoryField();
    given(fieldRepository.save(fieldArgumentCaptor.capture())).willReturn(new Field());
    given(farmRepository.findById(1L)).willReturn(Optional.of(org));
    willDoNothing().given(s3Service).uploadObject(file, TEST_FIELD);

    // when
    ResponseEntity<String> resp = fieldService.createField(fieldRequest);

    // then
    assertEquals(TEST_FIELD_2, fieldArgumentCaptor.getValue().getTitle());
    assertEquals(GPS_COORDINATE, fieldArgumentCaptor.getValue().getGpsCoordinates());

    assertEquals(BigDecimal.TEN, fieldArgumentCaptor.getValue().getAcreage());
    assertEquals(HttpStatus.CREATED, resp.getStatusCode());
  }

  @DisplayName(
      "Unit test for createField method when request body is provided without mandatory field attribute")
  @Test
  void givenInValidRequest_whenCreateField_thenCreateFieldMethodShouldFail() {

    // given
    fieldRequest = FieldRequest.builder().build();
    prepareMockOrg();
    given(fieldRepository.save(fieldArgumentCaptor.capture())).willReturn(new Field());
    given(farmRepository.findById(1L)).willReturn(Optional.of(org));
    willDoNothing().given(s3Service).uploadObject(file, TEST_FIELD);

    // when
    Executable executable = () -> fieldService.createField(fieldRequest);

    // then
    assertThrows(BusinessRuleException.class, executable);
  }

  @DisplayName("Unit test for updateField method when valid request body is provided")
  @Test
  void givenValidFieldRequest_whenUpdateField_thenFieldShouldBeCreated() {

    // given
    prepareMockDataForFieldUpdate();
    given(fieldRepository.save(fieldArgumentCaptor.capture())).willReturn(new Field());
    given(fieldRepository.findById(1L)).willReturn(Optional.of(new Field()));
    willDoNothing().given(s3Service).uploadObject(file, TEST_FIELD);

    // when
    ResponseEntity<String> resp = fieldService.updateField(fieldUpdateRequest, "1");

    // then
    assertEquals(TEST_FIELD, fieldArgumentCaptor.getValue().getTitle());
    assertEquals(GPS_COORDINATE, fieldArgumentCaptor.getValue().getGpsCoordinates());
    assertEquals(BigDecimal.ZERO, fieldArgumentCaptor.getValue().getAcreage());
    assertEquals(HttpStatus.OK, resp.getStatusCode());
  }

  @DisplayName("Unit test for getFields method when valid farm holding id is given")
  @Test
  void givenFarmHoldingId_whenGetFields_thenListOfFieldsShouldReturn() {

    // given
    given(fieldRepository.getFields(anyLong())).willReturn(getMockFieldTitles());

    // when
    ResponseEntity<FieldsResponse> response = fieldService.getFields("1");
    List<FieldBasicInfo> fieldTitles = response.getBody().fieldTitles();

    // then
    assertEquals(2, fieldTitles.size());
    assertEquals(TEST_TITLE_1, fieldTitles.get(0).title());
  }

  @DisplayName("Unit test for getField method when valid field id is given")
  @Test
  void givenFieldId_whenGetField_thenFieldShouldReturn() {

    // given
    given(fieldRepository.getFieldDetails(anyLong())).willReturn(getMockField());

    // when
    ResponseEntity<FieldResponse> response = fieldService.getField("1");
    FieldResponse fieldResponse = response.getBody();

    // then
    assertEquals(TEST_TITLE_1, fieldResponse.getTitle());
    assertEquals(GPS_COORDINATE, fieldResponse.getGpsCoordinates());
  }

  @Test
  void givenUserAsProjectAdmin_whenCheckUserPermissionForField_thenShouldReturnTrue() {

    // given
    UserProfile userProfile = createUserProfileWithRole(UserRole.ROLE_PROJECT_ADMIN);
    UserDetails userDetails =
        new UserDetails(userProfile.getId(), userProfile.getName(), userProfile.getRoles());
    given(commonUtils.getCurrentLoggedInUserDetails()).willReturn(userDetails);
    given(farmRepository.findByProjectAdmin(userProfile.getId())).willReturn(getMockFarmHoldings());
    given(fieldRepository.findFarmHoldingIdByFieldId(1L)).willReturn(List.of(1L));

    // when
    boolean isUserBelongsToField = fieldService.hasUserPermissionForField(1L);

    // then
    assertTrue(isUserBelongsToField);
  }

  @Test
  void givenUserAsFieldSupporter_whenCheckUserPermissionForField_thenShouldReturnTrue() {

    // given
    UserProfile userProfile = createUserProfileWithRole(UserRole.ROLE_FIELD_SUPPORTER);
    UserDetails userDetails =
        new UserDetails(userProfile.getId(), userProfile.getName(), userProfile.getRoles());
    given(commonUtils.getCurrentLoggedInUserDetails()).willReturn(userDetails);
    given(farmRepository.findByFieldSupporter(userProfile.getId()))
        .willReturn(getMockFarmHoldings());
    given(fieldRepository.findFarmHoldingIdByFieldId(1L)).willReturn(List.of(1L));

    // when
    boolean isUserBelongsToField = fieldService.hasUserPermissionForField(1L);

    // then
    assertTrue(isUserBelongsToField);
  }

  @Test
  void givenUserAsFieldManager_whenCheckUserPermissionForField_thenShouldReturnTrue() {

    // given
    UserProfile userProfile = createUserProfileWithRole(UserRole.ROLE_FIELD_MANAGER);
    UserDetails userDetails =
        new UserDetails(userProfile.getId(), userProfile.getName(), userProfile.getRoles());
    given(commonUtils.getCurrentLoggedInUserDetails()).willReturn(userDetails);
    given(farmRepository.findByFieldManager(userProfile.getId())).willReturn(getMockFarmHoldings());
    given(fieldRepository.findFarmHoldingIdByFieldId(1L)).willReturn(List.of(1L));

    // when
    boolean isUserBelongsToField = fieldService.hasUserPermissionForField(1L);

    // then
    assertTrue(isUserBelongsToField);
  }

  @Test
  void givenUnAuthorizedUser_whenCheckUserPermissionForField_thenShouldReturnFalse() {

    // given
    UserProfile userProfile = createUserProfileWithRole(UserRole.ROLE_FIELD_MANAGER);
    UserDetails userDetails =
        new UserDetails(userProfile.getId(), userProfile.getName(), userProfile.getRoles());
    given(commonUtils.getCurrentLoggedInUserDetails()).willReturn(userDetails);
    given(farmRepository.findByFieldManager(userProfile.getId())).willReturn(getMockFarmHoldings());
    given(fieldRepository.findFarmHoldingIdByFieldId(1L)).willReturn(List.of(3L));

    // when
    boolean isUserBelongsToField = fieldService.hasUserPermissionForField(1L);

    // then
    assertFalse(isUserBelongsToField);
  }

  private void prepareMockDataForMandatoryField() {
    prepareMockOrg();
    fieldRequest =
        FieldRequest.builder()
            .farmHoldingId(1L)
            .title(TEST_FIELD_2)
            .gpsCoordinates(GPS_COORDINATES_STRING)
            .acreage(BigDecimal.TEN)
            .build();
  }

  private void prepareMockData() {
    file = new MockMultipartFile("image", "image.jpg", "jpg", "image".getBytes());
    prepareMockOrg();
    fieldRequest =
        FieldRequest.builder()
            .title(TEST_FIELD)
            .memo1(TEST_MEMO)
            .acreage(BigDecimal.ZERO)
            .farmHoldingId(1L)
            .gpsCoordinates(GPS_COORDINATES_STRING)
            .zipCode("123456")
            .files(List.of(file))
            .build();
  }

  private void prepareMockDataForFieldUpdate() {
    file = new MockMultipartFile("image", "image.jpg", "jpg", "image".getBytes());
    prepareMockOrg();
    fieldUpdateRequest =
        FieldUpdateRequest.builder()
            .title(TEST_FIELD)
            .memo1(TEST_MEMO)
            .acreage(BigDecimal.ZERO)
            .gpsCoordinates(GPS_COORDINATES_STRING)
            .zipCode("123456")
            .files(List.of(file))
            .build();
  }

  private void prepareMockOrg() {
    org = new Organization();
    org.setFields(new HashSet<>());
  }

  private List<FarmHolding> getMockFarmHoldings() {
    FarmHolding farmHolding =
        new FarmHolding() {
          @Override
          public Long getId() {
            return 1L;
          }

          @Override
          public String getTitle() {
            return "Test-FarmHolding";
          }
        };
    return List.of(farmHolding);
  }

  private List<FieldTitle> getMockFieldTitles() {
    FieldTitle field1 =
        new FieldTitle() {
          @Override
          public Long getId() {
            return 1L;
          }

          @Override
          public String getTitle() {
            return TEST_TITLE_1;
          }

          @Override
          public byte[] getGps() {
            return null;
          }
        };
    FieldTitle field2 =
        new FieldTitle() {
          @Override
          public Long getId() {
            return 2L;
          }

          @Override
          public String getTitle() {
            return TEST_TITLE_2;
          }

          @Override
          public byte[] getGps() {
            return null;
          }
        };

    return List.of(field1, field2);
  }

  private Optional<FieldDetails> getMockField() {
    return Optional.of(
        new FieldDetails() {
          @Override
          public String getTitle() {
            return TEST_TITLE_1;
          }

          @Override
          public byte[] getGpsCoordinates() {
            try {
              ByteArrayOutputStream bos = new ByteArrayOutputStream();
              ObjectOutputStream out = new ObjectOutputStream(bos);
              out.writeObject(GPS_COORDINATE);
              out.flush();
              return bos.toByteArray();
            } catch (Exception e) {
              throw new RuntimeException();
            }
          }

          @Override
          public BigDecimal getAcreage() {
            return BigDecimal.TEN;
          }

          @Override
          public String getZipCode() {
            return "12345";
          }

          @Override
          public String getMemo1() {
            return TEST_MEMO;
          }

          @Override
          public String[] getPhotoPath() {
            return new String[] {"test/path/image.jpg"};
          }
        });
  }

  private UserProfile createUserProfileWithRole(UserRole role) {
    UserProfile userProfile = new UserProfile();
    userProfile.setId(1L);
    userProfile.setName("TestUser");
    userProfile.setRoles(Collections.singleton(new Role(1L, role, null)));
    return userProfile;
  }

  @Test
  void givenErrorDuringUpdate_whenUpdateField_thenBusinessRuleExceptionShouldBeThrown() {

    // given
    prepareMockDataForFieldUpdate();
    given(fieldRepository.findById(1L)).willReturn(Optional.of(new Field()));
    willDoNothing().given(s3Service).uploadObject(Mockito.any(), Mockito.anyString());
    given(fieldRepository.save(fieldArgumentCaptor.capture()))
        .willThrow(new RuntimeException("Simulated error during update"));

    // when
    Executable executable = () -> fieldService.updateField(fieldUpdateRequest, "1");

    // then
    BusinessRuleException businessRuleException =
        assertThrows(BusinessRuleException.class, executable);
    assertEquals("Error occurred while updating new field", businessRuleException.getMessage());
  }

  @Test
  void givenNonExistentFieldId_whenGetField_thenBusinessRuleExceptionShouldBeThrown() {
    // given
    given(fieldRepository.getFieldDetails(anyLong())).willReturn(Optional.empty());

    // when
    Executable executable = () -> fieldService.getField("1");

    // then
    BusinessRuleException businessRuleException =
        assertThrows(BusinessRuleException.class, executable);
    assertEquals("Field with id 1 does not exist", businessRuleException.getMessage());
  }

  @Mock private ModelMapper mapper;

  @Test
  void givenExistingAndUpdatedPaths_whenDeleteImageInvoked_thenExistingPathsUpdated()
      throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
    FieldServiceImpl fieldService =
        new FieldServiceImpl(fieldRepository, farmRepository, s3Service, commonUtils);

    String[] existingPath = {"path1", "path2", "path3"};
    List<String> updatedPath = Arrays.asList("path1", "path3");

    Method deleteImageMethod =
        FieldServiceImpl.class.getDeclaredMethod("deleteImage", String[].class, List.class);

    deleteImageMethod.setAccessible(true);

    deleteImageMethod.invoke(fieldService, existingPath, updatedPath);

    assertArrayEquals(new String[] {"path1", "path2", "path3"}, existingPath);
  }

  @Test
  void givenNonExistentField_whenUpdateField_thenThrowNotFoundException() {
    // Given
    String nonExistentFieldId = "1";
    FieldUpdateRequest fieldUpdateRequest = createFieldUpdateRequest();

    given(fieldRepository.findById(anyLong())).willReturn(Optional.empty());

    // When & Then
    Executable executable = () -> fieldService.updateField(fieldUpdateRequest, nonExistentFieldId);
    BusinessRuleException businessRuleException =
        assertThrows(BusinessRuleException.class, executable);

    assertEquals("Error occurred while updating new field", businessRuleException.getMessage());
  }

  private FieldUpdateRequest createFieldUpdateRequest() {
    return new FieldUpdateRequest();
  }
}
