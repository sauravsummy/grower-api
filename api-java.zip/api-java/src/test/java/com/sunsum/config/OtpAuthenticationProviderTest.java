package com.sunsum.config;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.sunsum.constants.ChannelType;
import com.sunsum.model.dto.OtpVerifyRequest;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.service.OtpService;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

class OtpAuthenticationProviderTest {

  @InjectMocks private OtpAuthenticationProvider otpAuthenticationProvider;

  @Mock private UserProfileRepository userProfileRepository;

  @Mock private OtpService otpService;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void whenAuthenticateWithValidOtp_thenAuthenticateSuccessfully() {
    OtpVerifyRequest otpVerifyRequest = new OtpVerifyRequest();
    otpVerifyRequest.setRecipientId("test@example.com");
    otpVerifyRequest.setChannelType(ChannelType.EMAIL_ID);

    UserProfile user = UserProfile.builder().email("test@example.com").isActive(true).build();

    when(userProfileRepository.findByEmailIgnoreCase(any(String.class)))
        .thenReturn(Optional.of(user));
    when(otpService.isValidOtp(any(OtpVerifyRequest.class))).thenReturn(true);

    Authentication authentication = new UsernamePasswordAuthenticationToken(otpVerifyRequest, null);
    Authentication result = otpAuthenticationProvider.authenticate(authentication);

    assertNotNull(result);
    verify(otpService).isValidOtp(otpVerifyRequest);
  }

  @Test
  void whenAuthenticateWithInvalidOtp_thenThrowBadCredentialsException() {
    OtpVerifyRequest otpVerifyRequest = new OtpVerifyRequest();
    otpVerifyRequest.setRecipientId("test@example.com");
    otpVerifyRequest.setChannelType(ChannelType.EMAIL_ID);

    UserProfile user = UserProfile.builder().email("test@example.com").isActive(true).build();

    when(userProfileRepository.findByEmailIgnoreCase(any(String.class)))
        .thenReturn(Optional.of(user));
    when(otpService.isValidOtp(any(OtpVerifyRequest.class))).thenReturn(false);

    Authentication authentication = new UsernamePasswordAuthenticationToken(otpVerifyRequest, null);

    assertThrows(
        BadCredentialsException.class,
        () -> otpAuthenticationProvider.authenticate(authentication));
  }

  @Test
  void whenAuthenticateWithNonExistentUser_thenThrowUsernameNotFoundException() {
    OtpVerifyRequest otpVerifyRequest = new OtpVerifyRequest();
    otpVerifyRequest.setRecipientId("nonexistent@example.com");
    otpVerifyRequest.setChannelType(ChannelType.EMAIL_ID);

    when(userProfileRepository.findByEmailIgnoreCase(any(String.class)))
        .thenReturn(Optional.empty());

    Authentication authentication = new UsernamePasswordAuthenticationToken(otpVerifyRequest, null);

    assertThrows(
        UsernameNotFoundException.class,
        () -> otpAuthenticationProvider.authenticate(authentication));
  }
}
