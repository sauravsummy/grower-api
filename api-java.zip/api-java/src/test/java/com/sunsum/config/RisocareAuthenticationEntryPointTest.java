package com.sunsum.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.io.PrintWriter;
import java.io.StringWriter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.AuthenticationException;

class RisocareAuthenticationEntryPointTest {

  private RisocareAuthenticationEntryPoint entryPoint;

  @Mock private HttpServletRequest request;

  @Mock private HttpServletResponse response;

  @Mock private AuthenticationException authException;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    entryPoint = new RisocareAuthenticationEntryPoint();
    entryPoint.setRealmName("RisocareDeveloperStack");
  }

  @Test
  void whenCommence_thenSetUnauthorizedResponse() throws Exception {
    StringWriter stringWriter = new StringWriter();
    PrintWriter writer = new PrintWriter(stringWriter);
    when(response.getWriter()).thenReturn(writer);

    when(authException.getMessage()).thenReturn("Test Exception Message");

    entryPoint.commence(request, response, authException);

    verify(response).addHeader("WWW-Authenticate", "Basic realm=RisocareDeveloperStack");
    verify(response).setStatus(HttpServletResponse.SC_UNAUTHORIZED);
    writer.flush();

    String expectedMessage = "HTTP Status 401 - Test Exception Message\n".trim();
    String actualMessage = stringWriter.toString().trim();

    assertEquals(expectedMessage, actualMessage, "Expected and actual messages do not match.");
  }
}
