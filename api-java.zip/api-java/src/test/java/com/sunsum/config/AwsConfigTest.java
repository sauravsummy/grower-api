package com.sunsum.config;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.amazonaws.services.s3.AmazonS3;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

class AwsConfigTest {

  @InjectMocks private AwsConfig awsConfig;

  @Mock private AmazonS3 amazonS3;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);

    // Set up mock values for the AWS configuration
    ReflectionTestUtils.setField(awsConfig, "region", "test-region");
    ReflectionTestUtils.setField(awsConfig, "s3EndpointUrl", "https://test-s3-url");
    ReflectionTestUtils.setField(awsConfig, "accessKey", "testAccessKey");
    ReflectionTestUtils.setField(awsConfig, "secretKey", "testSecretKey");
  }

  @Test
  void whenAmazonS3BeanCreated_thenNotNull() {
    // Act
    AmazonS3 createdAmazonS3 = awsConfig.amazonS3();

    // Assert
    assertNotNull(createdAmazonS3, "AmazonS3 bean should not be null");
  }
}
