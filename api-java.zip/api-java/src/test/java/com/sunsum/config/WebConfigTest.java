package com.sunsum.config;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.apache.catalina.filters.CorsFilter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

class WebConfigTest {

  private MockMvc mockMvc;

  @BeforeEach
  void setup() {
    WebMvcConfigurer webConfig =
        new WebConfig() {
          @Override
          public void addCorsMappings(CorsRegistry registry) {
            registry
                .addMapping("/api/v1/**")
                .allowedOrigins(
                    "http://localhost:3000",
                    "https://dev-admin.sunsum-growers.syndpe.com",
                    "https://qa-admin.sunsum-growers.syndpe.com");
          }
        };

    this.mockMvc = MockMvcBuilders.standaloneSetup(webConfig).addFilters(new CorsFilter()).build();
  }

  @Test
  void whenRequestingApiV1Endpoint_thenCorsHeadersAreSet() throws Exception {
    String realEndpoint = "/api/v1/actualEndpoint";

    mockMvc
        .perform(get(realEndpoint).header("Origin", "http://localhost:3000"))
        .andExpect(status().isForbidden());
  }

  @Test
  void whenRequestingNonApiV1Endpoint_thenCorsHeadersAreNotSet() throws Exception {
    mockMvc
        .perform(get("/api/v2/test").header("Origin", "http://localhost:3000"))
        .andExpect(header().doesNotExist("Access-Control-Allow-Origin"));
  }
}
