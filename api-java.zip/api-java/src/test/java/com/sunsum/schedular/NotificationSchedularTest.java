package com.sunsum.schedular;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.sunsum.client.EmailClient;
import com.sunsum.config.MessageProperties;
import com.sunsum.model.dto.PushNotificationReqDto;
import com.sunsum.model.dto.TaskCounts;
import com.sunsum.model.dto.UserFcmTokenDto;
import com.sunsum.model.dto.UserSubDetails;
import com.sunsum.service.FarmHoldingService;
import com.sunsum.service.FcmTokenService;
import com.sunsum.service.FirebaseService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.thymeleaf.TemplateEngine;

@ExtendWith(MockitoExtension.class)
class NotificationSchedularTest {

  @Mock private FirebaseService firebaseService;
  @Mock private FcmTokenService fcmTokenService;
  @Mock private FarmHoldingService farmHoldingService;
  @Mock private MessageProperties messageProperties;

  @Mock private EmailClient emailClient;
  @Mock private TemplateEngine templateEngine;

  @InjectMocks private NotificationSchedular notificationSchedular;

  @BeforeEach
  void setUp() {
    // Set up mocks and other necessary configurations
  }

  @Test
  void givenTasksPresent_whenRunTask_thenNotificationsSent() {
    // Given
    Map<UserSubDetails, Map<Long, Map<Long, TaskCounts>>> farmHoldingsForAllUsers =
        createMockFarmHoldingsData();
    when(farmHoldingService.getCountOfUpcomingInTwoDaysAndOverdueTasks())
        .thenReturn(farmHoldingsForAllUsers);

    List<UserFcmTokenDto> mockTokens = createMockTokens();
    when(fcmTokenService.getActiveUserFcmTokensByUserId(1L)).thenReturn(mockTokens);

    Map<String, String> mockMessages = new HashMap<>();
    mockMessages.put(
        "notification", "You have {0} overdue tasks, and {1} upcoming tasks in 2 days.");
    ReflectionTestUtils.setField(notificationSchedular, "defaultLang", "ja");
    when(messageProperties.getJa()).thenReturn(mockMessages);

    // When
    notificationSchedular.runTask();

    // Then
    verify(firebaseService, times(mockTokens.size()))
        .sendNotification(any(PushNotificationReqDto.class));
  }

  @Test
  void givenExceptionOccurs_whenRunTask_thenNoNotificationsSent() {
    // Given
    when(farmHoldingService.getCountOfUpcomingInTwoDaysAndOverdueTasks())
        .thenThrow(new RuntimeException("Error fetching tasks"));

    // When
    notificationSchedular.runTask();

    // Then
    verify(firebaseService, never()).sendNotification(any(PushNotificationReqDto.class));
    // Optionally verify that the error is logged
  }

  private Map<UserSubDetails, Map<Long, Map<Long, TaskCounts>>> createMockFarmHoldingsData() {
    Map<UserSubDetails, Map<Long, Map<Long, TaskCounts>>> farmHoldingsForAllUsers = new HashMap<>();

    // Mock data for one user
    Map<Long, Map<Long, TaskCounts>> farmHoldingDataForOneUser = new HashMap<>();
    Map<Long, TaskCounts> taskCountsForOneFarmHolding = new HashMap<>();

    // Assuming TaskCounts is a simple DTO with overdue and executable tasks
    TaskCounts counts = new TaskCounts(3, 5); // 3 overdue tasks, 5 executable tasks

    taskCountsForOneFarmHolding.put(1L, counts); // Farm Holding ID as key
    farmHoldingDataForOneUser.put(1L, taskCountsForOneFarmHolding); // User ID as key

    farmHoldingsForAllUsers.put(
        new UserSubDetails(1l, "email@gmail.com", "example"),
        farmHoldingDataForOneUser); // Populate for one user

    return farmHoldingsForAllUsers;
  }

  private List<UserFcmTokenDto> createMockTokens() {
    return List.of(
        new UserFcmTokenDto(1L, "token123"), // Example FCM token
        new UserFcmTokenDto(2L, "token456") // Another example FCM token
        );
  }

  @Test
  void givenExceptionDuringNotification_whenRunTask_thenErrorLogged() {
    // Given
    Map<UserSubDetails, Map<Long, Map<Long, TaskCounts>>> farmHoldingsForAllUsers =
        createMockFarmHoldingsData();
    given(farmHoldingService.getCountOfUpcomingInTwoDaysAndOverdueTasks())
        .willReturn(farmHoldingsForAllUsers);

    List<UserFcmTokenDto> mockTokens = createMockTokens();
    given(fcmTokenService.getActiveUserFcmTokensByUserId(1L)).willReturn(mockTokens);

    Map<String, String> mockMessages = new HashMap<>();
    mockMessages.put(
        "notification", "You have {0} overdue tasks, and {1} upcoming tasks in 2 days.");
    ReflectionTestUtils.setField(notificationSchedular, "defaultLang", "ja");
    given(messageProperties.getJa()).willReturn(mockMessages);

    willThrow(new RuntimeException("Error sending notification"))
        .given(firebaseService)
        .sendNotification(any(PushNotificationReqDto.class));

    // When
    notificationSchedular.runTask();

    // Then
    verify(firebaseService, times(mockTokens.size()))
        .sendNotification(any(PushNotificationReqDto.class));
  }
}
