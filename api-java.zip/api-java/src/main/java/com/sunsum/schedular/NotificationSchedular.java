package com.sunsum.schedular;

import com.sunsum.client.EmailClient;
import com.sunsum.config.MessageProperties;
import com.sunsum.constants.AppConstants;
import com.sunsum.model.dto.EmailDTO;
import com.sunsum.model.dto.Notification;
import com.sunsum.model.dto.PushNotificationReqDto;
import com.sunsum.model.dto.PushNotificationRespDto;
import com.sunsum.model.dto.TaskCounts;
import com.sunsum.model.dto.UserFcmTokenDto;
import com.sunsum.model.dto.UserSubDetails;
import com.sunsum.service.FarmHoldingService;
import com.sunsum.service.FcmTokenService;
import com.sunsum.service.FirebaseService;
import java.text.MessageFormat;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

@Component
@Slf4j
public class NotificationSchedular {

  private final FirebaseService firebaseService;
  private final FcmTokenService fcmTokenService;
  private final FarmHoldingService farmHoldingService;
  private final MessageProperties messageProperties;

  private final EmailClient emailClient;

  private final TemplateEngine templateEngine;

  @Value("${notification.email.source}")
  private String fromEmail;

  @Value("${notification.email.header.en}")
  private String subjectEn;

  @Value("${notification.email.header.ja}")
  private String subjectJa;

  @Value("${notification.default-lang}")
  private String defaultLang;

  public NotificationSchedular(
      FirebaseService firebaseService,
      FcmTokenService fcmTokenService,
      FarmHoldingService farmHoldingService,
      EmailClient emailClient,
      TemplateEngine templateEngine,
      MessageProperties messageProperties) {
    this.firebaseService = firebaseService;
    this.fcmTokenService = fcmTokenService;
    this.farmHoldingService = farmHoldingService;
    this.emailClient = emailClient;
    this.templateEngine = templateEngine;
    this.messageProperties = messageProperties;
  }

  @Scheduled(cron = "${scheduling.cron-expression}", zone = "Asia/Tokyo")
  @SchedulerLock(name = "tasks-lock", lockAtLeastFor = "5m", lockAtMostFor = "15m")
  public void runTask() {
    try {
      Map<UserSubDetails, Map<Long, Map<Long, TaskCounts>>> farmHoldingsForAllUsers =
          farmHoldingService.getCountOfUpcomingInTwoDaysAndOverdueTasks();

      log.info("Starting scheduled task for sending notifications.");

      farmHoldingsForAllUsers.forEach(
          (userPartialDetails, farmHoldingData) -> {
            try {
              int totalOverdueTasks =
                  farmHoldingData.values().stream()
                      .flatMap(farmHolding -> farmHolding.values().stream())
                      .mapToInt(TaskCounts::getOverdueTasks)
                      .sum();
              int totalUpcomingTasks =
                  farmHoldingData.values().stream()
                      .flatMap(farmHolding -> farmHolding.values().stream())
                      .mapToInt(TaskCounts::getExecutableTasks)
                      .sum();

              log.info(
                  "User ID: {}, Total Overdue Tasks: {}, Total Upcoming Tasks: {}",
                  userPartialDetails.id(),
                  totalOverdueTasks,
                  totalUpcomingTasks);

              if (totalOverdueTasks > 0 || totalUpcomingTasks > 0) {

                String messageKey = "notification";
                String message =
                    defaultLang.equalsIgnoreCase(AppConstants.JA)
                        ? messageProperties.getJa().get(messageKey)
                        : messageProperties.getEn().get(messageKey);
                String formattedMessage =
                    MessageFormat.format(message, totalOverdueTasks, totalUpcomingTasks);

                List<UserFcmTokenDto> activeTokens =
                    fcmTokenService.getActiveUserFcmTokensByUserId(userPartialDetails.id());

                log.info("Sending notifications to {} active tokens.", activeTokens.size());

                activeTokens.forEach(
                    token -> {
                      try {
                        PushNotificationReqDto notificationReqDto =
                            PushNotificationReqDto.builder()
                                .to(token.getFcmToken())
                                .notification(
                                    Notification.builder()
                                        .title(AppConstants.CROPWISE_GROWER)
                                        .body(formattedMessage)
                                        .build())
                                .build();

                        PushNotificationRespDto notificationRespDto =
                            firebaseService.sendNotification(notificationReqDto);
                        log.info(
                            "Notification sent to token: {}, response: {}",
                            token.getFcmToken(),
                            notificationRespDto);
                      } catch (Exception e) {
                        log.error(
                            "Error sending notification to token: {}", token.getFcmToken(), e);
                      }
                    });
                prepareAndSendEmail(userPartialDetails, totalOverdueTasks, totalUpcomingTasks);
              }
            } catch (Exception e) {
              log.error("Error preparing notification for user ID: {}", userPartialDetails.id(), e);
            }
          });
    } catch (Exception e) {
      log.error("Error in scheduled task", e);
    }
  }

  private void prepareAndSendEmail(
      UserSubDetails userPartialDetails, int totalOverdueTasks, int totalUpcomingTasks) {
    try {
      EmailDTO emailDTO =
          prepareEmailDetails(userPartialDetails, totalOverdueTasks, totalUpcomingTasks);
      log.info("Before calling the send email!");
      ResponseEntity<String> emailResponse = emailClient.sendEmail(emailDTO);
      log.info(
          "Email Notification sent to email: {}, response: {}",
          userPartialDetails.email(),
          emailResponse.getStatusCode());
    } catch (Exception e) {
      log.error(
          "Exception occurred while sending email notification to email: {}",
          userPartialDetails.id(),
          e);
    }
  }

  private EmailDTO prepareEmailDetails(
      UserSubDetails userPartialDetails, int totalOverdueTasks, int totalUpcomingTasks) {
    EmailDTO emailDTO = new EmailDTO();
    try {
      emailDTO.setFromEmail(fromEmail);
      emailDTO.setToEmail(userPartialDetails.email());
      if (defaultLang.equalsIgnoreCase(AppConstants.JA)) emailDTO.setSubject(subjectJa);
      else emailDTO.setSubject(subjectEn);
      String body =
          renderThymeleafTemplate(userPartialDetails.name(), totalOverdueTasks, totalUpcomingTasks);
      emailDTO.setBody(body);
    } catch (Exception e) {
      log.error("Exception Occurred while preparing the emailDTO");
    }

    return emailDTO;
  }

  private String renderThymeleafTemplate(
      String userName, int totalOverdueTasks, int totalUpcomingTasks) {

    Context thymeleafContext = new Context();
    thymeleafContext.setVariable("username", userName);
    thymeleafContext.setVariable("overdueCount", totalOverdueTasks);
    thymeleafContext.setVariable("upcomingCount", totalUpcomingTasks);
    String body =
        defaultLang.equalsIgnoreCase(AppConstants.JA)
            ? templateEngine.process("task-remainder-email-ja", thymeleafContext)
            : templateEngine.process("task-remainder-email-en", thymeleafContext);
    log.info("The thymleaf processing completed!");
    return body;
  }
}
