package com.sunsum.aspect;

import com.sunsum.model.entity.BaseEntity;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Slf4j
@Aspect
@Component
public class EntityBeforeAspect {

  // The pointcut added to work for both save and SaveAll methods.
  @Pointcut("execution(*  org.springframework.data.jpa.repository.JpaRepository.save(..))")
  private void selectSaveEntity() {}

  @Pointcut("execution(*  org.springframework.data.jpa.repository.JpaRepository+.saveAll(*))")
  private void selectSaveAllEntity() {}

  @Before("selectSaveEntity()")
  private void beforeSaveEntity(JoinPoint joinPoint) {
    try {
      Object arg = joinPoint.getArgs()[0];
      if (arg instanceof BaseEntity entity) {
        Object currentLoggedInUserId = getCurrentLoggedInUserId();
        setBaseEntityProperties(entity, currentLoggedInUserId);
      }
    } catch (Exception e) {
      log.error(
          "Exception occurred while setting base entity due to {} {}",
          e.getMessage(),
          e.getCause());
    }
  }

  @Before("selectSaveAllEntity()")
  private void beforeSaveAllEntity(JoinPoint joinPoint) {
    try {

      Object arg = joinPoint.getArgs()[0];

      if (arg instanceof Iterable<?> entities) {
        Object currentLoggedInUserId = getCurrentLoggedInUserId();
        for (Object entity : entities) {
          if (entity instanceof BaseEntity baseEntity)
            setBaseEntityProperties(baseEntity, currentLoggedInUserId);
        }
      }

    } catch (Exception e) {
      log.error(
          "Exception occurred while setting base entity due to {} {}",
          e.getMessage(),
          e.getCause());
    }
  }

  private static Object getCurrentLoggedInUserId() {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    return Objects.requireNonNull(authentication).getPrincipal();
  }

  private void setBaseEntityProperties(BaseEntity entity, Object currentLoggedInUserId) {
    if (entity.getCreatedBy() == null && entity.getCreatedDate() == null) {
      entity.setCreatedBy(Long.valueOf(currentLoggedInUserId.toString()));
      entity.setCreatedDate(LocalDateTime.now(ZoneId.of(ZoneId.SHORT_IDS.get("JST"))));
    }
    entity.setLastUpdatedBy(Long.valueOf(currentLoggedInUserId.toString()));
    entity.setLastUpdatedDate(LocalDateTime.now(ZoneId.of(ZoneId.SHORT_IDS.get("JST"))));
  }
}
