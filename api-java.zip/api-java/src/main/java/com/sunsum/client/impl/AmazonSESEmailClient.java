package com.sunsum.client.impl;

import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
import com.amazonaws.services.simpleemail.model.AmazonSimpleEmailServiceException;
import com.amazonaws.services.simpleemail.model.Body;
import com.amazonaws.services.simpleemail.model.Content;
import com.amazonaws.services.simpleemail.model.Destination;
import com.amazonaws.services.simpleemail.model.Message;
import com.amazonaws.services.simpleemail.model.SendEmailRequest;
import com.sunsum.constants.AppConstants;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.client.EmailClient;
import com.sunsum.model.dto.EmailDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AmazonSESEmailClient implements EmailClient {

  private final AmazonSimpleEmailService amazonSimpleEmailService;

  @Autowired
  public AmazonSESEmailClient(AmazonSimpleEmailService amazonSimpleEmailService) {
    this.amazonSimpleEmailService = amazonSimpleEmailService;
  }

  @Value("${cloud.aws.ses.sourceArn}")
  private String sourceArn;

  @Override
  public ResponseEntity<String> sendEmail(EmailDTO emailDto) {
    try {
      SendEmailRequest request =
          new SendEmailRequest()
              .withDestination(new Destination().withToAddresses(emailDto.getToEmail()))
              .withMessage(
                  new Message()
                      .withSubject(
                          new Content()
                              .withCharset(AppConstants.UTF_8)
                              .withData(emailDto.getSubject()))
                      .withBody(
                          new Body()
                              .withHtml(
                                  new Content()
                                      .withCharset(AppConstants.UTF_8)
                                      .withData(emailDto.getBody()))
                              .withText(
                                  new Content()
                                      .withCharset(AppConstants.UTF_8)
                                      .withData(emailDto.getBody()))))
              .withSource(emailDto.getFromEmail())
              .withSourceArn(sourceArn);

      // Send the email
      amazonSimpleEmailService.sendEmail(request);
      return new ResponseEntity<>("Email sent to " + emailDto.getToEmail(), HttpStatus.OK);
    } catch (AmazonSimpleEmailServiceException e) {
      log.error("Exception occurred while sending email with SES", e);
      throw new BusinessRuleException("Error sending email with SES", HttpStatus.BAD_REQUEST);
    } catch (Exception e) {
      log.error("Exception occurred while sending email", e);
      throw new BusinessRuleException(
          "Exception occurred while sending email", HttpStatus.BAD_REQUEST);
    }
  }
}
