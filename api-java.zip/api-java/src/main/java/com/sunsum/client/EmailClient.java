package com.sunsum.client;

import com.sunsum.model.dto.EmailDTO;
import java.io.IOException;
import org.springframework.http.ResponseEntity;

public interface EmailClient {
  ResponseEntity<String> sendEmail(EmailDTO dto) throws IOException;
}
