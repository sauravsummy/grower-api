package com.sunsum.exception;

import java.io.Serial;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class BusinessRuleException extends RuntimeException {

  @Serial private static final long serialVersionUID = -699134950520558547L;

  private final String errorMessage;
  private final HttpStatus httpStatus;

  public BusinessRuleException(String errorMessage, HttpStatus httpStatus) {
    super(errorMessage);
    this.errorMessage = errorMessage;
    this.httpStatus = httpStatus;
  }
}
