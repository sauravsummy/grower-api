package com.sunsum.exception;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.text.SimpleDateFormat;
import java.util.Date;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ErrorDetails {

  @JsonIgnore private final SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

  private String date;
  private String message;

  public ErrorDetails() {
    this.date = fmt.format(new Date());
  }

  public ErrorDetails(final String message) {
    this.date = fmt.format(new Date());
    this.message = message;
  }
}
