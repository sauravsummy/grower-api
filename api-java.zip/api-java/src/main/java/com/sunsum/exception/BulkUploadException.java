package com.sunsum.exception;

public class BulkUploadException extends RuntimeException {

  public BulkUploadException(String message, Throwable cause) {
    super(message, cause);
  }

  public BulkUploadException(String message) {
    super(message);
  }
}
