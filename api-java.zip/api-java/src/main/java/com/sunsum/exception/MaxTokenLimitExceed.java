package com.sunsum.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class MaxTokenLimitExceed extends RuntimeException {
  private final String errorMessage;
  private final HttpStatus httpStatus;

  public MaxTokenLimitExceed(String errorMessage, HttpStatus httpStatus) {
    super(errorMessage);
    this.errorMessage = errorMessage;
    this.httpStatus = httpStatus;
  }
}
