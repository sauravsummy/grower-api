package com.sunsum.exception;

public class BulkDownloadException extends RuntimeException {

  public BulkDownloadException(String message, Throwable cause) {
    super(message, cause);
  }

  public BulkDownloadException(String message) {
    super(message);
  }
}
