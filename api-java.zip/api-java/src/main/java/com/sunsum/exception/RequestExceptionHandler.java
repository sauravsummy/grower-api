package com.sunsum.exception;

import com.sunsum.model.ErrorResponse;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

@Slf4j
@RestControllerAdvice
public class RequestExceptionHandler {

  private static final String PRINT_EXCEPTION_MESSAGE =
      "Exception occur with cause = '{}' and exception = '{}'";

  @ExceptionHandler({BusinessRuleException.class})
  @Order(Ordered.HIGHEST_PRECEDENCE)
  public ResponseEntity<ErrorDetails> businessRuleError(BusinessRuleException e) {

    log.error(
        PRINT_EXCEPTION_MESSAGE, e.getCause() != null ? e.getCause() : "NULL", e.getMessage());

    return ResponseEntity.status(e.getHttpStatus()).body(new ErrorDetails(e.getErrorMessage()));
  }

  @ExceptionHandler({Exception.class})
  @Order(Ordered.LOWEST_PRECEDENCE)
  public ResponseEntity<Object> handleAll(Exception ex, WebRequest request) {
    log.error(
        PRINT_EXCEPTION_MESSAGE,
        ex.getCause() != null ? ex.getCause() : "NULL",
        ex.getMessage(),
        ex);
    ErrorResponse apiError = new ErrorResponse();
    apiError.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR);
    apiError.setMessage(ex.getMessage());
    return new ResponseEntity<>(apiError, HttpStatus.INTERNAL_SERVER_ERROR);
  }

  @ExceptionHandler
  public ResponseEntity<ErrorDetails> invalidArgumentError(MethodArgumentNotValidException e) {

    log.error(
        PRINT_EXCEPTION_MESSAGE, e.getCause() != null ? e.getCause() : "NULL", e.getMessage());

    return ResponseEntity.status(HttpStatus.BAD_REQUEST)
        .body(new ErrorDetails(Objects.requireNonNull(e.getFieldError()).getDefaultMessage()));
  }

  @ExceptionHandler(AccessDeniedException.class)
  public ResponseEntity<ErrorDetails> handleAccessDeniedException(AccessDeniedException e) {
    log.error(
        PRINT_EXCEPTION_MESSAGE, e.getCause() != null ? e.getCause() : "NULL", e.getMessage());

    return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new ErrorDetails(e.getMessage()));
  }
}
