package com.sunsum.repository;

import com.sunsum.model.entity.UserProfile;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserProfileRepository extends JpaRepository<UserProfile, Long> {

  Optional<UserProfile> findByEmail(String email);

  Optional<UserProfile> findByEmailIgnoreCase(String email);

  Optional<UserProfile> findById(Long id);

  Optional<UserProfile> findByPhoneNo(Long phoneNo);

  List<UserProfile> findAllByOrderByIdAsc();

  List<UserProfile> findAllByIsActive(Boolean isActive);
}
