package com.sunsum.repository;

import com.sunsum.model.entity.Task;
import com.sunsum.model.entity.TaskGroup;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface TaskRepository extends JpaRepository<Task, Long> {

  Optional<Task> findByTitleAndTaskGroup_Id(String title, Long taskGroupId);

  List<Task> findAllByOrderByIdAsc();

  List<Task> findByTaskGroup_Id(Long taskGroupId);

  @Query(
      value =
          """
      select * from task t inner join task_group tg on tg.id = t.taskgroup_id
      inner join field_task_group ftg on ftg.taskgroup_id = tg.id
      inner join field f on f.id = ftg.field_id
      where f.id in (:fieldId) and
      f.status = 'ACTIVE' and
      ftg.status = 'ACTIVE' and
      tg.status = 'ACTIVE'
      """,
      nativeQuery = true)
  List<Task> findTasksByFieldId(Long fieldId);

  Optional<Task> findById(Long id);

  Optional<Task> findByTaskGroupAndId(TaskGroup taskGroup, Long taskId);
}
