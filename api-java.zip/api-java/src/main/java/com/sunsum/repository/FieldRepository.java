package com.sunsum.repository;

import com.sunsum.model.dto.FieldTitle;
import com.sunsum.model.dto.FieldDetails;
import com.sunsum.model.entity.Field;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface FieldRepository extends JpaRepository<Field, Long> {

  @Query(
      value =
          """
              select f.id, f.title, f.gps_coordinates as gps
              from public.field f where f.farmholding_id = :farmHoldingId and f.status = 'ACTIVE'
              """,
      nativeQuery = true)
  List<FieldTitle> getFields(Long farmHoldingId);

  Optional<Field> findById(Long id);

  @Query(
      value =
          """
              select f.title,
              f.gps_coordinates as gpsCoordinates,
              f.acreage,
              f.note as memo1,
              f.zip_code as zipCode,
              f.photo_path as photoPath
              from Field f where f.id = :id
              """,
      nativeQuery = true)
  Optional<FieldDetails> getFieldDetails(Long id);

  List<Field> findAllByOrderByIdAsc();

  @Query(
      value =
          """
        select f.id from field f inner join organization o on o.id = f.farmholding_id
        where o.id = :farmholdingId and f.status = 'ACTIVE'
      """,
      nativeQuery = true)
  List<Long> findIdByFarmHoldingId(Long farmholdingId);

  @Query(
      value =
          """
        select o.id from field f inner join organization o on o.id = f.farmholding_id
        where f.id = :fieldId and f.status = 'ACTIVE' and o.type = 'FARM_HOLDINGS'
      """,
      nativeQuery = true)
  List<Long> findFarmHoldingIdByFieldId(Long fieldId);

  List<Field> findByFarmHoldingIdIn(List<Long> organizationIds);

  List<Field> findByFarmHoldingId(Long id);

  Page<Field> findAll(Pageable pageable);
}
