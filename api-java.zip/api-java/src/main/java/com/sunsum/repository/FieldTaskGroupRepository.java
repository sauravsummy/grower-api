package com.sunsum.repository;

import com.sunsum.constants.Status;
import com.sunsum.model.entity.FieldTaskGroup;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FieldTaskGroupRepository extends JpaRepository<FieldTaskGroup, Long> {
  Optional<FieldTaskGroup> findByFieldIdAndTaskGroupIdAndFiledTaskGroupStatus(
      Long fieldId, Long taskGroupId, Status status);

  List<FieldTaskGroup> findByFieldId(Long id);
}
