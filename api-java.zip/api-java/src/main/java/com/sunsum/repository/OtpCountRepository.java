package com.sunsum.repository;

import com.sunsum.model.entity.OTPCountTracker;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OtpCountRepository extends JpaRepository<OTPCountTracker, String> {
  Optional<OTPCountTracker> findByRecipientId(String recipientId);
}
