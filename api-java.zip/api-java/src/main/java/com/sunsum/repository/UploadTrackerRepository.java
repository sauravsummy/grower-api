package com.sunsum.repository;

import com.sunsum.model.entity.UploadTracker;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UploadTrackerRepository extends JpaRepository<UploadTracker, Long> {
  /**
   * It fetches the last inserted record for the respective file type.
   *
   * @return List<UploadTracker>
   */
  @Query(
      """
            SELECT ut FROM UploadTracker ut
            WHERE (ut.fileType, ut.createdDate) IN
            (SELECT ut2.fileType, MAX(ut2.createdDate) FROM UploadTracker ut2 GROUP BY ut2.fileType)
            ORDER BY ut.fileType
            """)
  List<UploadTracker> findLatestRecordsForEachFileType();
}
