package com.sunsum.repository;

import com.sunsum.constants.OrgType;
import com.sunsum.model.dto.FarmHolding;
import com.sunsum.model.entity.Organization;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface OrganisationRepository extends JpaRepository<Organization, Long> {

  Optional<Organization> findById(Long id);

  @Query(
      value =
          """
            select o.id, o.title from Organization o inner join public.user u on u.org_id = o.id
            where u.id = :userId and o.type = 'FARM_HOLDINGS' and o.status = 'ACTIVE'
            """,
      nativeQuery = true)
  List<FarmHolding> findByFieldManager(long userId);

  @Query(
      value =
          """
                SELECT distinct(o.id), o.title FROM public.Organization o
                INNER JOIN public.user fm ON fm.org_id = o.id
                INNER JOIN public.user fs ON fm.id = fs.id
                WHERE fs.reporting_id = :userId
                AND o.type = 'FARM_HOLDINGS'
                AND o.status = 'ACTIVE'
              """,
      nativeQuery = true)
  List<FarmHolding> findByFieldSupporter(long userId);

  @Query(
      value =
          """
                SELECT distinct(o.id), o.title FROM public.Organization o
                INNER JOIN public.user fm ON fm.org_id = o.id
                INNER JOIN public.user fs ON fm.id = fs.id
                INNER JOIN public.user pa ON fs.reporting_id = pa.id
                WHERE pa.reporting_id = :userId
                AND o.type = 'FARM_HOLDINGS'
                AND o.status = 'ACTIVE'
              """,
      nativeQuery = true)
  List<FarmHolding> findByProjectAdmin(@Param("userId") long userId);

  List<Organization> findAllByOrderByIdAsc();

  Optional<Organization> findByIdAndType(Long id, OrgType orgType);
}
