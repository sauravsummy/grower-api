package com.sunsum.repository;

import com.sunsum.model.entity.Token;
import com.sunsum.model.entity.UserProfile;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface TokenRepository extends JpaRepository<Token, Integer> {

  Optional<Token> findByValue(String token);

  List<Token> findByUserProfile(UserProfile user);

  @Query(
      """
            select t from Token t inner join UserProfile u on t.userProfile.id = u.id
            where u.id = :userId and t.revoked = false
            """)
  Optional<Token> findAllValidTokenByUserId(Long userId);

  void deleteByUserProfile(UserProfile userProfile);
}
