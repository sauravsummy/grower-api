package com.sunsum.repository;

import com.sunsum.model.entity.UserFcmToken;
import com.sunsum.model.entity.UserProfile;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserFcmTokenRepository extends JpaRepository<UserFcmToken, UUID> {
  List<UserFcmToken> findByUserAndIsActive(UserProfile user, boolean isActive);

  Optional<UserFcmToken> findByUserAndDeviceType(UserProfile user, String deviceType);
}
