package com.sunsum.repository;

import com.sunsum.model.dto.FieldTaskDetails;
import com.sunsum.model.entity.TaskField;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface TaskFieldRepository extends JpaRepository<TaskField, Long> {

  List<TaskField> findByFieldId(Long fieldId);

  Optional<TaskField> findByTaskIdAndFieldId(Long taskId, Long fieldId);

  @Query(
      "SELECT COUNT(tf) FROM TaskField tf WHERE tf.field.id = :fieldId AND tf.dueDate < CURRENT_DATE") // overdue
  int countOverdueTasksByFieldId(Long fieldId);

  @Query(
      "SELECT COUNT(tf) FROM TaskField tf WHERE tf.field.id = :fieldId AND tf.executableDate BETWEEN CURRENT_DATE AND CURRENT_DATE + 2") // upcoming in 2 days
  int countExecutableTasksByFieldId(Long fieldId);

  List<TaskField> findByFieldIdIn(List<Long> fieldId);

  @Query(
      """
      select tasks as task, f.id as fieldId, f.title as fieldTitle, f.gpsCoordinates as gps  from Field f join f.taskGroups taskGroups
       join taskGroups.tasks tasks
       inner join FieldTaskGroup ftg on (ftg.taskGroupId = taskGroups.id and ftg.fieldId = f.id)
       where f.id in (:fieldIds) and f.status = 'ACTIVE' and
       taskGroups.status = 'ACTIVE' and
       ftg.filedTaskGroupStatus = 'ACTIVE'
      """)
  List<FieldTaskDetails> findFieldAndTasksByFieldIdIn(List<Long> fieldIds);
}
