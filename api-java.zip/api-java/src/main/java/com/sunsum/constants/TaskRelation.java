package com.sunsum.constants;

import lombok.Getter;

@Getter
public enum TaskRelation {
  NONE("None"),
  FOLLOW("Follow"),
  WITH_IN("Within"),
  BLOCKED_BY("Blocked by"),
  FIXED_DUE_DATE("Fixed Due Date");

  String value;

  TaskRelation(String value) {
    this.value = value;
  }

  public static TaskRelation fromString(String text) {
    for (TaskRelation enumValue : TaskRelation.values()) {
      if (enumValue.value.equalsIgnoreCase(text)) {
        return enumValue;
      }
    }
    throw new IllegalArgumentException("No constant with text " + text + " found");
  }
}
