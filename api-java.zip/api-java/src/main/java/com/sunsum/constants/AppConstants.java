package com.sunsum.constants;

public class AppConstants {

  private AppConstants() {}

  public static final String EMPTY_STRING = "";

  public static final String NO_PASSWORD = "NO_PASSWORD";

  public static final String TIME_ZONE_OFFSET = "time-zone-offset";

  public static final String OTP_SENT_MSG = "Otp sent Successfully";

  public static final String OTP_FAILED_MSG = "OTP Failed";

  public static final String TOKEN = "token";
  public static final String COMMA = ",";
  public static final String SHEET_ORGANISATION = "ORGANISATION";
  public static final String SHEET_TASKGROUP = "TASKGROUP";
  public static final String SHEET_PROJECT = "PROJECT";
  public static final String SHEET_USER = "USER";
  public static final String SHEET_TASK = "TASK";
  public static final String DATE_FORMAT_FOR_FILE_NAME = "yyyy-MM-dd_HH-mm-ss";
  public static final String ATTACHMENT_FILENAME_QUERY_HEADER_VALUE = "attachment; filename=";
  public static final String EXCEL_EXTENSION = ".xlsx";

  public static final String ID = "Id";
  public static final String NAME = "Name";
  public static final String STATUS = "Status";
  public static final String ACTIVE = "Active";
  public static final String EMAIL_ID = "Email Id";
  public static final String PHONE = "Phone";
  public static final String REPORTING_TO = "Reporting To";
  public static final String MEMO_1 = "Memo_1";
  public static final String MEMO_2 = "Memo_2";
  public static final String MEMO_3 = "Memo_3";
  public static final String MEMO_4 = "Memo_4";
  public static final String MEMO_5 = "Memo_5";
  public static final String JST = "JST";
  public static final String ORGANISATION_ID = "Organisation Id";

  public static final String FARM_HOLDING_ID = "Farm Holding Id";

  public static final String IS_ACTIVE = "Is Active";
  public static final String ROLE = "Role";
  public static final String HYPHEN = "-";
  public static final String TITLE = "Title";
  public static final String TYPE = "Type";
  public static final String UPLOADER = "Uploader";
  public static final String DOWNLOADER = "Downloader";
  public static final String AREA = "Area";
  public static final String YEAR = "Year";
  public static final String OWNER = "Owner";
  public static final String PROJECT_ID = "Project Id";

  public static final String MEMO = "Memo";

  public static final String BRIEF = "Brief";

  public static final String ORDER = "Order";

  public static final String IS_LOCKED = "is Locked";

  public static final String FILE_PATH_SEPARATOR = "/";

  public static final String TASKGROUP_ID = "TaskGroup Id";

  public static final String RELATED_TASK_TITLE = "Related Task Title";
  public static final String RELATION = "Relation";
  public static final String RELATION_DAYS = "Relation Days";
  public static final String FIXED_DUE_DATE = "Fixed Due Date";
  public static final String CUSTOM_DEFINITION = "Custom Definition";
  public static final String COLON = ":";
  public static final String GPS_COORD = "GPS COORD";
  public static final String ZIP_CODE = "Zip Code";
  public static final String ACREAGE = "Acreage";
  public static final String PHOTO_PATH = "Photo Path";
  public static final String SHEET_FIELD = "FIELD";
  public static final String TASK_GROUP_ID = "Task Group Id";
  public static final String FIELD_TASK_GROUP_MEMO = "Field Task Group Memo";
  public static final String NO_PHOTOS = "No Photos";
  public static final String FIELD_TASK_GROUP_STATUS = "Field Task Group Status";
  public static final String NULL_STRING = "null";
  public static final String TASK_EXECUTION_STATUS_INEXECUTABLE = "inexecutable";
  public static final String TASK_EXECUTION_STATUS_COMPLETED = "completed";
  public static final String TASK_EXECUTION_STATUS_OVERDUE = "overdue";
  public static final String TASK_EXECUTION_STATUS_EXECUTABLE = "executable";
  public static final String TASK_EXECUTION_STATUS_INEXECUTABLE_2D = "inexecutable_2d";

  public static final String UTF_8 = "UTF-8";

  public static final String CROPWISE_GROWER = "Cropwise Grower";
  public static final String JA = "ja";
}
