package com.sunsum.constants;

public enum CustomType {
  TEXT,
  SINGLE_SELECTION,
  MULTI_SELECTION,
  PHOTO_ATTACHMENT;
}
