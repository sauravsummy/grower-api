package com.sunsum.constants;

public enum UserRole {
  ROLE_PROJECT_ADMIN,
  ROLE_USER,
  ROLE_FIELD_MANAGER,
  ROLE_FIELD_SUPPORTER
}
