package com.sunsum.constants;

import lombok.Getter;

@Getter
public enum Status {
  ACTIVE("Active"),
  INACTIVE("Inactive");

  String value;

  Status(String value) {
    this.value = value;
  }

  public static Status fromString(String text) {
    for (Status enumValue : Status.values()) {
      if (enumValue.value.equalsIgnoreCase(text)) {
        return enumValue;
      }
    }
    throw new IllegalArgumentException("No constant with text " + text + " found");
  }
}
