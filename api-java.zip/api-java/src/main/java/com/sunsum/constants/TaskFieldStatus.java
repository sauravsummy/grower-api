package com.sunsum.constants;

public enum TaskFieldStatus {
  INITIAL,
  ACKNOWLEDGED,
  CONFIRMED,

  COMPLETED;
}
