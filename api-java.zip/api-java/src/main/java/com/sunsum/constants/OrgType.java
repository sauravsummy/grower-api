package com.sunsum.constants;

import lombok.Getter;

@Getter
public enum OrgType {
  SYNGENTA("Syngenta"),
  CHANNEL_PARTNER("Channel Partner"),
  FARM_HOLDINGS("Farm Holdings");

  String value;

  OrgType(String value) {
    this.value = value;
  }

  public static OrgType fromString(String text) {
    for (OrgType enumValue : OrgType.values()) {
      if (enumValue.value.equalsIgnoreCase(text)) {
        return enumValue;
      }
    }
    throw new IllegalArgumentException("No constant with text " + text + " found");
  }
}
