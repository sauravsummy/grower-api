package com.sunsum.constants;

public enum ChannelType {
  EMAIL_ID,
  PHONE_NUMBER
}
