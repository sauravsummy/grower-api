package com.sunsum.constants;

public class ErrorMsgConstants {

  private ErrorMsgConstants() {}

  public static final String NO_RECORD_FOUND = "NO_RECORD_FOUND";
  public static final String ERR_NOT_AUTHORIZED = "ERR_NOT_AUTHORIZED";
  public static final int ERR_STATUS = 400;

  public static final String NULL_DATE = "NULL_DATE";
  public static final String INVALID_DATE = "INVALID_DATE";
  public static final String UNABLE_TO_PROCESS_THE_UPLOADED_FILE =
      "UNABLE_TO_PROCESS_THE_UPLOADED_FILE";

  public static final String MANDATORY_COLUMNS_MISSING = "MANDATORY_COLUMNS_MISSING";

  public static final String INVALID_SHEET_NAME = "INVALID_SHEET_NAME";
  public static final String UNAUTHORIZED_USER_MSG = "UNAUTHORIZED_USER_MSG";

  public static final String INVALID_FILE_FORMAT = "INVALID_FILE_FORMAT";

  public static final String GET_TASKS_ERROR_MSG =
      "error occurred while getting tasks for farmholding";

  public static final String UNAUTHORIZED_USER_FOR_FIELD = "UNAUTHORIZED_USER_FOR_FIELD";

  public static final String UNAUTHORIZED_USER_FOR_FARMHOLDING =
      "UNAUTHORIZED_USER_FOR_FARMHOLDING";

  public static final String UNABLE_TO_AUTHORIZE_USER = "UNABLE_TO_AUTHORIZE_USER";

  public static final String MAX_DEVICE_LOGIN_LIMIT_REACHED = "MAX_DEVICE_LOGIN_LIMIT_REACHED";

  public static final String UNABLE_TO_UPDATE_TASK_STATUS = "UNABLE_TO_UPDATE_TASK_STATUS";
}
