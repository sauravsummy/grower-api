package com.sunsum.constants;

import lombok.Getter;

@Getter
public enum TaskType {
  ACTION("Action"),
  REPORT("Report");

  String value;

  TaskType(String value) {
    this.value = value;
  }

  public static TaskType fromString(String text) {
    for (TaskType enumValue : TaskType.values()) {
      if (enumValue.value.equalsIgnoreCase(text)) {
        return enumValue;
      }
    }
    throw new IllegalArgumentException("No constant with text " + text + " found");
  }
}
