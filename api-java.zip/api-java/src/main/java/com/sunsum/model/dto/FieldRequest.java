package com.sunsum.model.dto;

import java.math.BigDecimal;
import java.util.List;
import javax.validation.constraints.NotNull;
import lombok.*;
import org.springframework.web.multipart.MultipartFile;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class FieldRequest {

  @NotNull private String title;

  private BigDecimal acreage;

  @NotNull private String gpsCoordinates;

  private String zipCode;

  private List<MultipartFile> files;

  @NotNull private Long farmHoldingId;

  private String memo1;
}
