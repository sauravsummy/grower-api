package com.sunsum.model.entity;

import com.sunsum.constants.Status;
import java.util.Set;
import javax.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "project", schema = "public")
@NoArgsConstructor
public class Project extends BaseEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", nullable = false)
  private Long id;

  @Column(name = "title", nullable = false)
  private String title;

  @Column private String area;
  @Column private Integer year;

  @Enumerated(EnumType.STRING)
  @Column
  private Status status;

  @OneToMany(mappedBy = "project")
  private Set<TaskGroup> taskGroups;

  @ManyToOne
  @JoinColumn(name = "owner")
  private UserProfile owner;

  @Column private String memo1;
  @Column private String memo2;
  @Column private String memo3;
  @Column private String memo4;
  @Column private String memo5;
}
