package com.sunsum.model.dto;

import com.sunsum.constants.TaskFieldStatus;
import java.util.List;
import javax.validation.constraints.NotNull;
import org.springframework.web.multipart.MultipartFile;

public record TaskStatusUpdateRequest(
    @NotNull TaskFieldStatus status,
    String CompletionDate,
    String reportDefinitions,
    @NotNull Long fieldId,
    List<MultipartFile> images) {}
