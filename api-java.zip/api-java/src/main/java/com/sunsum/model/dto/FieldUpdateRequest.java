package com.sunsum.model.dto;

import java.math.BigDecimal;
import java.util.List;
import javax.validation.constraints.NotNull;
import lombok.*;
import org.springframework.web.multipart.MultipartFile;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class FieldUpdateRequest {

  @NotNull private String title;

  private BigDecimal acreage;

  @NotNull private String gpsCoordinates;

  private String zipCode;

  private List<MultipartFile> files;

  private List<String> photoPath;

  private String memo1;

  private String memo2;

  private String memo3;

  private String memo4;

  private String memo5;
}
