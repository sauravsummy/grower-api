package com.sunsum.model.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.sunsum.constants.TaskFieldStatus;
import com.sunsum.constants.TaskType;
import com.sunsum.model.entity.CustomDefinition;
import java.time.LocalDate;
import java.util.List;
import lombok.*;
import org.springframework.data.geo.Point;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaskView {

  private Long taskId;
  private Long fieldId;
  private String taskTitle;
  private String taskBrief;
  private TaskType taskType;
  private TaskFieldStatus taskStatus;
  private LocalDate completionDate;
  private List<CustomDefinition> reportDefinitions;
  private Point gpsCoordinate;
}
