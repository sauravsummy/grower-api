package com.sunsum.model.dto;

public interface FieldTitle {

  Long getId();

  String getTitle();

  byte[] getGps();
}
