package com.sunsum.model.entity;

import com.sunsum.constants.TaskFieldStatus;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;
import java.time.LocalDate;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

@Entity
@Getter
@Setter
@TypeDef(name = "json", typeClass = JsonBinaryType.class)
@Table(name = "task_field", schema = "public")
@AllArgsConstructor
@NoArgsConstructor
public class TaskField extends BaseEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", nullable = false)
  private Long id;

  @Column(name = "due_date")
  private LocalDate dueDate;

  @Column(name = "task_status", length = 20)
  @Enumerated(EnumType.STRING)
  private TaskFieldStatus taskStatus;

  @Type(type = "json")
  @Column(name = "custom_input", columnDefinition = "JSON")
  private List<CustomDefinition> customInput;

  @Column(name = "task_execution_memo")
  private String taskExecutionMemo;

  @Column(name = "completion_date")
  private LocalDate completionDate;

  @Column(name = "executable_date")
  private LocalDate executableDate;

  @ManyToOne
  @JoinColumn(name = "task_id")
  private Task task;

  @ManyToOne
  @JoinColumn(name = "field_id")
  private Field field;

  @ManyToOne
  @JoinColumn(name = "field_manager")
  private UserProfile fieldManager;
}
