package com.sunsum.model.dto;

import com.sunsum.model.entity.IngestionStatus;
import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class RowIngestionResult {

  private IngestionStatus status;

  private Integer rowNumber;

  private String failureReason;
}
