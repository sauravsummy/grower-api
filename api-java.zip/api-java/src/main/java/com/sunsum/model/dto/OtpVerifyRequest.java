package com.sunsum.model.dto;

import com.sunsum.constants.ChannelType;
import javax.validation.constraints.NotNull;
import lombok.*;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
public class OtpVerifyRequest {

  @NotNull(message = "Recipient id shouldn't be null")
  private String recipientId;

  @NotNull(message = "otp shouldn't be null")
  private String otp;

  @NotNull(message = "channelType mode shouldn't be null")
  private ChannelType channelType;
}
