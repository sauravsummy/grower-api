package com.sunsum.model.entity;

import com.sunsum.constants.Status;
import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "field_task_group", schema = "public")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class FieldTaskGroup extends BaseEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", nullable = false)
  private Long id;

  @Column(name = "field_id")
  private Long fieldId;

  @Column(name = "taskgroup_id")
  private Long taskGroupId;

  @Column(name = "status")
  @Enumerated(EnumType.STRING)
  private Status filedTaskGroupStatus;

  @Column(name = "field_task_group_memo")
  private String fieldTaskGroupMemo;
}
