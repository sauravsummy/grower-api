package com.sunsum.model.entity;

import com.sunsum.constants.Status;
import com.vladmihalcea.hibernate.type.array.StringArrayType;
import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import javax.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.springframework.data.geo.Point;

@Entity
@DynamicUpdate
@Data
@Table(name = "field", schema = "public")
@NoArgsConstructor
@TypeDef(name = "string-array", typeClass = StringArrayType.class)
public class Field extends BaseEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", nullable = false)
  private Long id;

  @Column(name = "title", length = 50)
  private String title;

  @Column(name = "acreage", precision = 10, scale = 2)
  private BigDecimal acreage;

  @Column(name = "gps_coordinates")
  private Point gpsCoordinates;

  @Column(name = "zip_code", length = 10)
  private String zipCode;

  @Type(type = "string-array")
  @Column(name = "photo_path", columnDefinition = "text[]")
  private String[] photoPath;

  @Column(name = "status", length = 20)
  @Enumerated(EnumType.STRING)
  private Status status;

  @Column(name = "note")
  private String note;

  @ManyToOne
  @JoinColumn(name = "farmholding_id")
  private Organization farmHolding;

  @ManyToMany(mappedBy = "fields")
  private List<TaskGroup> taskGroups;

  @Column(name = "memo1")
  private String memo1;

  @Column(name = "memo2")
  private String memo2;

  @Column(name = "memo3")
  private String memo3;

  @Column(name = "memo4")
  private String memo4;

  @Column(name = "memo5")
  private String memo5;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    Field field = (Field) o;
    return Objects.equals(id, field.id) && Objects.equals(title, field.title);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, title);
  }
}
