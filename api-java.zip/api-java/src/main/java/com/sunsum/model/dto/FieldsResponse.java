package com.sunsum.model.dto;

import java.util.List;

public record FieldsResponse(List<FieldBasicInfo> fieldTitles) {}
