package com.sunsum.model.dto;

import com.sunsum.constants.TaskRelation;
import com.sunsum.constants.TaskType;
import com.sunsum.model.entity.CustomDefinition;
import java.time.LocalDate;
import java.util.List;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class TaskUpdateRequest {

  private Long id;
  private String title;
  private TaskType type;
  private String brief;
  private List<CustomDefinition> customDefinition;
  private Long taskGroupId;
  private Boolean isLocked;
  private Integer order;
  private TaskRelation relation;
  private Integer relatedDays;
  private LocalDate fixedDueDate;
  private Long relatedTaskId;
  private String memo1;
  private String memo2;
  private String memo3;
  private String memo4;
  private String memo5;
}
