package com.sunsum.model.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "otpcount", schema = "public")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class OTPCountTracker implements Serializable {

  @Id
  @Column(name = "recipient_id")
  private String recipientId;

  @Column(name = "otpcount")
  private int otpCount;

  @Column(name = "lastotptimestamp")
  private Timestamp lastOtpTimestamp;
}
