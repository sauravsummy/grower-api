package com.sunsum.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BulkUploadTracker {

  private String fileType;
  private Integer total;
  private Integer success;
  private Integer failed;
  private Integer skipped;
  private String createdBy;

  @JsonProperty("createdAt")
  private LocalDateTime createdDate;
}
