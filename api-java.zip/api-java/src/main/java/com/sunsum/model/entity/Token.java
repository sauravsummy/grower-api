package com.sunsum.model.entity;

import javax.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "token", schema = "public")
@Setter
@Getter
@NoArgsConstructor
public class Token {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", nullable = false)
  private long id;

  @Column(name = "token")
  private String value;

  @Column private boolean revoked;

  @ManyToOne
  @JoinColumn(name = "user_id")
  private UserProfile userProfile;
}
