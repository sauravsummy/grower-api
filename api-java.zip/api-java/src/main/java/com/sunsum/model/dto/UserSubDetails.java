package com.sunsum.model.dto;

public record UserSubDetails(Long id, String email, String name) {}
