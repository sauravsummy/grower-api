package com.sunsum.model.dto;

import lombok.*;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PushNotificationReqDto {

  private String to;
  private Notification notification;
}
