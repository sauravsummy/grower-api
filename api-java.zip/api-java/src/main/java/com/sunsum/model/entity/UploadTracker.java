package com.sunsum.model.entity;

import java.time.LocalDateTime;
import javax.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Entity
@Table(name = "upload_tracker", schema = "public")
@NoArgsConstructor
@Getter
@Setter
public class UploadTracker {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", nullable = false)
  private Long id;

  @Column(name = "file_type", nullable = false)
  private String fileType;

  @Column(name = "total", nullable = false)
  private Integer total;

  @Column(name = "success", nullable = false)
  private Integer success;

  @Column(name = "failed", nullable = false)
  private Integer failed;

  @Column(name = "skipped", nullable = false)
  private Integer skipped;

  @Column(name = "created_by", nullable = false)
  private Long createdBy;

  @Column(name = "created_at", nullable = false)
  private LocalDateTime createdDate;
}
