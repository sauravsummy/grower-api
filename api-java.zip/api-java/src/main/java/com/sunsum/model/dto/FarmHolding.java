package com.sunsum.model.dto;

public interface FarmHolding {
  Long getId();

  String getTitle();
}
