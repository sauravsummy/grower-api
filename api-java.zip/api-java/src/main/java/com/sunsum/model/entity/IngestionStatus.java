package com.sunsum.model.entity;

public enum IngestionStatus {
  INSERTED,
  FAILED,
  UPDATED,
  VALIDATION_FAILED,
}
