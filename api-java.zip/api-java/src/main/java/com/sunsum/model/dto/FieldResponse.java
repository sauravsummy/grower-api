package com.sunsum.model.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.geo.Point;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FieldResponse {

  private String title;
  private BigDecimal acreage;
  private Point gpsCoordinates;
  private String zipCode;
  private String[] photoPath;
  private String memo1;
  private String memo2;
  private String memo3;
  private String memo4;
  private String memo5;
}
