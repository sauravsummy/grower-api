package com.sunsum.model.entity;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import javax.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Entity
@Getter
@Setter
@Table(name = "user", schema = "public")
@SuperBuilder(toBuilder = true)
@NoArgsConstructor
public class UserProfile extends BaseEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", nullable = false)
  private Long id;

  private String name;
  private String email;

  @Column(name = "phone_no")
  private Long phoneNo;

  @OneToOne
  @JoinColumn(name = "reporting_id")
  private UserProfile reportingTo;

  @Column(name = "is_active")
  private Boolean isActive;

  @OneToMany(mappedBy = "owner")
  private Set<Project> projects;

  @Column(name = "password")
  private String password;

  @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
  @JoinTable(
      name = "user_role",
      joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "id"),
      inverseJoinColumns = @JoinColumn(name = "role_id", referencedColumnName = "id"))
  private Set<Role> roles;

  @OneToMany(mappedBy = "taskGroupOwner")
  private Set<TaskGroup> taskGroups;

  @OneToMany(mappedBy = "fieldManager")
  private Set<TaskField> taskFields;

  @ManyToOne
  @JoinColumn(name = "org_id")
  private Organization organization;

  @OneToMany(mappedBy = "userProfile")
  private List<Token> tokens;

  @Column private String memo1;
  @Column private String memo2;
  @Column private String memo3;
  @Column private String memo4;
  @Column private String memo5;

  @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  private List<UserFcmToken> notifications;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    UserProfile user = (UserProfile) o;
    return Objects.equals(id, user.id)
        && Objects.equals(name, user.name)
        && Objects.equals(email, user.email)
        && Objects.equals(phoneNo, user.phoneNo);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, email, phoneNo);
  }
}
