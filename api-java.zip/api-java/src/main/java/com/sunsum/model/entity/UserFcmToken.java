package com.sunsum.model.entity;

import java.util.UUID;
import javax.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Entity
@Table(name = "user_fcm_token", schema = "public")
@Getter
@Setter
@SuperBuilder(toBuilder = true)
@NoArgsConstructor
public class UserFcmToken {

  @Id @GeneratedValue private UUID id;

  @Column(name = "fcm_token")
  private String token;

  @Column(nullable = false)
  private boolean isActive;

  @Column(name = "device_type", length = 20)
  private String deviceType;

  @ManyToOne
  @JoinColumn(name = "user_id", nullable = false)
  private UserProfile user;
}
