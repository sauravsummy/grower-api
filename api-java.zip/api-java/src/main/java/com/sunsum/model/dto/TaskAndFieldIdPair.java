package com.sunsum.model.dto;

public record TaskAndFieldIdPair(Long taskId, Long fieldId) {}
