package com.sunsum.model.dto;

import java.util.List;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class FarmHoldingResponse {

  List<FarmHolding> farmHoldings;
}
