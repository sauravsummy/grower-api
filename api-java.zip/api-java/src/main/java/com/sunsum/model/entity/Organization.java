package com.sunsum.model.entity;

import com.sunsum.constants.OrgType;
import com.sunsum.constants.Status;
import java.util.Objects;
import java.util.Set;
import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "organization", schema = "public")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Organization extends BaseEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", nullable = false)
  private Long id;

  @Column(name = "title", nullable = false)
  private String title;

  @Column
  @Enumerated(EnumType.STRING)
  private OrgType type;

  @Enumerated(EnumType.STRING)
  @Column
  private Status status;

  @OneToMany(mappedBy = "organization", cascade = CascadeType.ALL)
  private Set<UserProfile> users;

  @OneToMany(mappedBy = "farmHolding")
  private Set<Field> fields;

  @Column private String memo1;
  @Column private String memo2;
  @Column private String memo3;
  @Column private String memo4;
  @Column private String memo5;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    Organization that = (Organization) o;
    return Objects.equals(id, that.id)
        && Objects.equals(title, that.title)
        && type == that.type
        && Objects.equals(status, that.status);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, title, type, status);
  }
}
