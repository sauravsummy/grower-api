package com.sunsum.model.entity;

import com.sunsum.constants.Status;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "task_group", schema = "public")
@NoArgsConstructor
public class TaskGroup extends BaseEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", nullable = false)
  private Long id;

  @Column(name = "title", nullable = false)
  private String title;

  @Enumerated(EnumType.STRING)
  @Column
  private Status status;

  @Column private Boolean isLocked;

  @Column(name = "task_group_order")
  private int order;

  @ManyToOne
  @JoinColumn(name = "owner_id")
  private UserProfile taskGroupOwner;

  @OneToMany(mappedBy = "taskGroup")
  private Set<Task> tasks;

  @ManyToOne
  @JoinColumn(name = "project_id")
  @EqualsAndHashCode.Exclude
  private Project project;

  @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
  @JoinTable(
      name = "field_task_group",
      joinColumns = @JoinColumn(name = "taskgroup_id", referencedColumnName = "id"),
      inverseJoinColumns = @JoinColumn(name = "field_id", referencedColumnName = "id"))
  private Set<Field> fields;

  @Column(name = "task_group_memo")
  private String taskGroupMemo;

  @Column private String memo1;
  @Column private String memo2;
  @Column private String memo3;
  @Column private String memo4;
  @Column private String memo5;
}
