package com.sunsum.model.dto;

import com.sunsum.constants.UserRole;
import com.sunsum.model.entity.Role;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserDetails {

  private Long id;
  private String name;
  private Set<Role> roles;

  /*
   * Returns true if the provided role is the user's highest role.
   * */
  public boolean hasHighestRole(UserRole role) {
    return switch (role) {
      case ROLE_PROJECT_ADMIN -> this.roles.stream()
          .anyMatch(it -> it.getName().equals(UserRole.ROLE_PROJECT_ADMIN));

      case ROLE_FIELD_SUPPORTER -> this.roles.stream()
              .anyMatch(it -> it.getName().equals(UserRole.ROLE_FIELD_SUPPORTER))
          && roles.stream().noneMatch(it -> it.getName().equals(UserRole.ROLE_PROJECT_ADMIN));

      default -> this.roles.stream()
              .anyMatch(it -> it.getName().equals(UserRole.ROLE_FIELD_MANAGER))
          && roles.stream().noneMatch(it -> it.getName().equals(UserRole.ROLE_PROJECT_ADMIN))
          && roles.stream().noneMatch(it -> it.getName().equals(UserRole.ROLE_FIELD_SUPPORTER));
    };
  }
}
