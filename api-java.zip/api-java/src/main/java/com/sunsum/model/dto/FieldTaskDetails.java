package com.sunsum.model.dto;

import com.sunsum.model.entity.Task;
import org.springframework.data.geo.Point;
import org.springframework.stereotype.Component;

@Component
public interface FieldTaskDetails {

  Task getTask();

  Long getFieldId();

  Point getGps();

  String getFieldTitle();
}
