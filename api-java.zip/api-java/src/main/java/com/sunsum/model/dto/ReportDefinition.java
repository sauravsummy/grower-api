package com.sunsum.model.dto;

import com.sunsum.constants.CustomType;
import java.util.List;

public record ReportDefinition(
    String attributeName, CustomType type, List<String> value, List<String> selectedValue) {}
