package com.sunsum.model.dto;

import java.math.BigDecimal;

public interface FieldDetails {

  String getTitle();

  byte[] getGpsCoordinates();

  BigDecimal getAcreage();

  String getZipCode();

  String getMemo1();

  String[] getPhotoPath();
}
