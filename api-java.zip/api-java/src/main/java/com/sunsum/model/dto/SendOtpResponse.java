package com.sunsum.model.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SendOtpResponse {
  private String message;
}
