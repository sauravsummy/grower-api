package com.sunsum.model.dto;

import org.springframework.data.geo.Point;

public record FieldBasicInfo(Long id, String title, boolean gpsFlag, Point gps) {}
