package com.sunsum.model.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OtpRequest {

  private String rec;
  private String emailId;
}
