package com.sunsum.model.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.*;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PushNotificationRespDto {

  private Integer success;
  private Integer failure;
  private List<Results> results;
}
