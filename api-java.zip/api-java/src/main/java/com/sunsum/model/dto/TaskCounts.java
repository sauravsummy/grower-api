package com.sunsum.model.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class TaskCounts {

  private int overdueTasks;
  private int executableTasks;
}
