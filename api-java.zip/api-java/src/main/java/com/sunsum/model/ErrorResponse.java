package com.sunsum.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.http.HttpStatus;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ErrorResponse {

  private HttpStatus errorCode;
  private String message;

  @Override
  public String toString() {
    return "ErrorResponse [errorCode=" + errorCode + ", message=" + message + "]";
  }
}
