package com.sunsum.model.entity;

import com.sunsum.constants.TaskRelation;
import com.sunsum.constants.TaskType;
import com.vladmihalcea.hibernate.type.json.JsonType;
import java.time.LocalDate;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

@Entity
@Getter
@Setter
@TypeDef(name = "json", typeClass = JsonType.class)
@Table(name = "task", schema = "public")
@NoArgsConstructor
public class Task extends BaseEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", nullable = false)
  private Long id;

  @Column(name = "title", length = 50)
  private String title;

  @Column(name = "type", length = 10)
  @Enumerated(EnumType.STRING)
  private TaskType type;

  @Column(name = "brief")
  private String brief;

  @Type(type = "json")
  @Column(name = "custom_definition", columnDefinition = "json")
  private List<CustomDefinition> customDefinition;

  @ManyToOne
  @JoinColumn(name = "taskgroup_id")
  private TaskGroup taskGroup;

  @Column(name = "is_locked")
  private Boolean isLocked;

  @Column(name = "task_order")
  private Integer order;

  @Enumerated(EnumType.STRING)
  @Column(name = "relation", length = 15)
  private TaskRelation relation;

  @Column(name = "related_days")
  private Integer relatedDays;

  @Column(name = "fixed_due_date")
  private LocalDate fixedDueDate;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "related_task_id")
  private Task relatedTask;

  @Column(name = "memo1")
  private String memo1;

  @Column(name = "memo2")
  private String memo2;

  @Column(name = "memo3")
  private String memo3;

  @Column(name = "memo4")
  private String memo4;

  @Column(name = "memo5")
  private String memo5;
}
