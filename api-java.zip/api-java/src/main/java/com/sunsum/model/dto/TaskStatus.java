package com.sunsum.model.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@AllArgsConstructor
@Getter
@Builder
public class TaskStatus {
  String taskId;
  String taskTitle;
  LocalDate dueDate;
  String status;
  Integer taskOrder;
  @JsonIgnore LocalDate executableDate;
}
