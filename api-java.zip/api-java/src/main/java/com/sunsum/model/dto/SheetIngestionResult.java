package com.sunsum.model.dto;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SheetIngestionResult {
  private List<RowIngestionResult> rows;
  private int totalRecords;
  private int failureCount;
  private int successCount;
}
