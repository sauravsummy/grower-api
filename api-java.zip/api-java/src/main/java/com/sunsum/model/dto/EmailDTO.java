package com.sunsum.model.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmailDTO {

  private String fromEmail;

  private String toEmail;

  private String subject;

  private String body;
}
