package com.sunsum.util;

import com.google.gson.Gson;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.ErrorResponse;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@Slf4j
public class RisocareCommonUtils {

  public static final String JP_COUNTRY_CODE = "81";
  public static final String SHA_256 = "SHA-256";

  private RisocareCommonUtils() {}

  public static boolean isValidEmailId(String id) {
    String emailRegex = "^[a-zA-Z0-9_!#$%&’*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";

    Pattern pattern = Pattern.compile(emailRegex);
    if (id == null || id.isBlank() || id.isEmpty()) return false;
    return pattern.matcher(id).matches();
  }

  public static ResponseEntity<String> buildErrorResponse(HttpStatus httpStatus, String message) {
    ResponseEntity<String> responseEntity;
    Gson gson = new Gson();
    ErrorResponse errorResponse = new ErrorResponse();
    errorResponse.setErrorCode(httpStatus);
    errorResponse.setMessage(message);
    responseEntity = new ResponseEntity<>(gson.toJson(errorResponse), httpStatus);
    return responseEntity;
  }

  public static String formatMobileNumber(String mobileNo) {
    // Check if the number start with Japan country code and its length is 13 (assuming standard
    // japanese phone numbers)
    if (mobileNo.startsWith(JP_COUNTRY_CODE) && mobileNo.length() == 13) {
      mobileNo = mobileNo.substring(JP_COUNTRY_CODE.length());
    }
    if (!mobileNo.startsWith("0")) {
      mobileNo = "0" + mobileNo;
    }
    return mobileNo;
  }

  // Method to hash a password with salt
  public static String hashString(String value) {

    // Create a MessageDigest instance for SHA-256
    MessageDigest digest;
    try {
      digest = MessageDigest.getInstance(SHA_256);
    } catch (NoSuchAlgorithmException e) {
      log.error("Unable to hash token due to {} {} ", e.getMessage(), e.getCause());
      throw new BusinessRuleException("Unable to hash token", HttpStatus.INTERNAL_SERVER_ERROR);
    }

    // Get the byte array from the salted password
    byte[] encodedHash = digest.digest(value.getBytes());

    // Convert the byte array to a hexadecimal string
    StringBuilder hexString = new StringBuilder();
    for (byte b : encodedHash) {
      String hex = Integer.toHexString(0xff & b);
      if (hex.length() == 1) {
        hexString.append('0');
      }
      hexString.append(hex);
    }
    return hexString.toString();
  }
}
