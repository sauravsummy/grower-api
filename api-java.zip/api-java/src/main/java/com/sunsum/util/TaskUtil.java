package com.sunsum.util;

import com.sunsum.constants.AppConstants;
import com.sunsum.constants.TaskFieldStatus;
import com.sunsum.constants.TaskRelation;
import com.sunsum.model.entity.Task;
import com.sunsum.model.entity.TaskField;
import com.sunsum.model.dto.TaskAndFieldIdPair;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Map;
import org.springframework.stereotype.Component;

@Component
public class TaskUtil {

  private TaskUtil() {}

  public static void setExecutableAndDueDate(
      Task task, Map<Long, TaskField> fieldTasks, TaskField taskField) {

    Task relatedTask = task.getRelatedTask();

    if (task.getFixedDueDate() != null) {
      taskField.setDueDate(task.getFixedDueDate());
      taskField.setExecutableDate(DateUtil.MIN_DATE);
    } else if (relatedTask != null) {
      TaskField relatedTaskField = fieldTasks.get(relatedTask.getId());
      if (relatedTaskField != null
          && TaskFieldStatus.COMPLETED.equals(relatedTaskField.getTaskStatus())
          && relatedTaskField.getCompletionDate() != null) {
        setExecutableDateAndDueDate(task, taskField, relatedTaskField);
      }
    } else {
      taskField.setExecutableDate(DateUtil.MIN_DATE);
    }
  }

  public static void setExecutableAndDueDate(
      Task task, Map<TaskAndFieldIdPair, TaskField> fieldTasks, TaskField taskField, Long fieldId) {

    Task relatedTask = task.getRelatedTask();

    if (task.getFixedDueDate() != null) {
      taskField.setDueDate(task.getFixedDueDate());
      taskField.setExecutableDate(DateUtil.MIN_DATE);
    } else if (relatedTask != null) {
      TaskField relatedTaskField =
          fieldTasks.get(new TaskAndFieldIdPair(relatedTask.getId(), fieldId));
      if (relatedTaskField != null
          && TaskFieldStatus.COMPLETED.equals(relatedTaskField.getTaskStatus())
          && relatedTaskField.getCompletionDate() != null) {
        setExecutableDateAndDueDate(task, taskField, relatedTaskField);
      }
    } else {
      taskField.setExecutableDate(DateUtil.MIN_DATE);
    }
  }

  public static String getStatus(TaskField taskField) {

    LocalDate currentDate = LocalDate.now(ZoneId.of(ZoneId.SHORT_IDS.get(AppConstants.JST)));
    if (taskField.getCompletionDate() != null
        && TaskFieldStatus.COMPLETED.equals(taskField.getTaskStatus())) {
      return AppConstants.TASK_EXECUTION_STATUS_COMPLETED;
    }
    if (taskField.getDueDate() != null && currentDate.isAfter(taskField.getDueDate())) {
      return AppConstants.TASK_EXECUTION_STATUS_OVERDUE;
    }
    if (taskField.getExecutableDate() != null) {
      if (currentDate.isAfter(taskField.getExecutableDate())
          || currentDate.equals(taskField.getExecutableDate())) {
        return AppConstants.TASK_EXECUTION_STATUS_EXECUTABLE;
      }

      if (currentDate.plusDays(2).compareTo(taskField.getExecutableDate()) >= 0) {
        return AppConstants.TASK_EXECUTION_STATUS_INEXECUTABLE_2D;
      }
    }
    return AppConstants.TASK_EXECUTION_STATUS_INEXECUTABLE;
  }

  private static void setExecutableDateAndDueDate(
      Task task, TaskField taskField, TaskField relatedTaskField) {
    TaskRelation relation = task.getRelation();
    int relatedDays = task.getRelatedDays() != null ? task.getRelatedDays() : 0;
    LocalDate completionDate = relatedTaskField.getCompletionDate();
    switch (relation) {
      case WITH_IN:
        taskField.setExecutableDate(completionDate);
        taskField.setDueDate(completionDate.plusDays(relatedDays));
        break;
      case FOLLOW:
        taskField.setExecutableDate(completionDate.plusDays(relatedDays));
        break;
      case BLOCKED_BY:
        taskField.setExecutableDate(completionDate);
        break;
      case FIXED_DUE_DATE, NONE:
        break;
    }
  }
}
