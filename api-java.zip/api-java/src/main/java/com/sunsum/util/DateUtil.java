package com.sunsum.util;

import com.sunsum.constants.AppConstants;
import com.sunsum.constants.ErrorMsgConstants;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Objects;
import java.util.Optional;
import liquibase.repackaged.org.apache.commons.lang3.time.DateFormatUtils;
import liquibase.repackaged.org.apache.commons.lang3.time.DateUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
public class DateUtil {

  private static final String DATE_FORMAT = "dd-MM-yyyy";

  public static final LocalDate MIN_DATE = LocalDate.of(1753, 1, 1);

  private DateUtil() {}

  /**
   * @param date
   * @return formatted date in string format dd-MM-yyyy
   */
  public static String formatDate(Date date) {
    if (date == null) return null;
    try {
      return DateFormatUtils.format(date, DATE_FORMAT);
    } catch (NullPointerException e) {
      throw new IllegalArgumentException(ErrorMsgConstants.NULL_DATE);
    }
  }

  /**
   * @param stringDate in string format dd-MM-yyyy
   * @return actual parsed date
   */
  public static Date parseDate(String stringDate) {
    Date date = null;
    try {
      if (StringUtils.hasText(stringDate)) {
        date = DateUtils.parseDate(stringDate, DATE_FORMAT);
      }
    } catch (Exception e) {
      throw new IllegalArgumentException(ErrorMsgConstants.INVALID_DATE + stringDate);
    }

    return date;
  }

  /**
   * @param stringDate in string format dd-MM-yyyy
   * @return actual parsed date
   */
  public static Date parseDate(String stringDate, String dateFormat) {
    Date date = null;
    try {
      if (StringUtils.hasText(stringDate)) {
        date = DateUtils.parseDate(stringDate, dateFormat);
      }
    } catch (Exception e) {
      throw new IllegalArgumentException(ErrorMsgConstants.INVALID_DATE + stringDate);
    }

    return date;
  }

  /**
   * @return current date with date as current date and time as 12 midnight.
   */
  public static Date today() {
    return parseDate(formatDate(new Date()));
  }

  /**
   * Convert UTC LocalDateTime to Local Time
   *
   * @param localDateTime
   * @return
   */
  public static LocalDateTime convertUtcToLocalTime(
      LocalDateTime localDateTime, long timeZoneOffset) {
    if (timeZoneOffset > 0) {
      return localDateTime.minusMinutes(timeZoneOffset);
    } else if (timeZoneOffset < 0) {
      return localDateTime.plusMinutes(Math.abs(timeZoneOffset));
    }
    return localDateTime.plusMinutes(timeZoneOffset);
  }

  public static long getTimeZoneOffset(HttpHeaders headers) {
    if (headers != null && Optional.ofNullable(headers.getFirst(AppConstants.TIME_ZONE_OFFSET)).isPresent()) {
      return Long.parseLong(Objects.requireNonNull(headers.getFirst(AppConstants.TIME_ZONE_OFFSET)));
    }
    return 0;
  }

  /**
   * get Current date in Local date format
   *
   * @return current local date in format 'yyyy-MM-dd'
   */
  public static LocalDate currentLocalDate() {
    return LocalDate.now();
  }

  /**
   * convert java.sql.Timestamp to LocalDate format
   *
   * @param timestamp
   * @return LocalDate
   */
  public static LocalDate localDateFromTimestamp(Timestamp timestamp) {
    return timestamp.toLocalDateTime().toLocalDate();
  }

  /**
   * convert String input date to Local date format using date pattern
   *
   * @param inputDate
   * @param pattern
   * @return Local Date format of input date
   */
  public static LocalDate parseToLocalDate(String inputDate, String pattern) {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
    return LocalDate.parse(inputDate, formatter);
  }
}
