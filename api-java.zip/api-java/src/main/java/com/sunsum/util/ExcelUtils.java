package com.sunsum.util;

import com.sunsum.constants.AppConstants;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class ExcelUtils {

  public void writeHeaderRow(
      String headers, String mandatoryColumns, XSSFWorkbook workbook, XSSFSheet sheet) {
    Row row = sheet.createRow(0);
    CellStyle headerCellStyle = getHeaderCellStyle(workbook);
    CellStyle manHeadColStyle = getManHeaderCellStyle(workbook);

    List<String> headersArr = List.of(headers.split(AppConstants.COMMA));
    List<String> mandatoryArr =
        Arrays.stream(mandatoryColumns.split(AppConstants.COMMA)).map(String::trim).toList();

    AtomicInteger headerCount = new AtomicInteger();
    headersArr.forEach(
        header -> {
          if (mandatoryArr.contains(header.trim())) {
            createCell(row, headerCount.getAndIncrement(), header, manHeadColStyle);
          } else {
            createCell(row, headerCount.getAndIncrement(), header, headerCellStyle);
          }
        });
  }

  private CellStyle getHeaderCellStyle(XSSFWorkbook workbook) {
    CellStyle headerCellStyle = workbook.createCellStyle();
    headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
    headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
    return headerCellStyle;
  }

  private CellStyle getManHeaderCellStyle(XSSFWorkbook workbook) {
    CellStyle headerCellStyle = workbook.createCellStyle();
    headerCellStyle.setFillForegroundColor(IndexedColors.RED.getIndex());
    headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
    return headerCellStyle;
  }

  public void createCell(Row row, int columnCount, Object value, CellStyle style) {
    Cell cell = row.createCell(columnCount);
    if (value == null) {
      cell.setBlank();
    } else if (value instanceof Long longValue) {
      cell.setCellValue(longValue.doubleValue());
    } else if (value instanceof Integer intValue) {
      cell.setCellValue(intValue);
    } else if (value instanceof Boolean booleanValue) {
      cell.setCellValue(booleanValue);
    } else if (value instanceof ArrayList) {
      cell.setCellValue(value.toString());
    } else if (value instanceof BigDecimal bigDecimal) {
      // Convert BigDecimal to Double
      cell.setCellValue(bigDecimal.doubleValue());
    } else if (value instanceof LocalDate localDate) {
      cell.setCellValue(localDate);
    } else {
      log.debug("Handling value of type: {}", value.getClass().getName());
      cell.setCellValue(String.valueOf(value));
    }
    cell.setCellStyle(style);
  }

  public <T> void createCell(
      Row row, int columnCount, Object value, Class<T> type, CellStyle style, CellType cellType) {
    Cell cell = row.createCell(columnCount, cellType);

    if (value instanceof Long longValue) {
      cell.setCellValue(longValue.doubleValue());
    } else if (value instanceof Boolean booleanValue) {
      cell.setCellValue(booleanValue);
    } else if (value instanceof ArrayList) {
      cell.setCellValue(value.toString());
    } else if (value instanceof LocalDate date) {
      cell.setCellValue(date);
    } else {
      cell.setCellValue((String) value);
    }
    cell.setCellStyle(style);
  }

  public Map<String, Integer> columnNameToIndex(Sheet sheet) {

    Map<String, Integer> columnNameToIndex = new HashMap<>();
    Row firstRow = sheet.getRow(0);
    short minColumnIndex = firstRow.getFirstCellNum();
    short maxColumnIndex = firstRow.getLastCellNum();
    for (short columnIndex = minColumnIndex; columnIndex < maxColumnIndex; columnIndex++) {

      Cell cell = firstRow.getCell(columnIndex);

      if (Objects.nonNull(cell)) {
        columnNameToIndex.put(cell.getStringCellValue().trim(), cell.getColumnIndex());
      }
    }
    return columnNameToIndex;
  }
}
