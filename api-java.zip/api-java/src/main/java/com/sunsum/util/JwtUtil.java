package com.sunsum.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.util.Collection;
import java.util.Date;
import java.util.function.Function;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

@Component
public class JwtUtil {

  @Value("${secret}")
  private String secret;

  public String extractUserId(String token) {
    return extractClaim(token, Claims::getSubject);
  }

  public Date extractExpiration(String token) {
    return extractClaim(token, Claims::getExpiration);
  }

  public boolean isValid(String token, UserDetails userDetails) {
    return (userDetails.getUsername().equals(extractUserId(token)));
  }

  private <T> T extractClaim(String token, Function<Claims, T> resolver) {
    Claims claims = extractAllClaims(token);
    return resolver.apply(claims);
  }

  private Claims extractAllClaims(String token) {
    return Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
  }

  public String getToken(String userId, Collection<? extends GrantedAuthority> grantedAuthorities) {

    return createToken(grantedAuthorities, userId);
  }

  private String createToken(Collection<? extends GrantedAuthority> claims, String subject) {
    return Jwts.builder()
        .claim("authorities", claims)
        .setSubject(subject)
        .setIssuedAt(new Date(System.currentTimeMillis()))
        .signWith(SignatureAlgorithm.HS512, secret)
        .compact();
  }
}
