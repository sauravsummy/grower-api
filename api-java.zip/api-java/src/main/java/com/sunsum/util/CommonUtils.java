package com.sunsum.util;

import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.UserDetails;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.UserProfileRepository;
import java.util.Objects;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

/** The class is for the commonly used code across the application */
@Component
@Slf4j
public class CommonUtils {

  private final UserProfileRepository userProfileRepository;

  private final ModelMapper mapper;

  public CommonUtils(UserProfileRepository userProfileRepository, ModelMapper mapper) {
    this.userProfileRepository = userProfileRepository;
    this.mapper = mapper;
  }

  /**
   * It will give the logged-in user id
   *
   * @return
   */
  public long getCurrentLoggedInUserId() {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    Object currentLoggedInUserId = Objects.requireNonNull(authentication).getPrincipal();
    return Long.parseLong(currentLoggedInUserId.toString());
  }

  /**
   * It will give the logged-in user entity
   *
   * @return
   */
  public Optional<UserProfile> getCurrentLoggedInUser() {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    Object currentLoggedInUserId = Objects.requireNonNull(authentication).getPrincipal();
    return userProfileRepository.findById(Long.valueOf(currentLoggedInUserId.toString()));
  }

  public UserDetails getCurrentLoggedInUserDetails() {
    Optional<UserProfile> userProfile = getCurrentLoggedInUser();
    UserProfile user =
        userProfile.orElseThrow(
            () ->
                new BusinessRuleException(
                    "In valid user access", HttpStatus.INTERNAL_SERVER_ERROR));
    return mapper.map(user, UserDetails.class);
  }
}
