package com.sunsum.util;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@Component
public class UploadValidation {

  public boolean checkFileType(MultipartFile file) {
    String ext = file.getOriginalFilename();

    if (ext == null) {
      log.error("The uploaded file is null!");
      return false;
    }

    if (ext.endsWith(".csv")) {
      log.error("File extension validation failed: {}", ext);
      return false;
    } else if (ext.endsWith(".xlsx") || ext.endsWith(".xls")) {
      log.debug("Validated the File extension: {}", ext);
      return true;
    } else {
      log.error("File extension validation failed: {}", ext);
    }
    return false;
  }

  public boolean isSheetEmpty(Sheet sheet) {
    log.info("Validated the isSheetEmpty: {}", sheet);
    Iterator<Row> rows = sheet.rowIterator();
    Row row;
    Cell cell;
    while (rows.hasNext()) {
      row = rows.next();
      Iterator<Cell> cells = row.cellIterator();
      while (cells.hasNext()) {
        cell = cells.next();
        if (!cell.getStringCellValue().isEmpty()) {
          return false;
        }
      }
    }
    return true;
  }

  public Sheet removeEmptyRows(Sheet sheet) {
    log.info("removeEmptyRows for: {}", sheet);
    int i = 0;
    while (i <= sheet.getLastRowNum()) {
      if (isRowEmpty(sheet, i)) {
        sheet.shiftRows(i + 1, sheet.getLastRowNum() + 1, -1);
        continue;
      }
      i++;
    }
    return sheet;
  }

  private boolean isRowEmpty(Sheet sheet, int idx) {

    if (sheet.getRow(idx) == null) {
      return true;
    }

    for (int cellIndex = 0; cellIndex < sheet.getRow(idx).getLastCellNum(); cellIndex++) {
      if (!isCellEmpty(sheet, idx, cellIndex)) {
        return false;
      }
    }

    return true;
  }

  private boolean isCellEmpty(Sheet sheet, int idx, int col) {
    return sheet.getRow(idx).getCell(col) == null
        || sheet.getRow(idx).getCell(col).toString().trim().equals("");
  }

  private Set<String> getHeaders(Sheet sheet) {
    Set<String> headers = new HashSet<>();
    Row headerRow = sheet.getRow(0);

    // LIst of headers from excel
    Iterator<Cell> cells = headerRow.cellIterator();
    while (cells.hasNext()) {
      Cell cell = cells.next();
      RichTextString value = cell.getRichStringCellValue();
      headers.add(value.getString());
    }

    return headers.stream().filter(Objects::nonNull).map(String::trim).collect(Collectors.toSet());
  }

  public boolean validateHeaders(List<String> mandatoryHeaders, Sheet sheet) {
    log.info("Validating sheet {}", sheet.getSheetName());
    List<String> sheetHeaders = new ArrayList<>(getHeaders(sheet));
    Map<String, Integer> headerIndexMap =
        IntStream.range(0, sheetHeaders.size())
            .boxed()
            .collect(Collectors.toMap(sheetHeaders::get, i -> i));

    if (!sheetHeaders.containsAll(mandatoryHeaders)) {
      List<String> missingHeaders =
          mandatoryHeaders.stream().filter(header -> !sheetHeaders.contains(header)).toList();

      log.error("Missing mandatory headers: {}", missingHeaders);
      return false;
    }

    log.info(
        "mandatoryHeaders list {}", mandatoryHeaders.stream().map(headerIndexMap::get).toList());

    // Existing code...
    return true;
  }

  public List<String> getMandatoryHeadersForFileType(String headersString) {

    return Arrays.stream(headersString.split(",\\s*"))
        .filter(Objects::nonNull)
        .map(String::trim)
        .toList();
  }

  public boolean validateMandatoryData(
      Row row, List<String> mandatoryHeaders, Map<String, Integer> columnNameToIndex) {
    for (String column : mandatoryHeaders) {
      Cell cell = row.getCell(columnNameToIndex.get(column));
      if (isCellEmpty(cell)) {
        return false;
      }
    }
    return true;
  }

  private boolean isCellEmpty(Cell cell) {
    return cell == null
        || (cell.getCellType() == CellType.STRING
            && (cell.getStringCellValue().trim().isEmpty()
                || cell.getStringCellValue().trim().equalsIgnoreCase("")));
  }
}
