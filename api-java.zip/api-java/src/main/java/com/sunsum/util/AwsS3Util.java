package com.sunsum.util;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.sunsum.constants.AppConstants;
import java.io.IOException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
@RequiredArgsConstructor
public class AwsS3Util {

  private final AmazonS3 amazonS3;

  public void uploadFileToS3(MultipartFile file, String bucketName, String key) throws IOException {
    ObjectMetadata metaData = new ObjectMetadata();
    metaData.setContentType(file.getContentType());
    metaData.setContentLength(file.getSize());
    amazonS3.putObject(
        bucketName,
        key + AppConstants.FILE_PATH_SEPARATOR + file.getOriginalFilename(),
        file.getInputStream(),
        metaData);
  }

  public void delete(String bucketName, String fileName) {
    amazonS3.deleteObject(bucketName, fileName);
  }
}
