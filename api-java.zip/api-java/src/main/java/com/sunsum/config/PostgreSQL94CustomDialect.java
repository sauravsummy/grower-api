package com.sunsum.config;

import com.vladmihalcea.hibernate.type.array.StringArrayType;
import org.hibernate.dialect.PostgreSQL9Dialect;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PostgreSQL94CustomDialect extends PostgreSQL9Dialect {

  public PostgreSQL94CustomDialect() {
    super();
    this.registerHibernateType(2003, StringArrayType.class.getName());
  }
}
