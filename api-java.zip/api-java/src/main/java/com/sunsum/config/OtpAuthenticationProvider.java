package com.sunsum.config;

import com.sunsum.constants.ChannelType;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.OtpVerifyRequest;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.service.OtpService;
import com.sunsum.util.RisocareCommonUtils;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class OtpAuthenticationProvider implements AuthenticationProvider {

  private final UserProfileRepository userProfileRepository;

  private final OtpService otpService;

  @Override
  public Authentication authenticate(Authentication authentication) throws AuthenticationException {
    OtpVerifyRequest otpVerifyRequest = (OtpVerifyRequest) authentication.getPrincipal();
    Optional<UserProfile> userProfile;
    if (ChannelType.EMAIL_ID.equals(otpVerifyRequest.getChannelType())) {
      userProfile = userProfileRepository.findByEmailIgnoreCase(otpVerifyRequest.getRecipientId());
    } else {
      String mobileNo = RisocareCommonUtils.formatMobileNumber(otpVerifyRequest.getRecipientId());
      otpVerifyRequest.setRecipientId(mobileNo);
      userProfile = userProfileRepository.findByPhoneNo(Long.valueOf(mobileNo));
    }
    UserProfile user =
        userProfile.orElseThrow(() -> new UsernameNotFoundException("User Not Found"));
    if (!Boolean.TRUE.equals(user.getIsActive())) {
      throw new BusinessRuleException("Inactive User", HttpStatus.UNAUTHORIZED);
    }
    if (otpService.isValidOtp(otpVerifyRequest)) {
      return new UsernamePasswordAuthenticationToken(user, null);
    } else {
      throw new BadCredentialsException("Invalid credentials");
    }
  }

  @Override
  public boolean supports(Class<?> authentication) {
    return authentication.equals(UsernamePasswordAuthenticationToken.class);
  }
}
