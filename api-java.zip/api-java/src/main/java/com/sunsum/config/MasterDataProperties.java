package com.sunsum.config;

import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "bulk-upload")
@Getter
@Setter
public class MasterDataProperties {
  private Map<String, String> fileTypes;
}
