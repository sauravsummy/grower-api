package com.sunsum.service;

import com.sunsum.model.dto.FarmHoldingResponse;
import com.sunsum.model.dto.TaskCounts;
import com.sunsum.model.dto.UserSubDetails;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public interface FarmHoldingService {

  FarmHoldingResponse getFarmHoldingsForUser();

  boolean hasUserPermissionForFarmHolding(Long id);

  Map<UserSubDetails, Map<Long, Map<Long, TaskCounts>>>
      getCountOfUpcomingInTwoDaysAndOverdueTasks();
}
