package com.sunsum.service.impl;

import com.sunsum.constants.AppConstants;
import com.sunsum.exception.BulkDownloadException;
import com.sunsum.repository.TaskGroupRepository;
import com.sunsum.model.entity.TaskGroup;
import com.sunsum.service.DataDownload;
import com.sunsum.util.ExcelUtils;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Class to create a XLSX file with sheet name as taskgroup and writes task group table data and
 * return as a byte stream.
 */
@Slf4j
@Service("taskgroupDownloader")
public class TaskGroupDownloadImpl implements DataDownload {

  private final TaskGroupRepository taskGroupRepository;

  private final ExcelUtils excelUtils;

  private List<TaskGroup> taskGroupList;

  @Autowired
  public TaskGroupDownloadImpl(TaskGroupRepository taskGroupRepository, ExcelUtils excelUtils) {
    this.taskGroupRepository = taskGroupRepository;
    this.excelUtils = excelUtils;
  }

  /**
   * To get the all the TaskGroup table data.
   *
   * @return DataDownload
   */
  @Override
  public DataDownload fetch() {
    taskGroupList = taskGroupRepository.findAllByOrderByIdAsc();
    return this;
  }

  /**
   * Method to create an Excel workbook and adds a sheet
   *
   * @param columns the list of columns separated by comma
   * @return ByteArrayInputStream
   */
  @Override
  public ByteArrayInputStream prepareSheet(String columns, String mandatoryColumns) {
    try (XSSFWorkbook workbook = new XSSFWorkbook()) {
      XSSFSheet sheet = workbook.createSheet(AppConstants.SHEET_TASKGROUP);
      excelUtils.writeHeaderRow(columns, mandatoryColumns, workbook, sheet);
      writeDataRows(sheet);
      try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
        workbook.write(outputStream);
        return new ByteArrayInputStream(outputStream.toByteArray());
      }
    } catch (Exception e) {
      log.error("Exception Occurred while downloading the TASK GROUP data", e);
      throw new BulkDownloadException(
          "Exception has occurred while downloading TASK GROUP data", e);
    }
  }

  /**
   * Writes Task Group table data to the sheet.
   *
   * @param sheet Excel sheet
   */
  private void writeDataRows(XSSFSheet sheet) {
    int columnCount;
    int rowNo = 1;
    // Creating data rows for each query
    for (TaskGroup taskGroup : taskGroupList) {
      try {
        Row row = sheet.createRow(rowNo);
        columnCount = 0;
        excelUtils.createCell(row, columnCount++, taskGroup.getId(), null);
        excelUtils.createCell(row, columnCount++, taskGroup.getTitle(), null);
        excelUtils.createCell(row, columnCount++, taskGroup.getTaskGroupOwner().getEmail(), null);
        excelUtils.createCell(row, columnCount++, taskGroup.getProject().getId(), null);
        excelUtils.createCell(row, columnCount++, taskGroup.getOrder(), null);
        excelUtils.createCell(row, columnCount++, taskGroup.getStatus(), null);
        excelUtils.createCell(row, columnCount++, taskGroup.getIsLocked(), null);
        excelUtils.createCell(row, columnCount++, taskGroup.getTaskGroupMemo(), null);
        excelUtils.createCell(row, columnCount++, taskGroup.getMemo1(), null);
        excelUtils.createCell(row, columnCount++, taskGroup.getMemo2(), null);
        excelUtils.createCell(row, columnCount++, taskGroup.getMemo3(), null);
        excelUtils.createCell(row, columnCount++, taskGroup.getMemo4(), null);
        excelUtils.createCell(row, columnCount, taskGroup.getMemo5(), null);
        rowNo++;
      } catch (Exception e) {
        log.error(
            "Exception occurred while preparing excel row in TaskGroup for Id ={} and Title={}",
            taskGroup.getId(),
            taskGroup.getTitle(),
            e);
      }
    }
  }
}
