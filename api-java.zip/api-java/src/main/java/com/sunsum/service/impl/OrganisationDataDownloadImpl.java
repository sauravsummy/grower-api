package com.sunsum.service.impl;

import com.sunsum.constants.AppConstants;
import com.sunsum.exception.BulkDownloadException;
import com.sunsum.repository.OrganisationRepository;
import com.sunsum.model.entity.Organization;
import com.sunsum.service.DataDownload;
import com.sunsum.util.ExcelUtils;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Class to create a XLSX file with sheet name as organisation and writes organisation table data
 * and return as a byte stream.
 */
@Slf4j
@Service("organisationDownloader")
public class OrganisationDataDownloadImpl implements DataDownload {

  private final OrganisationRepository organisationRepository;

  private final ExcelUtils excelUtils;

  @Autowired
  public OrganisationDataDownloadImpl(
      OrganisationRepository organisationRepository, ExcelUtils excelUtils) {
    this.organisationRepository = organisationRepository;
    this.excelUtils = excelUtils;
  }

  private List<Organization> orgData;

  /**
   * Gets all the table data using repo method
   *
   * @return DataDownload
   */
  @Override
  public DataDownload fetch() {
    orgData = organisationRepository.findAllByOrderByIdAsc();
    return this;
  }

  /**
   * Method to create an Excel workbook and adds a sheet
   *
   * @param columnsString the list of columns separated by comma
   * @return ByteArrayInputStream
   */
  @Override
  public ByteArrayInputStream prepareSheet(String columnsString, String mandatoryColumns) {
    try (XSSFWorkbook workbook = new XSSFWorkbook()) {
      XSSFSheet sheet = workbook.createSheet(AppConstants.SHEET_ORGANISATION);
      excelUtils.writeHeaderRow(columnsString, mandatoryColumns, workbook, sheet);
      writeDataRows(sheet);
      try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
        workbook.write(outputStream);
        return new ByteArrayInputStream(outputStream.toByteArray());
      }
    } catch (Exception e) {
      log.error("Exception Occurred while downloading the ORGANIZATION data", e);
      throw new BulkDownloadException(
          "Exception has occurred while downloading ORGANIZATION data", e);
    }
  }

  /**
   * Writes organisation table data to the sheet.
   *
   * @param sheet the XSSFSheet sheet
   */
  private void writeDataRows(XSSFSheet sheet) {
    int columnCount;
    int rowNo = 1;
    // Creating data rows for each query
    for (Organization organization : orgData) {
      try {
        Row row = sheet.createRow(rowNo);
        columnCount = 0;
        excelUtils.createCell(row, columnCount++, organization.getId(), null);
        excelUtils.createCell(row, columnCount++, organization.getTitle(), null);
        excelUtils.createCell(row, columnCount++, organization.getType().getValue(), null);
        excelUtils.createCell(row, columnCount++, organization.getStatus().getValue(), null);
        excelUtils.createCell(row, columnCount++, organization.getMemo1(), null);
        excelUtils.createCell(row, columnCount++, organization.getMemo2(), null);
        excelUtils.createCell(row, columnCount++, organization.getMemo3(), null);
        excelUtils.createCell(row, columnCount++, organization.getMemo4(), null);
        excelUtils.createCell(row, columnCount, organization.getMemo5(), null);
        rowNo++;
      } catch (Exception e) {
        log.error(
            "Exception occurred while preparing excel row in organisation for Id ={} and Title={}",
            organization.getId(),
            organization.getTitle(),
            e);
      }
    }
  }
}
