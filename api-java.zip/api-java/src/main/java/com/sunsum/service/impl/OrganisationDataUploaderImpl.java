package com.sunsum.service.impl;

import com.sunsum.constants.AppConstants;
import com.sunsum.constants.OrgType;
import com.sunsum.constants.Status;
import com.sunsum.repository.OrganisationRepository;
import com.sunsum.exception.BulkUploadException;
import com.sunsum.model.dto.RowIngestionResult;
import com.sunsum.model.entity.IngestionStatus;
import com.sunsum.model.entity.Organization;
import com.sunsum.service.DataUpload;
import java.util.Map;
import java.util.Objects;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

/**
 * The class is to read the organisation data from the XLSX file with sheet name as organisation.
 */
@Service("organisationUploader")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Slf4j
@Getter
public class OrganisationDataUploaderImpl implements DataUpload {

  private Organization organizationEntity;

  private final OrganisationRepository organisationRepository;

  @Autowired
  public OrganisationDataUploaderImpl(OrganisationRepository organisationRepository) {
    this.organisationRepository = organisationRepository;
  }

  /**
   * Saves each organisation row to database.
   *
   * @return RowIngestionResult
   */
  @Override
  public RowIngestionResult dataInjection(int rowNum) {
    IngestionStatus ingestionStatus;
    try {
      ingestionStatus =
          organizationEntity.getId() == null ? IngestionStatus.INSERTED : IngestionStatus.UPDATED;
      organisationRepository.save(organizationEntity);

    } catch (Exception e) {
      log.error(
          "Exception Occurred while saving the organisation data={}",
          organizationEntity.getTitle(),
          e);
      throw new BulkUploadException("Exception Occurred while saving the organisation data", e);
    }
    return RowIngestionResult.builder().rowNumber(rowNum).status(ingestionStatus).build();
  }

  /**
   * The method to transform the Excel file row in to an organisation entity object.
   *
   * @param row the Excel row
   * @param columnNameToIndex it holds the column name, it's index in the Excel sheet
   * @return DataUpload the reference to the same object
   */
  @Override
  public DataUpload createFromRow(Row row, Map<String, Integer> columnNameToIndex) {
    organizationEntity = new Organization();
    String title = getStringCell(row, columnNameToIndex.get(AppConstants.TITLE));
    String type = getStringCell(row, columnNameToIndex.get(AppConstants.TYPE));

    try {
      Integer idRowNum = columnNameToIndex.get(AppConstants.ID);
      if (idRowNum != null) {
        Long id = getCellValue(row.getCell(idRowNum), Long.class);
        if (id != null) {
          organizationEntity.setId(id);
        }
      }
      organizationEntity.setTitle(title);
      organizationEntity.setType(OrgType.fromString(type));
      String status = getStringCell(row, columnNameToIndex.get(AppConstants.STATUS));
      status = Objects.isNull(status) ? AppConstants.ACTIVE : status;
      organizationEntity.setStatus(Status.fromString(status));
      organizationEntity.setMemo1(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_1)), String.class));
      organizationEntity.setMemo2(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_2)), String.class));
      organizationEntity.setMemo3(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_3)), String.class));
      organizationEntity.setMemo4(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_4)), String.class));
      organizationEntity.setMemo5(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_5)), String.class));
    } catch (Exception e) {
      log.error(
          "Exception occurred while creating a organisation entity from the excel row for Title={} and Type={}",
          title,
          type,
          e);
      throw new BulkUploadException(
          "Exception occurred while creating a organisation entity from the excel row", e);
    }
    return this;
  }
}
