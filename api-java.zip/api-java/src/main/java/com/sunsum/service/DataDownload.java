package com.sunsum.service;

import java.io.ByteArrayInputStream;

public interface DataDownload {

  DataDownload fetch();

  ByteArrayInputStream prepareSheet(String columns, String mandatoryColumns);
}
