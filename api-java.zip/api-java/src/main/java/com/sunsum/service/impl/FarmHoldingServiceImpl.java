package com.sunsum.service.impl;

import com.sunsum.exception.BusinessRuleException;
import com.sunsum.repository.OrganisationRepository;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.constants.UserRole;
import com.sunsum.model.dto.FarmHolding;
import com.sunsum.model.dto.FarmHoldingResponse;
import com.sunsum.model.dto.TaskCounts;
import com.sunsum.model.dto.UserDetails;
import com.sunsum.model.dto.UserSubDetails;
import com.sunsum.model.entity.Field;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.FieldRepository;
import com.sunsum.service.FarmHoldingService;
import com.sunsum.service.TaskService;
import com.sunsum.util.CommonUtils;
import java.text.Collator;
import java.util.*;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class FarmHoldingServiceImpl implements FarmHoldingService {

  private final OrganisationRepository organisationRepository;

  private final CommonUtils commonUtils;

  private final UserProfileRepository userProfileRepository;

  private final ModelMapper modelMapper;

  private final FieldRepository fieldRepository;

  private final TaskService taskService;

  @Override
  public FarmHoldingResponse getFarmHoldingsForUser() {
    try {
      UserDetails userDetails = commonUtils.getCurrentLoggedInUserDetails();
      List<FarmHolding> farmHoldings;
      if (userDetails.hasHighestRole(UserRole.ROLE_PROJECT_ADMIN)) {
        farmHoldings = organisationRepository.findByProjectAdmin(userDetails.getId());
      } else if (userDetails.hasHighestRole(UserRole.ROLE_FIELD_SUPPORTER)) {
        farmHoldings = organisationRepository.findByFieldSupporter(userDetails.getId());
      } else {
        farmHoldings = organisationRepository.findByFieldManager(userDetails.getId());
      }
      sortFarmHoldingByJapaneseTitle(farmHoldings);
      return new FarmHoldingResponse(farmHoldings);

    } catch (Exception e) {
      log.error(
          "An error occurred when retrieving farmholdings for users, because of {} {}",
          e.getMessage(),
          e.getCause());
      throw new BusinessRuleException(
          "An error occurred when retrieving farmholdings for users",
          HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  public boolean hasUserPermissionForFarmHolding(Long id) {
    UserDetails userDetails = commonUtils.getCurrentLoggedInUserDetails();
    Long userId = userDetails.getId();
    List<FarmHolding> userFarmHoldings;
    if (userDetails.hasHighestRole(UserRole.ROLE_PROJECT_ADMIN)) {
      userFarmHoldings = organisationRepository.findByProjectAdmin(userId);
    } else if (userDetails.hasHighestRole(UserRole.ROLE_FIELD_SUPPORTER)) {
      userFarmHoldings = organisationRepository.findByFieldSupporter(userId);
    } else {
      userFarmHoldings = organisationRepository.findByFieldManager(userId);
    }
    return userFarmHoldings.stream().anyMatch(it -> it.getId().equals(id));
  }

  @Override
  public Map<UserSubDetails, Map<Long, Map<Long, TaskCounts>>>
      getCountOfUpcomingInTwoDaysAndOverdueTasks() {
    log.info("Starting to gather task counts (overdue and upcoming) for all users.");

    Map<UserSubDetails, Map<Long, Map<Long, TaskCounts>>> userDataMap = new HashMap<>();
    List<UserProfile> userProfiles = userProfileRepository.findAllByIsActive(Boolean.TRUE);
    log.debug("Number of active user profiles found: {}", userProfiles.size());

    for (UserProfile userProfile : userProfiles) {
      log.debug("Processing user profile: {}", userProfile.getId());
      Map<Long, Map<Long, TaskCounts>> farmHoldingsMap = processFarmHoldingsForUser(userProfile);
      UserSubDetails userPartialDetails =
          new UserSubDetails(userProfile.getId(), userProfile.getEmail(), userProfile.getName());
      userDataMap.put(userPartialDetails, farmHoldingsMap);
    }

    log.info("Finished compiling task counts for all users.");
    return userDataMap;
  }

  private Map<Long, Map<Long, TaskCounts>> processFarmHoldingsForUser(UserProfile userProfile) {
    log.debug("Fetching farm holdings for user ID: {}", userProfile.getId());
    List<FarmHolding> farmHoldings = fetchFarmHoldingsForUser(userProfile);
    log.debug(
        "Number of farm holdings found for user ID {}: {}",
        userProfile.getId(),
        farmHoldings.size());

    Map<Long, Map<Long, TaskCounts>> farmHoldingsMap = new HashMap<>();

    for (FarmHolding farmHolding : farmHoldings) {
      log.debug(
          "Processing farm holding ID: {} for user ID: {}",
          farmHolding.getId(),
          userProfile.getId());
      Map<Long, TaskCounts> fieldTaskCounts = processFieldsForFarmHolding(farmHolding);
      farmHoldingsMap.put(farmHolding.getId(), fieldTaskCounts);
    }

    return farmHoldingsMap;
  }

  private Map<Long, TaskCounts> processFieldsForFarmHolding(FarmHolding farmHolding) {
    log.debug("Fetching fields for farm holding ID: {}", farmHolding.getId());
    List<Field> fields = fieldRepository.findByFarmHoldingId(farmHolding.getId());
    log.debug(
        "Number of fields found for farm holding ID {}: {}", farmHolding.getId(), fields.size());

    Map<Long, TaskCounts> fieldsMap = new HashMap<>();

    for (Field field : fields) {
      log.debug("Calculating task counts for field ID: {}", field.getId());
      Map<String, Long> taskCounts =
          taskService.countOverdueAndExecutableTasks(String.valueOf(field.getId()));
      long overdueTasks = taskCounts.getOrDefault("OVERDUE", 0L);
      long executableInTwoDaysTasks = taskCounts.getOrDefault("UPCOMING_TASKS", 0L);
      log.debug(
          "Field ID {} has {} overdue tasks and {} executable in two days tasks.",
          field.getId(),
          overdueTasks,
          executableInTwoDaysTasks);

      fieldsMap.put(
          field.getId(), new TaskCounts((int) overdueTasks, (int) executableInTwoDaysTasks));
    }

    return fieldsMap;
  }

  private List<FarmHolding> fetchFarmHoldingsForUser(UserProfile userProfile) {
    log.debug("Fetching farm holdings for user: {}", userProfile.getId());
    UserDetails userDetails = modelMapper.map(userProfile, UserDetails.class);

    List<FarmHolding> farmHoldings;
    if (userDetails.hasHighestRole(UserRole.ROLE_PROJECT_ADMIN)) {
      farmHoldings = organisationRepository.findByProjectAdmin(userProfile.getId());
      log.debug(
          "Farm holdings as PROJECT_ADMIN for user {}: {}",
          userProfile.getId(),
          farmHoldings.size());
    } else if (userDetails.hasHighestRole(UserRole.ROLE_FIELD_SUPPORTER)) {
      farmHoldings = organisationRepository.findByFieldSupporter(userProfile.getId());
      log.debug(
          "Farm holdings as FIELD_SUPPORTER for user {}: {}",
          userProfile.getId(),
          farmHoldings.size());
    } else if (userDetails.hasHighestRole(UserRole.ROLE_FIELD_MANAGER)) {
      farmHoldings = organisationRepository.findByFieldManager(userProfile.getId());
      log.debug(
          "Farm holdings as FIELD_MANAGER for user {}: {}",
          userProfile.getId(),
          farmHoldings.size());
    } else {
      farmHoldings = new ArrayList<>();
      log.debug("No farm holdings found for user {}", userProfile.getId());
    }
    return farmHoldings;
  }

  private static void sortFarmHoldingByJapaneseTitle(List<FarmHolding> farmHoldings) {
    Collator collator = Collator.getInstance(Locale.JAPAN);
    Comparator<FarmHolding> titleComparator = Comparator.comparing(FarmHolding::getTitle, collator);
    farmHoldings.sort(titleComparator);
  }
}
