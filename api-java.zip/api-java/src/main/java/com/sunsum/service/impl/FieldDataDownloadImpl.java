package com.sunsum.service.impl;

import com.sunsum.constants.AppConstants;
import com.sunsum.constants.Status;
import com.sunsum.exception.BulkDownloadException;
import com.sunsum.repository.FieldTaskGroupRepository;
import com.sunsum.model.entity.Field;
import com.sunsum.model.entity.FieldTaskGroup;
import com.sunsum.repository.FieldRepository;
import com.sunsum.service.DataDownload;
import com.sunsum.util.ExcelUtils;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.data.geo.Point;
import org.springframework.stereotype.Service;

/**
 * Implementation of DataDownload for downloading field data into an Excel sheet. This class handles
 * the extraction of field data from the database and writes it to an Excel file format.
 */
@Slf4j
@Service("fieldDownloader")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class FieldDataDownloadImpl implements DataDownload {

  FieldRepository fieldRepository;

  FieldTaskGroupRepository fieldTaskGroupRepository;
  ExcelUtils excelUtils;
  private List<Field> fields;

  /**
   * Constructor for FieldDataDownloadImpl.
   *
   * @param fieldRepository Repository for accessing field data.
   * @param excelUtils Utility class for Excel operations.
   */
  public FieldDataDownloadImpl(
      FieldRepository fieldRepository,
      ExcelUtils excelUtils,
      FieldTaskGroupRepository fieldTaskGroupRepository) {
    this.fieldRepository = fieldRepository;
    this.excelUtils = excelUtils;
    this.fieldTaskGroupRepository = fieldTaskGroupRepository;
  }

  /**
   * Fetches all field data from the repository.
   *
   * @return This instance of FieldDataDownloadImpl with populated field data.
   */
  @Override
  public DataDownload fetch() {
    log.info("Fetching all field data from repository");
    fields = fieldRepository.findAllByOrderByIdAsc();
    log.info("Field data fetched successfully, total records: {}", fields.size());
    return this;
  }

  @Override
  public ByteArrayInputStream prepareSheet(String columnsString, String mandatoryColumns) {
    try (XSSFWorkbook workbook = new XSSFWorkbook()) {
      XSSFSheet sheet = workbook.createSheet(AppConstants.SHEET_FIELD);
      excelUtils.writeHeaderRow(columnsString, mandatoryColumns, workbook, sheet);
      writeDataRows(sheet);
      try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
        workbook.write(outputStream);
        return new ByteArrayInputStream(outputStream.toByteArray());
      }
    } catch (Exception e) {
      log.error("Exception Occurred while downloading the FIELD data", e);
      throw new BulkDownloadException("Exception occurred while downloading FIELD data ", e);
    }
  }

  /**
   * Writes data rows to the Excel sheet using field data.
   *
   * @param sheet The XSSFSheet to write data rows to.
   */
  private void writeDataRows(XSSFSheet sheet) {
    int columnCount;
    int rowNo = 1; // As header row added, rowNo should start from 1
    Row row;

    for (Field field : fields) {
      log.debug("Writing data for field with ID: {}", field.getId());
      try {
        row = sheet.createRow(rowNo++);
        columnCount = 0;

        excelUtils.createCell(row, columnCount++, field.getId(), null);
        excelUtils.createCell(row, columnCount++, field.getTitle(), null);
        excelUtils.createCell(
            row,
            columnCount++,
            field.getFarmHolding() != null ? field.getFarmHolding().getId() : null,
            null);
        String geoCoordinates = formatGeoCoordinates(field.getGpsCoordinates());
        excelUtils.createCell(
            row,
            columnCount++,
            geoCoordinates != null ? geoCoordinates : AppConstants.EMPTY_STRING,
            null);
        String formattedZipCode = formatZipCode(field.getZipCode());
        if (!formattedZipCode.isEmpty()) {
          excelUtils.createCell(row, columnCount++, Integer.parseInt(formattedZipCode), null);
        } else {
          excelUtils.createCell(row, columnCount++, null, null);
        }
        excelUtils.createCell(row, columnCount++, field.getAcreage(), null);
        excelUtils.createCell(row, columnCount++, field.getStatus().getValue(), null);
        excelUtils.createCell(row, columnCount++, field.getNote(), null); // Note
        String photoPath = formatPhotoPath(field.getPhotoPath());
        excelUtils.createCell(row, columnCount++, photoPath, null); // Photo Path
        columnCount = setFieldTaskGroup(field, row, columnCount);
        excelUtils.createCell(row, columnCount++, field.getMemo1(), null);
        excelUtils.createCell(row, columnCount++, field.getMemo2(), null);
        excelUtils.createCell(row, columnCount++, field.getMemo3(), null);
        excelUtils.createCell(row, columnCount++, field.getMemo4(), null);
        excelUtils.createCell(row, columnCount, field.getMemo5(), null);
      } catch (Exception e) {
        log.error("Error occurred while writing data rows: {}", e.getMessage(), e);
      }
    }
    log.info("Data rows written to Excel sheet successfully, total rows: {}", rowNo - 1);
  }

  private int setFieldTaskGroup(Field field, Row row, int columnCount) {
    if (field.getTaskGroups() == null || field.getTaskGroups().isEmpty()) {
      return createEmptyCells(row, columnCount, 3);
    }

    List<Optional<FieldTaskGroup>> fieldTaskGroupOptList =
        field.getTaskGroups().stream()
            .map(
                taskGroup ->
                    fieldTaskGroupRepository.findByFieldIdAndTaskGroupIdAndFiledTaskGroupStatus(
                        field.getId(), taskGroup.getId(), Status.ACTIVE))
            .toList();

    Optional<FieldTaskGroup> fieldTaskGroupOpt =
        fieldTaskGroupOptList.stream()
            .flatMap(Optional::stream)
            .filter(ftg -> ftg.getFiledTaskGroupStatus().equals(Status.ACTIVE))
            .findFirst();

    if (!fieldTaskGroupOpt.isPresent()) {
      return createEmptyCells(row, columnCount, 3);
    }

    FieldTaskGroup fieldTaskGroup = fieldTaskGroupOpt.get();
    excelUtils.createCell(
        row, columnCount++, fieldTaskGroup.getTaskGroupId(), null); // TaskGroup ID
    excelUtils.createCell(
        row, columnCount++, fieldTaskGroup.getFieldTaskGroupMemo(), null); // FieldTaskGroup Memo
    excelUtils.createCell(
        row,
        columnCount++,
        fieldTaskGroup.getFiledTaskGroupStatus().getValue(),
        null); // FieldTaskGroup Status

    return columnCount;
  }

  private int createEmptyCells(Row row, int columnCount, int numberOfCells) {
    for (int i = 0; i < numberOfCells; i++) {
      excelUtils.createCell(row, columnCount++, null, null);
    }
    return columnCount;
  }

  private String formatPhotoPath(String[] photoPaths) {
    if (photoPaths == null || photoPaths.length == 0) {
      return AppConstants.EMPTY_STRING; // Or "N/A", or "", based on what you prefer
    }
    return Arrays.stream(photoPaths).map(String::trim).collect(Collectors.joining(","));
  }

  private String formatGeoCoordinates(Point gpsCoordinates) {
    if (gpsCoordinates != null) {
      return gpsCoordinates.getX() + ", " + gpsCoordinates.getY();
    }
    return null; // Or return a default string like "Not Available"
  }

  private String formatZipCode(String zipCode) {
    // For now, we simply return the ZIP code as is
    return zipCode != null ? zipCode : "";
  }
}
