package com.sunsum.service;

import com.sunsum.model.dto.RowIngestionResult;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Map;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

public interface DataUpload {

  DataUpload createFromRow(Row row, Map<String, Integer> columnNameToIndex);

  RowIngestionResult dataInjection(int rowNum);

  default String getStringCell(Row row, Integer index) {

    Cell cell = row.getCell(index);

    if (cell == null) {
      return null;
    }

    return cell.getStringCellValue().trim();
  }

  default <T extends Number> T getNumericCell(Row row, Integer index, Class<T> numericType) {

    Cell cell = row.getCell(index);

    if (cell == null) {
      return null;
    }
    double cellValue = cell.getNumericCellValue();

    return switch (numericType.getSimpleName()) {
      case "Integer" -> numericType.cast((int) cellValue);
      case "Long" -> numericType.cast((long) cellValue);
      case "Float" -> numericType.cast((float) cellValue);
      case "Double" -> numericType.cast(cellValue);
      default -> throw new IllegalArgumentException(
          "Unsupported numeric type: " + numericType.getName());
    };
  }

  default <T> T getCellValue(Cell cell, Class<T> returnType) {
    if (cell == null) {
      return null;
    }

    switch (cell.getCellType()) {
      case STRING:
        return convertStringValue(cell, returnType);
      case NUMERIC:
        return convertNumericValue(cell, returnType);
      case BOOLEAN:
        return convertBooleanValue(cell, returnType);
      case FORMULA:
        // Handle formula cells if needed
        return null;
      default:
        return null;
    }
  }

  private <T> T convertStringValue(Cell cell, Class<T> returnType) {
    if (String.class.isAssignableFrom(returnType)) {
      return returnType.cast(cell.getStringCellValue());
    } else {
      return null; // Not supported type
    }
  }

  private <T> T convertNumericValue(Cell cell, Class<T> returnType) {
    if (Number.class.isAssignableFrom(returnType)) {
      double numericValue = cell.getNumericCellValue();
      if (Long.class.isAssignableFrom(returnType)) {
        return returnType.cast((long) numericValue);
      } else if (Integer.class.isAssignableFrom(returnType)) {
        return returnType.cast((int) numericValue);
      } else if (Double.class.isAssignableFrom(returnType)) {
        return returnType.cast(numericValue);
      } else if (BigDecimal.class.isAssignableFrom(returnType)) {
        BigDecimal bigDecimalValue = BigDecimal.valueOf(numericValue);
        return returnType.cast(bigDecimalValue);
      } else {
        return null;
      }
    } else {

      if (LocalDate.class.isAssignableFrom(returnType)) {
        java.util.Date date = cell.getDateCellValue();
        Instant instant = date.toInstant();
        LocalDate localDate = instant.atZone(ZoneId.systemDefault()).toLocalDate();
        return returnType.cast(localDate);
      }
      if (String.class.isAssignableFrom(returnType)) {
        double numericValue = cell.getNumericCellValue();
        String strVal = String.valueOf(numericValue);
        return returnType.cast(strVal);
      }

      return null; // Not supported type
    }
  }

  private <T> T convertBooleanValue(Cell cell, Class<T> returnType) {
    if (Boolean.class.isAssignableFrom(returnType)) {
      return returnType.cast(cell.getBooleanCellValue());
    } else {
      return null; // Not supported type
    }
  }
}
