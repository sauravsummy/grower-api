package com.sunsum.service;

import com.sunsum.model.dto.FcmTokenRequest;
import com.sunsum.model.dto.UserFcmTokenDto;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public interface FcmTokenService {
  List<UserFcmTokenDto> getActiveUserFcmTokensByUserId(Long userId);

  void saveFcmToken(FcmTokenRequest request);
}
