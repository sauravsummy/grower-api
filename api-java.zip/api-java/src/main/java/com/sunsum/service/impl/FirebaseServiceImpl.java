package com.sunsum.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sunsum.model.dto.PushNotificationReqDto;
import com.sunsum.model.dto.PushNotificationRespDto;
import com.sunsum.service.FirebaseService;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Slf4j
@Service
public class FirebaseServiceImpl implements FirebaseService {
  private final RestTemplate restTemplate;
  private final ObjectMapper mapper;

  private final String firebaseApiUrl;
  private final String firebaseAuthKey;

  public FirebaseServiceImpl(
      RestTemplate restTemplate,
      ObjectMapper mapper,
      @Value("${firebase.api-url}") String firebaseApiUrl,
      @Value("${firebase.auth-key}") String firebaseAuthKey) {
    this.restTemplate = restTemplate;
    this.mapper = mapper;
    this.firebaseApiUrl = firebaseApiUrl;
    this.firebaseAuthKey = firebaseAuthKey;
  }

  @Override
  public PushNotificationRespDto sendNotification(PushNotificationReqDto notificationReqDto) {
    try {
      HttpHeaders headers = createNotificationHeaders();
      String jsonPayload = mapper.writeValueAsString(notificationReqDto);
      log.debug("JSON Payload for Notification: {}", jsonPayload); // Debug level for payload

      HttpEntity<String> entity = new HttpEntity<>(jsonPayload, headers);
      URI uri = UriComponentsBuilder.fromUriString(firebaseApiUrl).build().toUri();
      log.info("Request URI: {}", uri); // Log the URI

      ResponseEntity<String> response =
          restTemplate.exchange(uri, HttpMethod.POST, entity, String.class);
      log.info(
          "Notification sent, response status: {}",
          response.getStatusCode()); // Log response status

      return mapper.readValue(response.getBody(), PushNotificationRespDto.class);
    } catch (JsonProcessingException e) {
      log.error("Error processing JSON", e);
    } catch (Exception e) {
      log.error("Error sending notification", e);
    }
    return null; // Or consider throwing a custom exception
  }

  private HttpHeaders createNotificationHeaders() {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(new MediaType("application", "json", StandardCharsets.UTF_8));
    headers.set("Authorization", firebaseAuthKey);
    return headers;
  }
}
