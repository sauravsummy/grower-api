package com.sunsum.service.impl;

import com.sunsum.constants.AppConstants;
import com.sunsum.constants.ErrorMsgConstants;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.FieldBasicInfo;
import com.sunsum.model.dto.FieldTaskDetails;
import com.sunsum.model.dto.FieldTasksStatus;
import com.sunsum.model.dto.FieldsTaskInfo;
import com.sunsum.model.dto.TaskAndFieldIdPair;
import com.sunsum.model.entity.Task;
import com.sunsum.model.entity.TaskField;
import com.sunsum.repository.FieldRepository;
import com.sunsum.repository.TaskFieldRepository;
import com.sunsum.service.FieldTaskService;
import com.sunsum.util.TaskUtil;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.geo.Point;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class FieldTaskServiceImpl implements FieldTaskService {

  private final FieldRepository fieldRepository;
  private final TaskFieldRepository taskFieldRepository;

  @Override
  public List<FieldTasksStatus> getAllFieldsTask(Long farmHoldingId) {
    try {
      List<FieldsTaskInfo> fieldsTaskInfo = getFieldTaskInfo(farmHoldingId);
      List<FieldTasksStatus> fieldTasksStatus = getTasksGroupByField(fieldsTaskInfo);
      fieldTasksStatus.sort(getJapaneseTitleComparator());
      return fieldTasksStatus;
    } catch (Exception e) {
      log.error(
          "error occurred while getting all tasks for farm holding due to {} {}",
          e.getMessage(),
          e.getCause());
      throw new BusinessRuleException(ErrorMsgConstants.GET_TASKS_ERROR_MSG, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Override
  public List<FieldTasksStatus> getUpcomingFieldTasks(Long farmHoldingId) {
    try {
      List<FieldTasksStatus> fieldTasksStatus =
          getTasksGroupByField(getFieldTaskInfo(farmHoldingId));
      return fieldTasksStatus.stream()
          .map(this::upcomingTaskMapper)
          .filter(Objects::nonNull)
          .sorted(getJapaneseTitleComparator())
          .toList();
    } catch (Exception e) {
      log.error(
          "error occurred while getting upcoming tasks for farm holding due to {} {}",
          e.getMessage(),
          e.getCause());
      throw new BusinessRuleException(ErrorMsgConstants.GET_TASKS_ERROR_MSG, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  private FieldTasksStatus upcomingTaskMapper(FieldTasksStatus fieldTasksStatus) {
    List<FieldsTaskInfo> fieldsTaskInfo = fieldTasksStatus.getTaskStatus();
    List<FieldsTaskInfo> upComingTask =
        fieldsTaskInfo.stream()
            .filter(upcomingTaskPredicate())
            .collect(Collectors.toCollection(ArrayList::new));

    /* In case no OVERDUE, EXECUTABLE and INEXECUTABLE_2D tasks, 4 tasks will be selected based on nearest Executable Date and Display Order.
     If there are tasks with the same Executable Date, the task with the higher display order will be selected.
    * */
    if (upComingTask.isEmpty()) {
      upComingTask =
          fieldsTaskInfo.stream()
              .filter(
                  it ->
                      it.getExecutableDate() != null
                          && !AppConstants.TASK_EXECUTION_STATUS_COMPLETED.equals(it.getStatus()))
              .sorted(getTaskComparator())
              .limit(4)
              .collect(Collectors.toCollection(ArrayList::new));
      /*
       * in case if there are less than 4 tasks with Executable Date, additional, the task with the higher display order will be selected.
       * */
      if (upComingTask.size() < 4) {
        int noOfTaskToBeAdded = 4 - upComingTask.size();
        fieldsTaskInfo.removeAll(upComingTask);
        List<FieldsTaskInfo> additionalTaskToAdded =
            fieldsTaskInfo.stream()
                .filter(it -> !AppConstants.TASK_EXECUTION_STATUS_COMPLETED.equals(it.getStatus()))
                .sorted((Comparator.comparing(FieldsTaskInfo::getTaskOrder)))
                .limit(noOfTaskToBeAdded)
                .collect(Collectors.toCollection(ArrayList::new));
        upComingTask.addAll(additionalTaskToAdded);
      }
    }
    return getFieldTasksStatus(fieldTasksStatus, upComingTask);
  }

  private static FieldTasksStatus getFieldTasksStatus(
      FieldTasksStatus fieldTasksStatus, List<FieldsTaskInfo> upComingTask) {
    return upComingTask.isEmpty()
        ? null
        : FieldTasksStatus.builder()
            .fieldId(fieldTasksStatus.getFieldId())
            .fieldTitle(fieldTasksStatus.getFieldTitle())
            .gps(fieldTasksStatus.getGps())
            .taskStatus(upComingTask)
            .build();
  }

  private static Predicate<FieldsTaskInfo> upcomingTaskPredicate() {
    return it ->
        AppConstants.TASK_EXECUTION_STATUS_EXECUTABLE.equals(it.getStatus())
            || AppConstants.TASK_EXECUTION_STATUS_INEXECUTABLE_2D.equals(it.getStatus())
            || AppConstants.TASK_EXECUTION_STATUS_OVERDUE.equals(it.getStatus());
  }

  private static List<FieldTasksStatus> getTasksGroupByField(List<FieldsTaskInfo> fieldsTaskInfo) {
    return fieldsTaskInfo.stream()
        .collect(Collectors.groupingBy(FieldsTaskInfo::getFieldBasicInfo))
        .entrySet()
        .stream()
        .map(
            e ->
                new FieldTasksStatus(
                    e.getKey().id(), e.getKey().title(), e.getKey().gps(), e.getValue()))
        .collect(Collectors.toCollection(ArrayList::new));
  }

  private static Comparator<FieldsTaskInfo> getTaskComparator() {
    return (task1, task2) ->
        task1.getExecutableDate().equals(task2.getExecutableDate())
            ? task1.getTaskOrder().compareTo(task2.getTaskOrder())
            : task1.getExecutableDate().compareTo(task2.getExecutableDate());
  }

  private List<FieldsTaskInfo> getFieldTaskInfo(Long farmHoldingId) {
    List<Long> filedIds = fieldRepository.findIdByFarmHoldingId(farmHoldingId);
    List<FieldTaskDetails> fieldTask = taskFieldRepository.findFieldAndTasksByFieldIdIn(filedIds);

    final Map<TaskAndFieldIdPair, TaskField> fieldTasks =
        taskFieldRepository.findByFieldIdIn(filedIds).stream()
            .collect(
                Collectors.toMap(
                    taskField ->
                        new TaskAndFieldIdPair(
                            taskField.getTask().getId(), taskField.getField().getId()),
                    taskField -> taskField));

    return fieldTask.stream()
        .map(it -> getFieldTaskInfo(it, fieldTasks))
        .collect(Collectors.toCollection(ArrayList::new));
  }

  private FieldsTaskInfo getFieldTaskInfo(
      FieldTaskDetails fieldsTaskDetails, Map<TaskAndFieldIdPair, TaskField> fieldTasks) {
    Task task = fieldsTaskDetails.getTask();
    TaskField taskField = getTaskField(task, fieldTasks, fieldsTaskDetails.getFieldId());
    String status = TaskUtil.getStatus(taskField);
    return FieldsTaskInfo.builder()
        .fieldBasicInfo(getFieldBasicInfo(fieldsTaskDetails))
        .taskTitle(task.getTitle())
        .taskId(task.getId().toString())
        .dueDate(taskField.getDueDate())
        .status(status)
        .taskOrder(task.getOrder())
        .executableDate(taskField.getExecutableDate())
        .build();
  }

  private static FieldBasicInfo getFieldBasicInfo(FieldTaskDetails fieldsTaskDetails) {
    Point gps = fieldsTaskDetails.getGps();
    return new FieldBasicInfo(
        fieldsTaskDetails.getFieldId(), fieldsTaskDetails.getFieldTitle(), gps != null, gps);
  }

  private static TaskField getTaskField(
      Task task, Map<TaskAndFieldIdPair, TaskField> fieldTasks, Long fieldId) {

    TaskField taskField = fieldTasks.get(new TaskAndFieldIdPair(task.getId(), fieldId));
    if (taskField == null) {
      taskField = new TaskField();
      TaskUtil.setExecutableAndDueDate(task, fieldTasks, taskField, fieldId);
    }
    return taskField;
  }

  private Comparator<FieldTasksStatus> getJapaneseTitleComparator() {
    Collator collator = Collator.getInstance(Locale.JAPAN);
    return Comparator.comparing(FieldTasksStatus::getFieldTitle, collator);
  }
}
