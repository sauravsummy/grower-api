package com.sunsum.service.impl;

import com.sunsum.exception.BusinessRuleException;
import com.sunsum.service.S3Service;
import com.sunsum.util.AwsS3Util;
import java.io.IOException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
@Slf4j
@RequiredArgsConstructor
public class S3ServiceImpl implements S3Service {

  @Value(value = "${cloud.aws.s3.cloud-front.bucket-name}")
  private String bucketName;

  private final AwsS3Util awsS3Util;

  @Override
  public void uploadObject(MultipartFile file, String key) {
    log.info("uploading object to s3 bucket {}", bucketName);
    try {
      awsS3Util.uploadFileToS3(file, bucketName, key);
    } catch (IOException e) {
      throw new BusinessRuleException(
          "Error occurred while uploading image to S3", HttpStatus.INTERNAL_SERVER_ERROR);
    }
    log.info("{} file uploaded to S3", file.getOriginalFilename());
  }

  @Override
  public void delete(String fileName) {
    log.info("deleting file {} form S3", fileName);
    try {
      awsS3Util.delete(bucketName, fileName);
    } catch (Exception e) {
      log.error("Error occurred while updating image due to {} {}", e.getMessage(), e.getCause());
    }
    log.info("deleted file {} form S3", fileName);
  }
}
