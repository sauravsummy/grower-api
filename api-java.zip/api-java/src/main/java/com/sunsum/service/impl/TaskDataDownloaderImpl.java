package com.sunsum.service.impl;

import com.sunsum.constants.AppConstants;
import com.sunsum.exception.BulkDownloadException;
import com.sunsum.repository.TaskRepository;
import com.sunsum.model.entity.CustomDefinition;
import com.sunsum.model.entity.Task;
import com.sunsum.service.DataDownload;
import com.sunsum.util.ExcelUtils;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

/**
 * Class to create a XLSX file with sheet name as task and writes task table data and return as a
 * byte stream.
 */
@Slf4j
@Service("taskDownloader")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class TaskDataDownloaderImpl implements DataDownload {

  private final TaskRepository taskRepository;
  private final ExcelUtils excelUtils;
  private List<Task> tasks;

  public TaskDataDownloaderImpl(TaskRepository taskRepository, ExcelUtils excelUtils) {
    this.taskRepository = taskRepository;
    this.excelUtils = excelUtils;
  }

  /**
   * To get the all the Task table data.
   *
   * @return DataDownload
   */
  @Override
  public DataDownload fetch() {
    tasks = taskRepository.findAllByOrderByIdAsc();
    return this;
  }

  /**
   * Method to create an Excel workbook and adds a sheet
   *
   * @param columns,mandatoryColumns the list of columns separated by comma
   * @return ByteArrayInputStream
   */
  @Override
  public ByteArrayInputStream prepareSheet(String columns, String mandatoryColumns) {
    try (XSSFWorkbook workbook = new XSSFWorkbook()) {
      XSSFSheet sheet = workbook.createSheet(AppConstants.SHEET_TASK);
      excelUtils.writeHeaderRow(columns, mandatoryColumns, workbook, sheet);
      writeDataRows(workbook, sheet);
      try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
        workbook.write(outputStream);
        return new ByteArrayInputStream(outputStream.toByteArray());
      }
    } catch (Exception e) {
      log.error("Exception Occurred while downloading the TASK data", e);
      throw new BulkDownloadException("Exception has occurred while downloading TASK data", e);
    }
  }

  /**
   * Writes Task table data to the sheet.
   *
   * @param sheet Excel sheet
   */
  private void writeDataRows(XSSFWorkbook workbook, XSSFSheet sheet) {
    int columnCount;
    // As header row added, rowNo should start from 1
    int rowNo = 1;
    Row row;
    // Creating data rows for each query
    for (Task task : tasks) {
      try {
        row = sheet.createRow(rowNo);
        columnCount = 0;
        excelUtils.createCell(row, columnCount++, task.getId(), null);
        excelUtils.createCell(row, columnCount++, task.getTitle(), null);
        excelUtils.createCell(row, columnCount++, task.getType().getValue(), null);
        excelUtils.createCell(row, columnCount++, task.getBrief(), null);
        excelUtils.createCell(row, columnCount++, task.getTaskGroup().getId(), null);
        String relatedTaskTitle =
            task.getRelatedTask() != null ? task.getRelatedTask().getTitle() : "null";
        excelUtils.createCell(row, columnCount++, relatedTaskTitle, null);
        excelUtils.createCell(row, columnCount++, task.getRelation().getValue(), null);
        excelUtils.createCell(row, columnCount++, task.getRelatedDays(), null);
        excelUtils.createCell(
            row, columnCount++, convertToString(task.getCustomDefinition()), null);
        excelUtils.createCell(row, columnCount++, task.getOrder(), null);
        CellStyle dateStyle = workbook.createCellStyle();
        dateStyle.setDataFormat(
            workbook.getCreationHelper().createDataFormat().getFormat("yyyy-MM-dd"));
        excelUtils.createCell(row, columnCount++, task.getFixedDueDate(), dateStyle);
        excelUtils.createCell(row, columnCount++, task.getIsLocked(), null);
        excelUtils.createCell(row, columnCount++, task.getMemo1(), null);
        excelUtils.createCell(row, columnCount++, task.getMemo2(), null);
        excelUtils.createCell(row, columnCount++, task.getMemo3(), null);
        excelUtils.createCell(row, columnCount++, task.getMemo4(), null);
        excelUtils.createCell(row, columnCount, task.getMemo5(), null);
        rowNo++;
      } catch (Exception e) {
        log.error(
            "Exception occurred while preparing excel row in project download for Id={}, Title={} ,Type={} ",
            task.getId(),
            task.getTitle(),
            task.getType().name(),
            e);
      }
    }
  }

  public static String convertToString(List<CustomDefinition> customDefinitions) {
    return customDefinitions.stream()
        .map(TaskDataDownloaderImpl::formatCustomDefinition)
        .collect(Collectors.joining(","));
  }

  private static String formatCustomDefinition(CustomDefinition def) {
    StringBuilder formatted = new StringBuilder();
    formatted.append(def.getAttributeName()).append(":").append(def.getType());
    if (!def.getValue().isEmpty()) {
      formatted.append("|").append(String.join("|", def.getValue()));
    }
    return formatted.toString();
  }
}
