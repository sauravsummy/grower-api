package com.sunsum.service.impl;

import com.google.gson.Gson;
import com.sunsum.constants.AppConstants;
import com.sunsum.constants.CustomType;
import com.sunsum.constants.ErrorMsgConstants;
import com.sunsum.constants.TaskFieldStatus;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.repository.TaskFieldRepository;
import com.sunsum.repository.TaskRepository;
import com.sunsum.model.dto.TaskStatus;
import com.sunsum.model.dto.TaskStatusResponse;
import com.sunsum.model.dto.TaskStatusUpdateRequest;
import com.sunsum.model.dto.TaskView;
import com.sunsum.model.entity.CustomDefinition;
import com.sunsum.model.entity.Field;
import com.sunsum.model.entity.Task;
import com.sunsum.model.entity.TaskField;
import com.sunsum.repository.FieldRepository;
import com.sunsum.service.S3Service;
import com.sunsum.service.TaskService;
import com.sunsum.util.DateUtil;
import com.sunsum.util.TaskUtil;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@Service
@RequiredArgsConstructor
public class TaskServiceImpl implements TaskService {

  public static final String TYPE = "type";
  public static final String ATTRIBUTE_NAME = "attributeName";

  @Value(value = "${cloud.aws.s3.cloud-front.url}")
  private String cloudFrontDomainUrl;

  private final TaskRepository taskRepository;
  private final TaskFieldRepository taskFieldRepository;
  private final FieldRepository fieldRepository;
  private final S3Service s3Service;

  @Override
  public TaskStatusResponse getAllTasks(String fieldId) {
    try {

      List<TaskStatus> taskStatus = getTaskStatuses(fieldId);

      return new TaskStatusResponse(taskStatus);
    } catch (Exception e) {
      log.error(
          "error occurred while getting tasks for farmholding due to {} {}",
          e.getMessage(),
          e.getCause());
      throw new BusinessRuleException(ErrorMsgConstants.GET_TASKS_ERROR_MSG, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  public TaskStatusResponse getUpcomingTasks(String fieldId) {
    List<TaskStatus> taskStatus = getTaskStatuses(fieldId);

    List<TaskStatus> upComingTask =
        taskStatus.stream()
            .filter(
                it ->
                    AppConstants.TASK_EXECUTION_STATUS_EXECUTABLE.equals(it.getStatus())
                        || AppConstants.TASK_EXECUTION_STATUS_INEXECUTABLE_2D.equals(it.getStatus())
                        || AppConstants.TASK_EXECUTION_STATUS_OVERDUE.equals(it.getStatus()))
            .collect(Collectors.toCollection(ArrayList::new));
    /* In case no OVERDUE, EXECUTABLE and INEXECUTABLE_2D tasks, 4 tasks will be selected based on nearest Executable Date and Display Order.
     If there are tasks with the same Executable Date, the task with the higher display order will be selected.
    * */
    if (upComingTask.isEmpty()) {
      upComingTask =
          taskStatus.stream()
              .filter(
                  it ->
                      it.getExecutableDate() != null
                          && !it.getExecutableDate().equals(DateUtil.MIN_DATE)
                          && !AppConstants.TASK_EXECUTION_STATUS_COMPLETED.equals(it.getStatus()))
              .sorted(
                  (task1, task2) ->
                      task1.getExecutableDate().equals(task2.getExecutableDate())
                          ? task1.getTaskOrder().compareTo(task2.getTaskOrder())
                          : task1.getExecutableDate().compareTo(task2.getExecutableDate()))
              .limit(4)
              .collect(Collectors.toCollection(ArrayList::new));

      /*
       * in case if there are less than 4 tasks with Executable Date, additional, the task with the higher display order will be selected.
       * */
      if (upComingTask.size() < 4) {
        int noOfTaskToBeAdded = 4 - upComingTask.size();
        taskStatus.removeAll(upComingTask);
        List<TaskStatus> additionalTaskToAdded =
            taskStatus.stream()
                .filter(it -> !AppConstants.TASK_EXECUTION_STATUS_COMPLETED.equals(it.getStatus()))
                .sorted((Comparator.comparing(TaskStatus::getTaskOrder)))
                .limit(noOfTaskToBeAdded)
                .collect(Collectors.toCollection(ArrayList::new));
        upComingTask.addAll(additionalTaskToAdded);
      }
    }
    return new TaskStatusResponse(upComingTask);
  }

  @Override
  public TaskView getTaskView(Long taskId, Long fieldId) {
    log.info("Fetching TaskField with Task ID: {} and Field ID: {}", taskId, fieldId);
    TaskField taskField = taskFieldRepository.findByTaskIdAndFieldId(taskId, fieldId).orElse(null);
    Task task = taskField != null ? taskField.getTask() : getTask(taskId);
    TaskView taskView = new TaskView();
    taskView.setFieldId(fieldId);
    taskView.setTaskId(taskId);
    taskView.setTaskBrief(task.getBrief());
    taskView.setTaskTitle(task.getTitle());
    taskView.setTaskType(task.getType());
    if (taskField != null) {
      taskView.setTaskStatus(taskField.getTaskStatus());
      taskView.setCompletionDate(taskField.getCompletionDate());
      if (TaskFieldStatus.ACKNOWLEDGED.equals(taskField.getTaskStatus())) {
        taskView.setReportDefinitions(task.getCustomDefinition());
      } else {
        taskView.setReportDefinitions(taskField.getCustomInput());
      }
    } else {
      taskView.setTaskStatus(TaskFieldStatus.INITIAL);
      taskView.setReportDefinitions(task.getCustomDefinition());
    }

    log.info(
        "Successfully fetched TaskField data for Task ID: {} and Field ID: {}", taskId, fieldId);

    return taskView;
  }

  @Override
  public String updateTaskStatus(Long taskId, TaskStatusUpdateRequest updateRequest) {
    try {
      TaskField taskField =
          taskFieldRepository
              .findByTaskIdAndFieldId(taskId, updateRequest.fieldId())
              .orElse(new TaskField());

      if (TaskFieldStatus.ACKNOWLEDGED.equals(updateRequest.status())) {
        handleTaskAcknowledgement(taskId, updateRequest, taskField);

      } else {
        handleTaskConfirmationAndCompletion(taskId, updateRequest, taskField);
      }
      TaskField updatedTaskField = taskFieldRepository.save(taskField);
      return updatedTaskField.getTaskStatus().toString();
    } catch (Exception e) {
      log.error(
          "Error occurred while updating task status due to {} {}", e.getMessage(), e.getCause());
      throw new BusinessRuleException(
          ErrorMsgConstants.UNABLE_TO_UPDATE_TASK_STATUS, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  private void handleTaskConfirmationAndCompletion(
      Long taskId, TaskStatusUpdateRequest updateRequest, TaskField taskField) {
    taskField.setTaskStatus(updateRequest.status());
    LocalDate completionDate =
        LocalDate.parse(updateRequest.CompletionDate(), DateTimeFormatter.ofPattern("yyyy/MM/dd"));
    taskField.setCompletionDate(completionDate);
    if (updateRequest.reportDefinitions() != null) {
      Gson gson = new Gson();
      List<Map<String, Object>> reportDefinitions =
          gson.fromJson(updateRequest.reportDefinitions(), List.class);
      List<CustomDefinition> customDefinitions = new ArrayList<>();
      List<String> imagePaths = uploadImage(updateRequest.images(), taskId);
      prepareCustomDefinition(reportDefinitions, imagePaths, customDefinitions);
      taskField.setCustomInput(customDefinitions);
    }
  }

  private void handleTaskAcknowledgement(
      Long taskId, TaskStatusUpdateRequest updateRequest, TaskField taskField) {
    if (taskField.getField() == null) {
      Field field = getField(updateRequest.fieldId());
      taskField.setField(field);
    }
    if (taskField.getTask() == null) {
      Task task = getTask(taskId);
      taskField.setTask(task);
    }
    taskField.setTaskStatus(TaskFieldStatus.ACKNOWLEDGED);
    Task relatedTask = taskField.getTask().getRelatedTask();
    Map<Long, TaskField> relatedTaskField = new HashMap<>();
    if (Objects.nonNull(relatedTask)) {
      taskFieldRepository
          .findByTaskIdAndFieldId(relatedTask.getId(), updateRequest.fieldId())
          .ifPresent(it -> relatedTaskField.put(relatedTask.getId(), it));
    }
    TaskUtil.setExecutableAndDueDate(taskField.getTask(), relatedTaskField, taskField);
  }

  public Task getTask(Long taskId) {
    return taskRepository
        .findById(taskId)
        .orElseThrow(() -> new BusinessRuleException(ErrorMsgConstants.NO_RECORD_FOUND, HttpStatus.NOT_FOUND));
  }

  private Field getField(Long fieldId) {
    return fieldRepository
        .findById(fieldId)
        .orElseThrow(() -> new BusinessRuleException(ErrorMsgConstants.NO_RECORD_FOUND, HttpStatus.NOT_FOUND));
  }

  private List<String> uploadImage(List<MultipartFile> images, Long taskId) {
    final List<String> paths = new ArrayList<>();
    if (images == null) {
      return paths;
    }
    final String key = "task" + AppConstants.FILE_PATH_SEPARATOR + taskId;
    images.forEach(
        it -> {
          s3Service.uploadObject(it, key);
          paths.add(
              cloudFrontDomainUrl
                  + AppConstants.FILE_PATH_SEPARATOR
                  + key
                  + AppConstants.FILE_PATH_SEPARATOR
                  + it.getOriginalFilename()
                  + "?size="
                  + it.getSize());
        });
    return paths;
  }

  private static void prepareCustomDefinition(
      List<Map<String, Object>> reportDefinitions,
      List<String> imagePaths,
      List<CustomDefinition> customDefinitions) {
    reportDefinitions.forEach(
        it -> {
          CustomDefinition customDefinition = new CustomDefinition();
          customDefinition.setType(
              CustomType.valueOf(it.get(TYPE).toString().trim().toUpperCase()));
          customDefinition.setAttributeName(it.get(ATTRIBUTE_NAME).toString());
          if (CustomType.PHOTO_ATTACHMENT.equals(
              CustomType.valueOf(it.get(TYPE).toString().trim().toUpperCase()))) {
            customDefinition.setValue(imagePaths);
          } else {
            customDefinition.setValue((List<String>) it.get("value"));
          }
          customDefinitions.add(customDefinition);
        });
  }

  private List<TaskStatus> getTaskStatuses(String fieldId) {
    List<Task> tasks = taskRepository.findTasksByFieldId(Long.parseLong(fieldId));
    final Map<Long, TaskField> fieldTasks =
        taskFieldRepository.findByFieldId(Long.parseLong(fieldId)).stream()
            .collect(
                Collectors.toMap(taskField -> taskField.getTask().getId(), taskField -> taskField));

    return tasks.stream()
        .map(it -> getTaskDetails(it, fieldTasks))
        .collect(Collectors.toCollection(ArrayList::new));
  }

  private TaskStatus getTaskDetails(Task task, Map<Long, TaskField> fieldTasks) {

    TaskField taskField = getTaskField(task, fieldTasks);
    String status = TaskUtil.getStatus(taskField);
    return TaskStatus.builder()
        .taskTitle(task.getTitle())
        .taskId(task.getId().toString())
        .dueDate(taskField.getDueDate())
        .status(status)
        .taskOrder(task.getOrder())
        .executableDate(taskField.getExecutableDate())
        .build();
  }

  private static TaskField getTaskField(Task task, Map<Long, TaskField> fieldTasks) {

    TaskField taskField = fieldTasks.get(task.getId());
    if (taskField == null) {
      taskField = new TaskField();
      TaskUtil.setExecutableAndDueDate(task, fieldTasks, taskField);
    }
    return taskField;
  }

  @Override
  public Map<String, Long> countOverdueAndExecutableTasks(String fieldId) {
    List<TaskStatus> taskStatuses = getTaskStatuses(fieldId);

    long overdueCount = 0;
    long executableInTwoDaysCount = 0;
    long inExecutableInTwoDaysCount = 0;

    // Iterate through the list once and count each status
    for (TaskStatus status : taskStatuses) {
      if (AppConstants.TASK_EXECUTION_STATUS_OVERDUE.equals(status.getStatus())) {
        overdueCount++;
      } else if (AppConstants.TASK_EXECUTION_STATUS_EXECUTABLE.equals(status.getStatus())) {
        executableInTwoDaysCount++;
      } else if (AppConstants.TASK_EXECUTION_STATUS_INEXECUTABLE_2D.equals(status.getStatus())) {
        inExecutableInTwoDaysCount++;
      }
    }

    Map<String, Long> taskCounts = new HashMap<>();
    taskCounts.put("OVERDUE", overdueCount);
    // Sum of executable and inexecutable tasks within two days = upcoming tasks
    taskCounts.put("UPCOMING_TASKS", executableInTwoDaysCount + inExecutableInTwoDaysCount);

    return taskCounts;
  }
}
