package com.sunsum.service.impl;

import com.sunsum.constants.AppConstants;
import com.sunsum.exception.BulkDownloadException;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.model.entity.Role;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.service.DataDownload;
import com.sunsum.util.ExcelUtils;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Class to create a XLSX file with sheet name as User and writes user table data and return as a
 * byte stream.
 */
@Service("userDownloader")
@Slf4j
public class UserDataDownloadImpl implements DataDownload {

  private final UserProfileRepository userProfileRepo;
  private final ExcelUtils excelUtils;
  private List<UserProfile> userProfiles;

  @Autowired
  public UserDataDownloadImpl(UserProfileRepository userProfileRepo, ExcelUtils excelUtils) {
    this.userProfileRepo = userProfileRepo;
    this.excelUtils = excelUtils;
  }

  /**
   * To get the all the user table data.
   *
   * @return DataDownload
   */
  @Override
  public DataDownload fetch() {
    userProfiles = userProfileRepo.findAllByOrderByIdAsc();
    return this;
  }

  /**
   * Method to create an Excel workbook and adds a sheet
   *
   * @param columns the list of columns separated by comma
   * @return ByteArrayInputStream
   */
  @Override
  public ByteArrayInputStream prepareSheet(String columns, String mandatoryColumns) {
    try (XSSFWorkbook workbook = new XSSFWorkbook()) {
      XSSFSheet sheet = workbook.createSheet(AppConstants.SHEET_USER);
      excelUtils.writeHeaderRow(columns, mandatoryColumns, workbook, sheet);
      writeDataRows(sheet);
      try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
        workbook.write(outputStream);
        return new ByteArrayInputStream(outputStream.toByteArray());
      }
    } catch (Exception e) {
      log.error("Exception Occurred while downloading the USER data", e);
      throw new BulkDownloadException("Exception has occurred while downloading USER data", e);
    }
  }

  /**
   * Writes User table data to the sheet.
   *
   * @param sheet the XSSFSheet sheet
   */
  private void writeDataRows(XSSFSheet sheet) {
    int columnCount;
    int rowNo = 1;
    // Creating data rows for each query
    for (UserProfile userProfile : userProfiles) {
      try {
        Row row = sheet.createRow(rowNo);
        columnCount = 0;
        excelUtils.createCell(
            row, columnCount++, userProfile.getId(), Long.class, null, CellType.NUMERIC);
        excelUtils.createCell(row, columnCount++, userProfile.getName(), null);
        Set<Role> roles = userProfile.getRoles();
        String roleStr =
            roles.stream().map(r -> r.getName().name()).collect(Collectors.joining(","));
        excelUtils.createCell(row, columnCount++, roleStr, null);
        excelUtils.createCell(row, columnCount++, userProfile.getEmail(), null);
        excelUtils.createCell(
            row, columnCount++, userProfile.getPhoneNo(), Long.class, null, CellType.NUMERIC);
        String reportEmail =
            Objects.nonNull(userProfile.getReportingTo())
                ? userProfile.getReportingTo().getEmail()
                : "null";
        excelUtils.createCell(row, columnCount++, reportEmail, null);
        excelUtils.createCell(
            row,
            columnCount++,
            userProfile.getOrganization().getId(),
            Long.class,
            null,
            CellType.NUMERIC);
        excelUtils.createCell(row, columnCount++, userProfile.getIsActive(), null);
        excelUtils.createCell(row, columnCount++, userProfile.getMemo1(), null);
        excelUtils.createCell(row, columnCount++, userProfile.getMemo2(), null);
        excelUtils.createCell(row, columnCount++, userProfile.getMemo3(), null);
        excelUtils.createCell(row, columnCount++, userProfile.getMemo4(), null);
        excelUtils.createCell(row, columnCount, userProfile.getMemo5(), null);
        rowNo++;
      } catch (Exception e) {
        log.error(
            "Exception occurred while preparing excel row in User for Id ={} and Name={}, Email={}",
            userProfile.getId(),
            userProfile.getName(),
            userProfile.getEmail(),
            e);
      }
    }
  }
}
