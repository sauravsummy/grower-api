package com.sunsum.service;

import com.sunsum.model.entity.Token;
import com.sunsum.model.entity.UserProfile;
import java.util.List;
import java.util.Optional;

public interface TokenService {
  boolean logoff(String token);

  void save(Token token);

  Optional<Token> findByToken(String token);

  List<Token> findByUserProfile(UserProfile user);

  void deleteTokenByUserProfile(UserProfile userProfile);
}
