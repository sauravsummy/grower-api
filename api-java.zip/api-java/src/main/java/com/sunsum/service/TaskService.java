package com.sunsum.service;

import com.sunsum.model.dto.TaskStatusResponse;
import com.sunsum.model.dto.TaskStatusUpdateRequest;
import com.sunsum.model.dto.TaskView;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public interface TaskService {

  public TaskStatusResponse getAllTasks(String fieldId);

  public TaskStatusResponse getUpcomingTasks(String fieldId);

  TaskView getTaskView(Long taskId, Long fieldId);

  String updateTaskStatus(Long taskId, TaskStatusUpdateRequest updateRequest);

  Map<String, Long> countOverdueAndExecutableTasks(String fieldId);
}
