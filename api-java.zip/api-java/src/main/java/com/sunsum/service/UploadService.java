package com.sunsum.service;

import com.sunsum.model.dto.BulkUploadTracker;
import com.sunsum.model.dto.SheetIngestionResult;
import java.util.List;
import org.springframework.web.multipart.MultipartFile;

public interface UploadService {
  SheetIngestionResult bulkInsert(MultipartFile file);

  List<BulkUploadTracker> getUploadTrackerDetails();
}
