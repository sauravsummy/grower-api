package com.sunsum.service.impl;

import com.sunsum.constants.AppConstants;
import com.sunsum.constants.CustomType;
import com.sunsum.constants.TaskRelation;
import com.sunsum.constants.TaskType;
import com.sunsum.repository.TaskGroupRepository;
import com.sunsum.repository.TaskRepository;
import com.sunsum.exception.BulkUploadException;
import com.sunsum.model.dto.RowIngestionResult;
import com.sunsum.model.entity.CustomDefinition;
import com.sunsum.model.entity.IngestionStatus;
import com.sunsum.model.entity.Task;
import com.sunsum.model.entity.TaskGroup;
import com.sunsum.service.DataUpload;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Service("taskUploader")
@Slf4j
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class TaskDataUploaderImpl implements DataUpload {

  private Task taskEntity;
  private final TaskRepository taskRepository;
  private final TaskGroupRepository taskGroupRepository;

  public TaskDataUploaderImpl(
      TaskRepository taskRepository, TaskGroupRepository taskGroupRepository) {
    this.taskRepository = taskRepository;
    this.taskGroupRepository = taskGroupRepository;
  }

  @Override
  public DataUpload createFromRow(Row row, Map<String, Integer> columnNameToIndex) {
    taskEntity = new Task();
    String title =
        getCellValue(row.getCell(columnNameToIndex.get(AppConstants.TITLE)), String.class);
    String type = getCellValue(row.getCell(columnNameToIndex.get(AppConstants.TYPE)), String.class);
    Long taskGroupId =
        getCellValue(row.getCell(columnNameToIndex.get(AppConstants.TASKGROUP_ID)), Long.class);
    try {
      if (columnNameToIndex.get(AppConstants.ID) != null) {
        Long id = getCellValue(row.getCell(columnNameToIndex.get(AppConstants.ID)), Long.class);
        if (id != null) {
          taskEntity.setId(id);
        }
      }
      taskEntity.setTitle(title);
      taskEntity.setType(TaskType.fromString(type));
      Optional<TaskGroup> taskGroupOptional = taskGroupRepository.findById(taskGroupId);
      taskGroupOptional.ifPresent(tg -> taskEntity.setTaskGroup(tg));
      taskEntity.setBrief(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.BRIEF)), String.class));

      String relatedTaskTitle =
          getCellValue(
              row.getCell(columnNameToIndex.get(AppConstants.RELATED_TASK_TITLE)), String.class);
      if (relatedTaskTitle != null
          && !relatedTaskTitle.equalsIgnoreCase(AppConstants.NULL_STRING)) {
        Optional<Task> relatedTask =
            taskRepository.findByTitleAndTaskGroup_Id(relatedTaskTitle, taskGroupId);
        relatedTask.ifPresent(task -> taskEntity.setRelatedTask(task));
      }

      String relationStr =
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.RELATION)), String.class);
      taskEntity.setRelation(TaskRelation.fromString(relationStr));

      taskEntity.setRelatedDays(
          getCellValue(
              row.getCell(columnNameToIndex.get(AppConstants.RELATION_DAYS)), Integer.class));

      LocalDate fixedDueDate =
          getCellValue(
              row.getCell(columnNameToIndex.get(AppConstants.FIXED_DUE_DATE)), LocalDate.class);

      if (relationStr.equals(TaskRelation.FIXED_DUE_DATE.getValue()) && fixedDueDate == null) {
        throw new BulkUploadException(
            "The Fixed Due date is required when relation is Fixed Due Date!");
      }
      taskEntity.setFixedDueDate(fixedDueDate);

      List<CustomDefinition> customDefinitions =
          prepareCustomDefinition(
              getCellValue(
                  row.getCell(columnNameToIndex.get(AppConstants.CUSTOM_DEFINITION)),
                  String.class));
      taskEntity.setCustomDefinition(customDefinitions);
      taskEntity.setOrder(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.ORDER)), Integer.class));
      taskEntity.setIsLocked(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.IS_LOCKED)), Boolean.class));
      taskEntity.setMemo1(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_1)), String.class));
      taskEntity.setMemo2(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_2)), String.class));
      taskEntity.setMemo3(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_3)), String.class));
      taskEntity.setMemo4(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_4)), String.class));
      taskEntity.setMemo5(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_5)), String.class));
    } catch (Exception e) {
      log.error(
          "Exception occurred while creating a Task entity from the excel row for Title={}, Type={}, Task Group ={}",
          title,
          type,
          taskGroupId,
          e);
      throw new BulkUploadException(
          "Exception occurred while transforming the Excel row to Task entity", e);
    }
    return this;
  }

  private List<CustomDefinition> prepareCustomDefinition(String cellValue) {
    return Arrays.stream(cellValue.split(AppConstants.COMMA))
        .map(
            custDef -> {
              String[] custDefCols = custDef.split(AppConstants.COLON);
              // Each custom definition should have at least two parts
              if (custDefCols.length < 2) {
                log.error("Skipping invalid custom definition: {}", custDef);
                return null;
              }

              try {
                String attributeName = custDefCols[0].trim();
                CustomType type;
                String[] typeArr = null;
                if (custDefCols[1].contains("|")) {
                  typeArr = custDefCols[1].split("\\|");
                  type = CustomType.valueOf(typeArr[0].toUpperCase().trim());
                } else {
                  type = CustomType.valueOf(custDefCols[1].toUpperCase().trim());
                }

                List<String> values;
                if (custDefCols.length == 2 && typeArr != null) {
                  values = Arrays.asList(typeArr).subList(1, typeArr.length);
                } else {
                  // Empty list for types other than "selection"
                  values = List.of();
                }

                return CustomDefinition.builder()
                    .attributeName(attributeName)
                    .type(type)
                    .value(values)
                    .build();
              } catch (IllegalArgumentException e) {
                log.error("Invalid Custom Type ={}", custDefCols[0]);
                return null;
              }
            })
        .filter(Objects::nonNull)
        .toList();
  }

  @Override
  public RowIngestionResult dataInjection(int rowNum) {
    IngestionStatus ingestionStatus;
    try {
      ingestionStatus =
          taskEntity.getId() == null ? IngestionStatus.INSERTED : IngestionStatus.UPDATED;
      taskRepository.save(taskEntity);
    } catch (Exception e) {
      log.error(
          "Exception Occurred while inserting Task  Title={} for Task Group Id={} ",
          taskEntity.getTitle(),
          taskEntity.getTaskGroup().getId(),
          e);
      throw new BulkUploadException("Exception Occurred while saving the task data", e);
    }
    return RowIngestionResult.builder().rowNumber(rowNum).status(ingestionStatus).build();
  }
}
