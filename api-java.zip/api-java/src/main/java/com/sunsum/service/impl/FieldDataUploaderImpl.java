package com.sunsum.service.impl;

import com.sunsum.constants.AppConstants;
import com.sunsum.constants.OrgType;
import com.sunsum.constants.Status;
import com.sunsum.repository.FieldTaskGroupRepository;
import com.sunsum.repository.OrganisationRepository;
import com.sunsum.repository.TaskFieldRepository;
import com.sunsum.repository.TaskGroupRepository;
import com.sunsum.repository.TaskRepository;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.exception.BulkUploadException;
import com.sunsum.model.dto.RowIngestionResult;
import com.sunsum.model.entity.Field;
import com.sunsum.model.entity.FieldTaskGroup;
import com.sunsum.model.entity.IngestionStatus;
import com.sunsum.model.entity.Organization;
import com.sunsum.model.entity.TaskGroup;
import com.sunsum.repository.FieldRepository;
import com.sunsum.service.DataUpload;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import liquibase.repackaged.org.apache.commons.lang3.StringUtils;
import liquibase.repackaged.org.apache.commons.lang3.exception.ExceptionUtils;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.data.geo.Point;
import org.springframework.stereotype.Service;

/**
 * Implementation of DataUpload for uploading field data from an Excel row. This class is
 * responsible for mapping Excel row data to the Field entity and persisting it.
 */
@Service("fieldUploader")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Getter
@Setter
@Slf4j
public class FieldDataUploaderImpl implements DataUpload {

  private Row currentRow; // To store the current Excel row
  private Map<String, Integer> currentColumnNameToIndex;

  private FieldRepository fieldRepository;

  private UserProfileRepository userProfileRepository;

  private TaskGroupRepository taskGroupRepository;

  private OrganisationRepository organisationRepository;

  private FieldTaskGroupRepository fieldTaskGroupRepository;

  private Field fieldEntity;

  private TaskRepository taskRepository;

  private TaskFieldRepository taskFieldRepository;

  public FieldDataUploaderImpl(
      FieldRepository fieldRepository,
      UserProfileRepository userProfileRepository,
      TaskGroupRepository taskGroupRepository,
      OrganisationRepository organisationRepository,
      FieldTaskGroupRepository fieldTaskGroupRepository,
      TaskRepository taskRepository,
      TaskFieldRepository taskFieldRepository) {
    this.fieldRepository = fieldRepository;
    this.userProfileRepository = userProfileRepository;
    this.taskGroupRepository = taskGroupRepository;
    this.organisationRepository = organisationRepository;
    this.fieldTaskGroupRepository = fieldTaskGroupRepository;
    this.taskRepository = taskRepository;
    this.taskFieldRepository = taskFieldRepository;
  }

  /**
   * Creates a Field entity from a given Excel row.
   *
   * @param row The Excel row to process.
   * @param columnNameToIndex A mapping of column names to their indices in the row.
   * @return This instance of FieldDataUploaderImpl, with the fieldEntity populated from the row
   *     data.
   */
  @Override
  public DataUpload createFromRow(Row row, Map<String, Integer> columnNameToIndex) {
    log.info("Creating Field entity from Excel row: {}", row.getRowNum());
    fieldEntity = new Field();
    // Store the row and columnNameToIndex for later use
    this.currentRow = row;
    this.currentColumnNameToIndex = columnNameToIndex;
    try {
      if (columnNameToIndex.get(AppConstants.ID) != null) {
        Long id = getCellValue(row.getCell(columnNameToIndex.get(AppConstants.ID)), Long.class);
        if (id != null) {
          fieldEntity.setId(id);
        }
      }
      fieldEntity.setTitle(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.TITLE)), String.class));

      Long farmHoldingId =
          getCellValue(
              row.getCell(columnNameToIndex.get(AppConstants.FARM_HOLDING_ID)), Long.class);
      Optional<Organization> organization =
          organisationRepository.findByIdAndType(farmHoldingId, OrgType.FARM_HOLDINGS);
      fieldEntity.setFarmHolding(
          organization.orElseThrow(
              () ->
                  new BulkUploadException(
                      "The provided FarmHolding Id is not of type Farm Holdings")));

      setGeoCoordinates(row, columnNameToIndex);
      setZipCode(row, columnNameToIndex);
      fieldEntity.setAcreage(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.ACREAGE)), BigDecimal.class));
      // Check and update FieldTaskGroup status if field status is INACTIVE
      String fieldStatus =
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.STATUS)), String.class);
      fieldStatus = Objects.isNull(fieldStatus) ? AppConstants.ACTIVE : fieldStatus;
      fieldEntity.setStatus(Status.fromString(fieldStatus));

      if (Status.fromString(fieldStatus) == Status.INACTIVE) {
        deactivateAssociatedFieldTaskGroups(fieldEntity.getId());
      }

      // Fetching and setting the general note
      fieldEntity.setNote(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO)), String.class));

      Cell photoPathCell = row.getCell(columnNameToIndex.get(AppConstants.PHOTO_PATH));
      if (photoPathCell != null && !photoPathCell.getStringCellValue().trim().isEmpty()) {
        // Non-empty cell: split by comma and set the photo paths
        String photoPathCellValue = photoPathCell.getStringCellValue();
        String[] photoPaths = photoPathCellValue.split(",");
        fieldEntity.setPhotoPath(photoPaths);
      } else {
        // Empty cell: set an empty array
        fieldEntity.setPhotoPath(new String[0]);
      }
      extractTaskGroups(row, columnNameToIndex);
      fieldEntity.setMemo1(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_1)), String.class));
      fieldEntity.setMemo2(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_2)), String.class));
      fieldEntity.setMemo3(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_3)), String.class));
      fieldEntity.setMemo4(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_4)), String.class));
      fieldEntity.setMemo5(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_5)), String.class));
      log.info("Field entity created successfully for row: {}", row.getRowNum());
    } catch (Exception e) {
      log.error("Exception occurred while transforming the Excel row to field entity", e);
      throw new BulkUploadException(
          "Exception occurred while transforming the Excel row to field entity", e);
    }
    return this;
  }

  private void setZipCode(Row row, Map<String, Integer> columnNameToIndex) {

    String zipCode =
        getCellValue(row.getCell(columnNameToIndex.get(AppConstants.ZIP_CODE)), String.class);
    if (zipCode != null) {
      zipCode = zipCode.split("\\.")[0];
      if (zipCode.matches("\\d{7}")) {
        fieldEntity.setZipCode(zipCode);
      } else {
        log.warn("Invalid ZIP code: {}", zipCode);
        throw new BulkUploadException("Invalid Zip code");
      }
    }
  }

  private void setGeoCoordinates(Row row, Map<String, Integer> columnNameToIndex) {
    Integer columnIndex = columnNameToIndex.get(AppConstants.GPS_COORD);
    if (columnIndex == null) {
      // Handle the case where the column doesn't exist
      return;
    }

    Cell cell = row.getCell(columnIndex);
    if (cell == null || cell.getCellType() != CellType.STRING) {
      return;
    }

    String[] parts = handleInvalidGeoCoordinates(cell);
    if (parts.length != 0) {
      try {
        double latitude = Double.parseDouble(parts[0]);
        double longitude = Double.parseDouble(parts[1]);
        Point point = new Point(latitude, longitude);
        fieldEntity.setGpsCoordinates(point);
      } catch (NumberFormatException e) {
        // Handle parsing error
      }
    }
  }

  private static String[] handleInvalidGeoCoordinates(Cell cell) {
    String cellValue = cell.getStringCellValue();
    if (cellValue == null || !cellValue.contains(",")) {
      // Handle invalid cell value
      return new String[0];
    }

    String[] parts = cellValue.split(", ");
    if (parts.length != 2) {
      // Handle invalid format
      return new String[0];
    }
    return parts;
  }

  @Override
  public RowIngestionResult dataInjection(int rowNum) {
    IngestionStatus ingestionStatus;
    try {
      ingestionStatus =
          fieldEntity.getId() == null ? IngestionStatus.INSERTED : IngestionStatus.UPDATED;
      Field fieldData = fieldRepository.save(fieldEntity);
      log.info("Field entity saved successfully with ID: {}", fieldData.getId());
      // After saving the Field entity, now save associated FieldTaskGroup entities
      if (this.currentRow != null && this.currentColumnNameToIndex != null) {
        saveFieldTaskGroups(this.currentRow, this.currentColumnNameToIndex);
      }

    } catch (Exception e) {
      log.error(
          "Data injection failed for row {}. Error: {}",
          rowNum,
          ExceptionUtils.getRootCauseMessage(e));
      throw new BulkUploadException("Exception Occurred while saving the field data", e);
    }
    return RowIngestionResult.builder().rowNumber(rowNum).status(ingestionStatus).build();
  }

  private void saveFieldTaskGroups(Row row, Map<String, Integer> columnNameToIndex) {
    if (fieldEntity.getTaskGroups() != null) {
      // Check field status
      boolean isFieldInactive = fieldEntity.getStatus() == Status.INACTIVE;

      // Process each task group
      fieldEntity
          .getTaskGroups()
          .forEach(
              taskGroup -> {
                log.info("fieldEntity - field id: {}", fieldEntity.getId());

                // Find existing FieldTaskGroup
                Optional<FieldTaskGroup> existingFieldTaskGroupOpt =
                    fieldTaskGroupRepository.findByFieldIdAndTaskGroupIdAndFiledTaskGroupStatus(
                        fieldEntity.getId(), taskGroup.getId(), Status.ACTIVE);

                FieldTaskGroup fieldTaskGroup =
                    existingFieldTaskGroupOpt.orElse(new FieldTaskGroup());

                fieldTaskGroup.setFieldId(fieldEntity.getId());
                fieldTaskGroup.setTaskGroupId(taskGroup.getId());

                // Set status based on field status
                if (isFieldInactive) {
                  fieldTaskGroup.setFiledTaskGroupStatus(Status.INACTIVE);
                } else {
                  String status =
                      getCellValue(
                          row.getCell(columnNameToIndex.get(AppConstants.FIELD_TASK_GROUP_STATUS)),
                          String.class);
                  status = StringUtils.isBlank(status) ? AppConstants.ACTIVE : status;
                  fieldTaskGroup.setFiledTaskGroupStatus(Status.fromString(status));
                }

                // Set memo for FieldTaskGroup
                fieldTaskGroup.setFieldTaskGroupMemo(
                    getCellValue(
                        row.getCell(columnNameToIndex.get(AppConstants.FIELD_TASK_GROUP_MEMO)),
                        String.class));

                fieldTaskGroupRepository.save(fieldTaskGroup);
              });

      // Deactivate existing FieldTaskGroups that are not in the new task groups list and not
      // already processed
      if (!isFieldInactive) {
        List<FieldTaskGroup> existingFieldTaskGroups =
            fieldTaskGroupRepository.findByFieldId(fieldEntity.getId());

        existingFieldTaskGroups.forEach(
            existingFieldTaskGroup -> {
              if (fieldEntity.getTaskGroups().stream()
                  .noneMatch(tg -> tg.getId().equals(existingFieldTaskGroup.getTaskGroupId()))) {
                existingFieldTaskGroup.setFiledTaskGroupStatus(Status.INACTIVE);
                fieldTaskGroupRepository.save(existingFieldTaskGroup);
              }
            });
      }
    }
  }

  private void extractTaskGroups(Row row, Map<String, Integer> columnNameToIndex) {
    Long taskGroupId =
        getCellValue(row.getCell(columnNameToIndex.get(AppConstants.TASK_GROUP_ID)), Long.class);
    if (taskGroupId != null) {
      Optional<TaskGroup> taskGroupOpt = taskGroupRepository.findById(taskGroupId);
      if (taskGroupOpt.isPresent()) {
        if (fieldEntity.getTaskGroups() == null) {
          fieldEntity.setTaskGroups(new ArrayList<>());
        }
        fieldEntity.getTaskGroups().add(taskGroupOpt.get());
      }
    }
  }

  private void deactivateAssociatedFieldTaskGroups(Long fieldId) {
    List<FieldTaskGroup> fieldTaskGroups = fieldTaskGroupRepository.findByFieldId(fieldId);
    fieldTaskGroups.forEach(
        ftg -> {
          ftg.setFiledTaskGroupStatus(Status.INACTIVE);
          fieldTaskGroupRepository.save(ftg);
        });
    log.info("Deactivated all FieldTaskGroups associated with Field ID: {}", fieldId);
  }
}
