package com.sunsum.service.impl;

import com.sunsum.constants.AppConstants;
import com.sunsum.constants.Status;
import com.sunsum.constants.UserRole;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.FarmHolding;
import com.sunsum.model.dto.FieldBasicInfo;
import com.sunsum.model.dto.FieldDetails;
import com.sunsum.model.dto.FieldRequest;
import com.sunsum.model.dto.FieldResponse;
import com.sunsum.model.dto.FieldTitle;
import com.sunsum.model.dto.FieldUpdateRequest;
import com.sunsum.model.dto.FieldsResponse;
import com.sunsum.model.dto.UserDetails;
import com.sunsum.model.entity.Field;
import com.sunsum.model.entity.Organization;
import com.sunsum.repository.FieldRepository;
import com.sunsum.repository.OrganisationRepository;
import com.sunsum.service.FieldService;
import com.sunsum.service.S3Service;
import com.sunsum.util.CommonUtils;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.geo.Point;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.SerializationUtils;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@Service
@RequiredArgsConstructor
public class FieldServiceImpl implements FieldService {

  public static final String SIZE_PARAM = "?size=";

  @Value(value = "${cloud.aws.s3.cloud-front.url}")
  private String cloudFrontDomainUrl;

  private final FieldRepository fieldRepository;
  private final OrganisationRepository farmRepository;
  private final S3Service s3Service;
  private final CommonUtils commonUtils;

  @Transactional
  @Override
  public ResponseEntity<String> createField(FieldRequest fieldRequest) {

    try {
      Field field = new Field();
      List<MultipartFile> files =
          fieldRequest.getFiles() != null ? fieldRequest.getFiles() : new ArrayList<>();
      prepareField(fieldRequest, files, field);
      fieldRepository.save(field);
      files.forEach(it -> s3Service.uploadObject(it, field.getTitle()));
      return new ResponseEntity<>(
          "Field with title %s created successfully".formatted(field.getTitle()),
          HttpStatus.CREATED);
    } catch (Exception e) {
      log.error(
          "Error occurred while creating new field due to {} {}", e.getMessage(), e.getCause());
      throw new BusinessRuleException(
          "Error occurred while creating new field", HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Transactional
  @Override
  public ResponseEntity<String> updateField(FieldUpdateRequest fieldRequest, String id) {
    try {
      Field field =
          fieldRepository
              .findById(Long.parseLong(id))
              .orElseThrow(
                  () ->
                      new BusinessRuleException("Field with does not exist", HttpStatus.NOT_FOUND));
      List<MultipartFile> files =
          fieldRequest.getFiles() != null ? fieldRequest.getFiles() : new ArrayList<>();
      String[] existingPhotoPath = field.getPhotoPath();
      prepareField(fieldRequest, files, field);
      fieldRepository.save(field);
      updateImageInS3(fieldRequest, existingPhotoPath, files);
      return new ResponseEntity<>("Field updated successfully", HttpStatus.OK);
    } catch (Exception e) {
      log.error(
          "Error occurred while updating new field due to {} {}", e.getMessage(), e.getCause());
      throw new BusinessRuleException(
          "Error occurred while updating new field", HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  private void updateImageInS3(
      FieldUpdateRequest fieldRequest, String[] existingPhotoPath, List<MultipartFile> files) {
    List<String> updatedPath =
        fieldRequest.getPhotoPath() != null ? fieldRequest.getPhotoPath() : new ArrayList<>();
    deleteImage(existingPhotoPath, updatedPath);
    files.forEach(it -> s3Service.uploadObject(it, fieldRequest.getTitle()));
  }

  public ResponseEntity<FieldsResponse> getFields(String farmHoldingId) {
    if (farmHoldingId != null) {
      List<FieldTitle> fields = fieldRepository.getFields(Long.parseLong(farmHoldingId));
      Pageable p = PageRequest.of(10,10, Sort.by("title"));
      Page<Field> f = fieldRepository.findAll(p);
      List<FieldBasicInfo> fieldBasicInfos =
          fields.stream()
              .distinct()
              .map(
                  it ->
                      new FieldBasicInfo(
                          it.getId(),
                          it.getTitle(),
                          it.getGps() != null,
                          (Point) SerializationUtils.deserialize(it.getGps())))
              .sorted(getJapaneseTitleComparator())
              .toList();
      FieldsResponse fieldsResponse = new FieldsResponse(fieldBasicInfos);
      return ResponseEntity.ok(fieldsResponse);
    } else {
      throw new BusinessRuleException(
          "Farm holding id should not be empty", HttpStatus.BAD_REQUEST);
    }
  }

  public ResponseEntity<FieldResponse> getField(String id) {
    FieldDetails fieldDetails =
        fieldRepository
            .getFieldDetails(Long.parseLong(id))
            .orElseThrow(
                () ->
                    new BusinessRuleException(
                        "Field with id %s does not exist".formatted(id), HttpStatus.NOT_FOUND));
    FieldResponse fieldResponse = mapToFieldResponse(fieldDetails);
    return ResponseEntity.ok(fieldResponse);
  }

  private FieldResponse mapToFieldResponse(FieldDetails field) {
    FieldResponse fieldResponse = new FieldResponse();
    fieldResponse.setTitle(field.getTitle());
    fieldResponse.setAcreage(field.getAcreage());
    fieldResponse.setGpsCoordinates(
        (Point) SerializationUtils.deserialize(field.getGpsCoordinates()));
    fieldResponse.setZipCode(field.getZipCode());
    fieldResponse.setMemo1(field.getMemo1());
    fieldResponse.setPhotoPath(field.getPhotoPath());
    return fieldResponse;
  }

  public boolean hasUserPermissionForField(Long id) {
    UserDetails userDetails = commonUtils.getCurrentLoggedInUserDetails();
    Long userId = userDetails.getId();
    List<FarmHolding> userFarmHoldings;
    if (userDetails.hasHighestRole(UserRole.ROLE_PROJECT_ADMIN)) {
      userFarmHoldings = farmRepository.findByProjectAdmin(userId);
    } else if (userDetails.hasHighestRole(UserRole.ROLE_FIELD_SUPPORTER)) {
      userFarmHoldings = farmRepository.findByFieldSupporter(userId);
    } else {
      userFarmHoldings = farmRepository.findByFieldManager(userId);
    }
    List<Long> farmHoldingIds = fieldRepository.findFarmHoldingIdByFieldId(id);
    Set<Long> farmHoldingIdSet = new HashSet<>(farmHoldingIds);

    return userFarmHoldings.stream().map(FarmHolding::getId).anyMatch(farmHoldingIdSet::contains);
  }

  /*
   * This method will build the new field object from FieldRequest object
   * */
  private void prepareField(FieldRequest fieldRequest, List<MultipartFile> files, Field field) {

    field.setTitle(fieldRequest.getTitle());
    field.setAcreage(fieldRequest.getAcreage());
    field.setZipCode(fieldRequest.getZipCode());
    field.setNote(fieldRequest.getMemo1());
    field.setStatus(Status.ACTIVE);
    String[] coordinates = fieldRequest.getGpsCoordinates().split(" ");
    Point gpsCoordinate =
        new Point(Double.parseDouble(coordinates[0]), Double.parseDouble(coordinates[1]));
    final String basePath =
        cloudFrontDomainUrl + AppConstants.FILE_PATH_SEPARATOR + fieldRequest.getTitle() + AppConstants.FILE_PATH_SEPARATOR;
    String[] paths =
        files.stream()
            .map(it -> basePath + it.getOriginalFilename() + SIZE_PARAM + it.getSize())
            .toArray(String[]::new);
    field.setGpsCoordinates(gpsCoordinate);
    field.setPhotoPath(paths);
    addFarmHolding(fieldRequest.getFarmHoldingId(), field);
  }

  /*
   * This method will build the existing field object from FieldUpdateRequest object
   * */
  private void prepareField(
      FieldUpdateRequest fieldRequest, List<MultipartFile> files, Field field) {

    field.setTitle(fieldRequest.getTitle());
    field.setAcreage(fieldRequest.getAcreage());
    field.setZipCode(fieldRequest.getZipCode());
    field.setNote(fieldRequest.getMemo1());
    field.setStatus(Status.ACTIVE);
    String[] coordinates = fieldRequest.getGpsCoordinates().split(" ");
    Point gpsCoordinate =
        new Point(Double.parseDouble(coordinates[0]), Double.parseDouble(coordinates[1]));

    List<String> updatedPaths =
        fieldRequest.getPhotoPath() != null ? fieldRequest.getPhotoPath() : new ArrayList<>();
    final String basePath =
        cloudFrontDomainUrl + AppConstants.FILE_PATH_SEPARATOR + fieldRequest.getTitle() + AppConstants.FILE_PATH_SEPARATOR;
    List<String> paths =
        files.stream()
            .map(it -> basePath + it.getOriginalFilename() + SIZE_PARAM + it.getSize())
            .toList();
    updatedPaths.addAll(paths);

    field.setGpsCoordinates(gpsCoordinate);
    field.setPhotoPath(updatedPaths.toArray(new String[0]));
  }

  /*
   * This method compares the existing photo paths from the field to the updated photoPath from the request body,
   * and if any existing path is not available in the updated path, it will remove those photo paths from S3.
   * */
  private void deleteImage(String[] existingPath, List<String> updatedPath) {
    try {
      Set<String> paths = Arrays.stream(existingPath).collect(Collectors.toSet());
      paths.removeAll(updatedPath);
      final int index = (cloudFrontDomainUrl + AppConstants.FILE_PATH_SEPARATOR).length();
      paths.forEach(it -> s3Service.delete(it.substring(index).split("\\" + SIZE_PARAM)[0]));
    } catch (Exception e) {
      log.error("error occurred while deleting image from S3");
    }
  }

  private void addFarmHolding(Long farmHoldingId, Field field) {
    Organization farmHolding =
        farmRepository
            .findById(farmHoldingId)
            .orElseThrow(() -> new RuntimeException("Invalid farm holding id provided"));
    field.setFarmHolding(farmHolding);
    farmHolding.getFields().add(field);
  }

  private static Comparator<FieldBasicInfo> getJapaneseTitleComparator() {
    Collator collator = Collator.getInstance(Locale.JAPAN);
    return Comparator.comparing(FieldBasicInfo::title, collator);
  }
}
