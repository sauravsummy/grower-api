package com.sunsum.service;

import java.io.ByteArrayInputStream;

public interface DownloadService {

  ByteArrayInputStream download(String category);
}
