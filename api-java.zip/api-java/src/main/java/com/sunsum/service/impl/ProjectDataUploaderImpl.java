package com.sunsum.service.impl;

import com.sunsum.constants.AppConstants;
import com.sunsum.constants.Status;
import com.sunsum.repository.ProjectRepository;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.exception.BulkUploadException;
import com.sunsum.model.dto.RowIngestionResult;
import com.sunsum.model.entity.IngestionStatus;
import com.sunsum.model.entity.Project;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.service.DataUpload;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

/** The class is to read the project data from the XLSX file with sheet name as project. */
@Service("projectUploader")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Slf4j
public class ProjectDataUploaderImpl implements DataUpload {

  private final ProjectRepository projectRepository;

  private final UserProfileRepository userProfileRepository;

  private Project projectEntity;

  @Autowired
  public ProjectDataUploaderImpl(
      ProjectRepository projectRepository, UserProfileRepository userProfileRepository) {
    this.projectRepository = projectRepository;
    this.userProfileRepository = userProfileRepository;
  }

  /**
   * The method to transform the Excel file row in to a Project entity object.
   *
   * @param row the Excel row
   * @param columnNameToIndex it holds the column name, it's index in the Excel sheet
   * @return DataUpload
   */
  @Override
  public DataUpload createFromRow(Row row, Map<String, Integer> columnNameToIndex) {
    projectEntity = new Project();
    String title =
        getCellValue(row.getCell(columnNameToIndex.get(AppConstants.TITLE)), String.class);
    String area = getCellValue(row.getCell(columnNameToIndex.get(AppConstants.AREA)), String.class);
    Integer year =
        getCellValue(row.getCell(columnNameToIndex.get(AppConstants.YEAR)), Integer.class);
    try {
      if (columnNameToIndex.get(AppConstants.ID) != null) {
        Long id = getCellValue(row.getCell(columnNameToIndex.get(AppConstants.ID)), Long.class);
        if (id != null) {
          projectEntity.setId(id);
        }
      }

      projectEntity.setTitle(title);
      projectEntity.setArea(area);
      projectEntity.setYear(year);

      String ownerEmail =
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.OWNER)), String.class);
      Optional<UserProfile> userProfile = userProfileRepository.findByEmail(ownerEmail);
      userProfile.ifPresent(profile -> projectEntity.setOwner(profile));
      String status =
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.STATUS)), String.class);
      status = Objects.isNull(status) ? AppConstants.ACTIVE : status;
      projectEntity.setStatus(Status.fromString(status));
      projectEntity.setMemo1(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_1)), String.class));
      projectEntity.setMemo2(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_2)), String.class));
      projectEntity.setMemo3(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_3)), String.class));
      projectEntity.setMemo4(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_4)), String.class));
      projectEntity.setMemo5(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_5)), String.class));
    } catch (Exception e) {
      log.error(
          "Exception occurred while creating a project entity from the excel row for Title={}, Area ={}, Year ={}",
          title,
          area,
          year,
          e);
      throw new BulkUploadException(
          "Exception occurred while creating a project entity from the excel row", e);
    }

    return this;
  }

  /**
   * Saves each entity object to database.
   *
   * @return RowIngestionResult
   */
  @Override
  public RowIngestionResult dataInjection(int rowNum) {
    IngestionStatus ingestionStatus;
    try {
      ingestionStatus =
          projectEntity.getId() == null ? IngestionStatus.INSERTED : IngestionStatus.UPDATED;
      projectRepository.save(projectEntity);

    } catch (Exception e) {
      log.error(
          "Exception Occurred while inserting project title={} , area={} and year={}",
          projectEntity.getTitle(),
          projectEntity.getArea(),
          projectEntity.getYear(),
          e);
      throw new BulkUploadException("Exception Occurred while saving the project data", e);
    }
    return RowIngestionResult.builder().rowNumber(rowNum).status(ingestionStatus).build();
  }
}
