package com.sunsum.service;

import com.sunsum.model.dto.PushNotificationReqDto;
import com.sunsum.model.dto.PushNotificationRespDto;
import org.springframework.stereotype.Service;

@Service
public interface FirebaseService {
  PushNotificationRespDto sendNotification(PushNotificationReqDto notificationReqDto);
}
