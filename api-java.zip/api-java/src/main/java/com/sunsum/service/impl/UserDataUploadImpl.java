package com.sunsum.service.impl;

import com.sunsum.constants.AppConstants;
import com.sunsum.constants.UserRole;
import com.sunsum.repository.OrganisationRepository;
import com.sunsum.repository.RoleRepository;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.exception.BulkUploadException;
import com.sunsum.model.dto.RowIngestionResult;
import com.sunsum.model.entity.IngestionStatus;
import com.sunsum.model.entity.Organization;
import com.sunsum.model.entity.Role;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.service.DataUpload;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import liquibase.repackaged.org.apache.commons.lang3.StringUtils;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

/**
 * The class is to read the user data from the XLSX file with sheet name as user and save to the
 * user and related tables.
 */
@Service("userUploader")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Slf4j
@Getter
@Setter
public class UserDataUploadImpl implements DataUpload {

  private UserProfile userProfile;

  private final UserProfileRepository userProfileRepository;

  private final OrganisationRepository organisationRepository;

  private final RoleRepository roleRepository;

  @Autowired
  public UserDataUploadImpl(
      UserProfileRepository userProfileRepository,
      OrganisationRepository organisationRepository,
      RoleRepository roleRepository) {
    this.userProfileRepository = userProfileRepository;
    this.organisationRepository = organisationRepository;
    this.roleRepository = roleRepository;
  }

  /**
   * The method to transform the Excel file row in to a user entity object.
   *
   * @param row the Excel row
   * @param columnNameToIndex it holds the column name, it's index in the Excel sheet
   * @return DataUpload
   */
  @Override
  public DataUpload createFromRow(Row row, Map<String, Integer> columnNameToIndex) {
    userProfile = new UserProfile();
    String name = getStringCell(row, columnNameToIndex.get(AppConstants.NAME));
    String email = getStringCell(row, columnNameToIndex.get(AppConstants.EMAIL_ID));
    Long phone = getCellValue(row.getCell(columnNameToIndex.get(AppConstants.PHONE)), Long.class);

    try {
      if (columnNameToIndex.get(AppConstants.ID) != null) {
        Long id = getCellValue(row.getCell(columnNameToIndex.get(AppConstants.ID)), Long.class);
        if (id != null) {
          userProfile.setId(id);
        }
      }
      userProfile.setName(name);
      Boolean isActive =
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.IS_ACTIVE)), Boolean.class);
      // Default value for the (Is Active) column is TRUE.
      userProfile.setIsActive(Objects.isNull(isActive) ? Boolean.TRUE : isActive);

      String role = getStringCell(row, columnNameToIndex.get(AppConstants.ROLE));
      Optional<Role> dbRole = roleRepository.findByName(UserRole.valueOf(role));
      Set<Role> roleSet = new HashSet<>();
      dbRole.ifPresent(roleSet::add);
      userProfile.setRoles(roleSet);

      userProfile.setEmail(StringUtils.isBlank(email) ? email : email.trim().toLowerCase());
      userProfile.setPhoneNo(phone);

      String reportingTo = getStringCell(row, columnNameToIndex.get(AppConstants.REPORTING_TO));
      if (null != reportingTo && !reportingTo.contains(AppConstants.NULL_STRING)) {
        Optional<UserProfile> userProfileOpt = userProfileRepository.findByEmail(reportingTo);
        userProfileOpt.ifPresent(value -> userProfile.setReportingTo(value));
      }

      Long orgId =
          getCellValue(
              row.getCell(columnNameToIndex.get(AppConstants.ORGANISATION_ID)), Long.class);
      Optional<Organization> organization = organisationRepository.findById(orgId);
      organization.ifPresent(value -> userProfile.setOrganization(value));

      userProfile.setMemo1(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_1)), String.class));
      userProfile.setMemo2(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_2)), String.class));
      userProfile.setMemo3(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_3)), String.class));
      userProfile.setMemo4(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_4)), String.class));
      userProfile.setMemo5(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_5)), String.class));
    } catch (Exception e) {
      log.error(
          "Exception occurred while transforming the Excel row to user entity Name={}, Email ={}, Phone ={}",
          name,
          email,
          phone,
          e);
      throw new BulkUploadException(
          "Exception occurred while transforming the Excel row to user entity", e);
    }

    return this;
  }

  /**
   * Saves each user row to database.
   *
   * @return RowIngestionResult
   */
  @Override
  public RowIngestionResult dataInjection(int rowNum) {
    IngestionStatus ingestionStatus = null;
    try {
      ingestionStatus =
          userProfile.getId() == null ? IngestionStatus.INSERTED : IngestionStatus.UPDATED;
      userProfileRepository.save(userProfile);
    } catch (Exception e) {
      log.error(
          "Exception Occurred while saving user data Name ={} , Email ={} and Phone={}",
          userProfile.getName(),
          userProfile.getEmail(),
          userProfile.getPhoneNo(),
          e);
      throw new BulkUploadException("Exception Occurred while saving the User data", e);
    }
    return RowIngestionResult.builder().rowNumber(rowNum).status(ingestionStatus).build();
  }
}
