package com.sunsum.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public interface S3Service {

  void uploadObject(MultipartFile file, String key);

  void delete(String fileName);
}
