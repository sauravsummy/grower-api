package com.sunsum.service.impl;

import com.sunsum.exception.BusinessRuleException;
import com.sunsum.repository.UserFcmTokenRepository;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.model.dto.FcmTokenRequest;
import com.sunsum.model.dto.UserFcmTokenDto;
import com.sunsum.model.entity.UserFcmToken;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.service.FcmTokenService;
import java.util.List;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@AllArgsConstructor
public class FcmTokenServiceImpl implements FcmTokenService {

  private final UserFcmTokenRepository userNotificationRepository;
  private final UserProfileRepository userProfileRepository;

  @Override
  public List<UserFcmTokenDto> getActiveUserFcmTokensByUserId(Long userId) {
    if (userId == null) {
      log.error("User ID is null in getActiveUserFcmTokensByUserId");
      return List.of(); // or throw an IllegalArgumentException
    }

    UserProfile user =
        userProfileRepository
            .findById(userId)
            .orElseThrow(
                () ->
                    new BusinessRuleException(
                        "User not found with ID: " + userId, HttpStatus.NOT_FOUND));

    List<UserFcmToken> notifications = userNotificationRepository.findByUserAndIsActive(user, true);

    return notifications.stream()
        .map(notification -> new UserFcmTokenDto(userId, notification.getToken()))
        .toList();
  }

  @Override
  public void saveFcmToken(FcmTokenRequest request) {
    log.info(
        "Attempting to save or update FCM token for user ID: {} and device type: {}",
        request.getUserId(),
        request.getDeviceType());

    UserProfile user =
        userProfileRepository
            .findById(request.getUserId())
            .orElseThrow(
                () -> {
                  log.error("User not found with ID: {}", request.getUserId());
                  return new RuntimeException("User not found");
                });

    // Check if there's an existing token for this user and device type
    Optional<UserFcmToken> existingNotificationOpt =
        userNotificationRepository.findByUserAndDeviceType(user, request.getDeviceType());

    UserFcmToken notification = existingNotificationOpt.orElseGet(UserFcmToken::new);
    notification.setUser(user);
    notification.setToken(request.getFcmToken());
    notification.setDeviceType(request.getDeviceType());
    notification.setActive(true);

    userNotificationRepository.save(notification);
    log.info(
        "FCM token for device type '{}' saved/updated for user: {}",
        request.getDeviceType(),
        user.getId());
  }
}
