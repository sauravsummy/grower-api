package com.sunsum.service;

import com.sunsum.model.dto.FieldRequest;
import com.sunsum.model.dto.FieldResponse;
import com.sunsum.model.dto.FieldUpdateRequest;
import com.sunsum.model.dto.FieldsResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface FieldService {

  ResponseEntity<String> createField(FieldRequest fieldRequest);

  ResponseEntity<FieldsResponse> getFields(String farmHoldingId);

  public ResponseEntity<FieldResponse> getField(String id);

  public ResponseEntity<String> updateField(FieldUpdateRequest fieldRequest, String id);

  public boolean hasUserPermissionForField(Long id);
}
