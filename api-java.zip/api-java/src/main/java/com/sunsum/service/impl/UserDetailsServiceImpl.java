package com.sunsum.service.impl;

import com.sunsum.constants.AppConstants;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.entity.Role;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.UserProfileRepository;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {

  private final UserProfileRepository userDetailsRepository;

  @Override
  public UserDetails loadUserByUsername(String id) throws UsernameNotFoundException {
    UserProfile userProfile =
        userDetailsRepository
            .findById(Long.valueOf(id))
            .orElseThrow(() -> new BusinessRuleException("User not found", HttpStatus.NOT_FOUND));
    return new User(
        userProfile.getId().toString(), AppConstants.NO_PASSWORD, getAuthorities(userProfile.getRoles()));
  }

  private Collection<? extends GrantedAuthority> getAuthorities(Collection<Role> roles) {
    List<SimpleGrantedAuthority> grantedAuthorities = new ArrayList<>();
    roles.forEach(
        role -> grantedAuthorities.add(new SimpleGrantedAuthority(role.getName().name())));
    return grantedAuthorities;
  }
}
