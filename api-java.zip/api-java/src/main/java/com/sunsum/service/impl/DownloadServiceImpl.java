package com.sunsum.service.impl;

import com.sunsum.constants.AppConstants;
import com.sunsum.config.MasterDataDownloadProperties;
import com.sunsum.config.MasterDataProperties;
import com.sunsum.service.DataDownload;
import com.sunsum.service.DownloadService;
import java.io.ByteArrayInputStream;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * The Download service calls the respective Downloader by passing the columns and mandatory
 * columns.
 */
@Slf4j
@Service
public class DownloadServiceImpl implements DownloadService {

  private final Map<String, DataDownload> dataDownloadMap;
  private final MasterDataDownloadProperties masterDataDownloadProperties;
  private final MasterDataProperties masterDataProperties;

  @Autowired
  public DownloadServiceImpl(
      Map<String, DataDownload> dataUploadMap,
      MasterDataDownloadProperties masterDataDownloadProperties,
      MasterDataProperties masterDataProperties) {
    this.dataDownloadMap = dataUploadMap;
    this.masterDataDownloadProperties = masterDataDownloadProperties;
    this.masterDataProperties = masterDataProperties;
  }

  @Override
  public ByteArrayInputStream download(String category) {
    DataDownload dataDownload = dataDownloadMap.get(category + AppConstants.DOWNLOADER);
    dataDownload = dataDownload.fetch();
    return dataDownload.prepareSheet(
        masterDataDownloadProperties.getFileTypes().get(category),
        masterDataProperties.getFileTypes().get(category));
  }
}
