package com.sunsum.service.impl;

import com.google.gson.Gson;
import com.sunsum.constants.AppConstants;
import com.sunsum.constants.ChannelType;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.repository.OtpCountRepository;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.model.MessageBirdProperty;
import com.sunsum.model.dto.OtpVerifyRequest;
import com.sunsum.model.dto.SendOtpResponse;
import com.sunsum.model.entity.OTPCountTracker;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.service.OtpService;
import com.sunsum.util.DateUtil;
import com.sunsum.util.RisocareCommonUtils;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
@RequiredArgsConstructor
public class OtpServiceImpl implements OtpService {

  public static final String DUMMY_ACCOUNT_EMAIL = "dummy@dummyaccount.com";
  public static final String DUMMY_ACCOUNT_PHONE_NUMBER = "09999999999";

  @Value("${max_otp_limit:5}")
  private int maxOtpLimit;

  private final MessageBirdProperty messageBirdProperty;

  private final OtpCountRepository otpCountRepo;

  private final RestTemplate restTemplate;

  private final UserProfileRepository userProfileRepository;

  @Override
  public ResponseEntity<String> sendOtpToMobile(String mobileNo) {

    mobileNo = RisocareCommonUtils.formatMobileNumber(mobileNo);

    if (DUMMY_ACCOUNT_PHONE_NUMBER.equals(mobileNo.trim())) {
      return sentOtpResponse();
    }
    validateUser(mobileNo.trim(), ChannelType.PHONE_NUMBER);
    checkOTPLimit(mobileNo);
    ResponseEntity<String> otpApiResponse =
        otpApiCall(
            Map.of("phone", mobileNo.trim(), "hash-key", messageBirdProperty.getHashKey()),
            messageBirdProperty.getSendOtpMobileUrl());
    if (otpApiResponse.getStatusCode() == HttpStatus.NO_CONTENT) {
      return sentOtpResponse();
    } else {
      log.info("OTP failed for mobile no. : {}", mobileNo);
      return RisocareCommonUtils.buildErrorResponse(
          HttpStatus.INTERNAL_SERVER_ERROR, AppConstants.OTP_FAILED_MSG);
    }
  }

  @Override
  public ResponseEntity<String> sendOtpToEmail(String emailId) {
    if (DUMMY_ACCOUNT_EMAIL.equals(emailId)) {
      return sentOtpResponse();
    }
    validateUser(emailId.trim(), ChannelType.EMAIL_ID);
    validateEmailId(emailId.trim());
    checkOTPLimit(emailId.toLowerCase().trim());
    ResponseEntity<String> otpApiResponse =
        otpApiCall(
            Map.of("email", emailId.toLowerCase().trim()),
            messageBirdProperty.getSendOtpEmailUrl());
    if (otpApiResponse.getStatusCode() == HttpStatus.NO_CONTENT) {
      return sentOtpResponse();
    } else {
      log.info("OTP failed for email id : {}", emailId);
      return RisocareCommonUtils.buildErrorResponse(
          HttpStatus.INTERNAL_SERVER_ERROR, AppConstants.OTP_FAILED_MSG);
    }
  }

  @Override
  public boolean isValidOtp(OtpVerifyRequest otpVerifyRequest) {
    try {

      if (isDummyAccount(otpVerifyRequest)) {
        return true;
      }

      Map<String, String> requestBody = getRequestBody(otpVerifyRequest);
      String verifyUrl = getVerifyUrl(otpVerifyRequest);
      ResponseEntity<String> otpApiResponse = otpApiCall(requestBody, verifyUrl);
      return otpApiResponse.getStatusCode().equals(HttpStatus.OK);
    } catch (HttpClientErrorException e) {
      throw new BusinessRuleException(
          e.getResponseBodyAsString(), HttpStatus.INTERNAL_SERVER_ERROR);
    } catch (Exception e) {
      log.error("Getting error while calling messagebird Api");
      throw e;
    }
  }

  private boolean isDummyAccount(OtpVerifyRequest otpVerifyRequest) {
    return (DUMMY_ACCOUNT_EMAIL.equals(otpVerifyRequest.getRecipientId())
        || DUMMY_ACCOUNT_PHONE_NUMBER.equals(otpVerifyRequest.getRecipientId()));
  }

  private void validateUser(String recipientId, ChannelType channelType) {
    Optional<UserProfile> userProfile =
        ChannelType.EMAIL_ID.equals(channelType)
            ? userProfileRepository.findByEmailIgnoreCase(recipientId)
            : userProfileRepository.findByPhoneNo(Long.valueOf(recipientId));
    if (!userProfile.isPresent()) {
      throw new BusinessRuleException("Unknown User", HttpStatus.BAD_REQUEST);
    }
    if (!Boolean.TRUE.equals(userProfile.get().getIsActive())) {
      throw new BusinessRuleException("Inactive User", HttpStatus.BAD_REQUEST);
    }
  }

  private String getVerifyUrl(OtpVerifyRequest otpVerifyRequest) {
    return otpVerifyRequest.getChannelType().equals(ChannelType.EMAIL_ID)
        ? messageBirdProperty.getVerifyOtpEmailUrl()
        : messageBirdProperty.getVerifyOtpMobileUrl();
  }

  private Map<String, String> getRequestBody(OtpVerifyRequest otpVerifyRequest) {
    return Map.of(
        "identifier",
        otpVerifyRequest.getRecipientId().trim().toLowerCase()
            + "_"
            + otpVerifyRequest.getOtp().trim());
  }

  private ResponseEntity<String> sentOtpResponse() {
    SendOtpResponse sendOtpResponse = new SendOtpResponse();
    Gson gson = new Gson();
    sendOtpResponse.setMessage(AppConstants.OTP_SENT_MSG);
    return new ResponseEntity<>(gson.toJson(sendOtpResponse), HttpStatus.OK);
  }

  private ResponseEntity<String> otpApiCall(Map<String, String> requestBody, String url) {
    try {
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      HttpEntity<Map<String, String>> httpEntity = new HttpEntity<>(requestBody, headers);
      return restTemplate.postForEntity(url, httpEntity, String.class);
    } catch (HttpClientErrorException e) {
      return RisocareCommonUtils.buildErrorResponse(e.getStatusCode(), e.getResponseBodyAsString());

    } catch (Exception e) {
      log.error("Getting error while calling messagebird Api");
      throw e;
    }
  }

  private void validateEmailId(String email) {
    if (!RisocareCommonUtils.isValidEmailId(email)) {
      log.error("Invalid email id provided");
      throw new BusinessRuleException("Invalid Email Id", HttpStatus.BAD_REQUEST);
    }
  }

  private void checkOTPLimit(String recipientId) {
    OTPCountTracker otpCount;
    Optional<OTPCountTracker> opOTPCount = otpCountRepo.findByRecipientId(recipientId);
    if (opOTPCount.isPresent()) {
      otpCount = opOTPCount.get();
      int noOfOTP = otpCount.getOtpCount();

      LocalDate today = DateUtil.currentLocalDate();
      LocalDate lastOtpDate = DateUtil.localDateFromTimestamp(otpCount.getLastOtpTimestamp());

      if (today.isEqual(lastOtpDate)) {
        if (noOfOTP >= maxOtpLimit) {
          log.error("OTP max limit reached for mobile no : {}", recipientId);
          throw new BusinessRuleException("OTP_ERROR", HttpStatus.BAD_REQUEST);
        } else {
          otpCount.setOtpCount(++noOfOTP);
        }
      } else {
        otpCount.setOtpCount(1);
      }

    } else {
      otpCount = new OTPCountTracker();
      otpCount.setRecipientId(recipientId);
      otpCount.setOtpCount(1);
    }
    otpCount.setLastOtpTimestamp(new Timestamp(System.currentTimeMillis()));
    otpCountRepo.save(otpCount);
  }
}
