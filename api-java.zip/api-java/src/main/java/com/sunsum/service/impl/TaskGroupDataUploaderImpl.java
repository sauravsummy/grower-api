package com.sunsum.service.impl;

import com.sunsum.constants.AppConstants;
import com.sunsum.constants.Status;
import com.sunsum.repository.ProjectRepository;
import com.sunsum.repository.TaskGroupRepository;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.exception.BulkUploadException;
import com.sunsum.model.dto.RowIngestionResult;
import com.sunsum.model.entity.IngestionStatus;
import com.sunsum.model.entity.Project;
import com.sunsum.model.entity.TaskGroup;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.service.DataUpload;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

/** The class is to upload the taskgroup data from the XLSX file with sheet name as taskgroup */
@Service("taskgroupUploader")
@Slf4j
@Getter
@Setter
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class TaskGroupDataUploaderImpl implements DataUpload {

  private TaskGroup taskGroupEntity;

  private final ProjectRepository projectRepository;
  private final UserProfileRepository userProfileRepository;
  private final TaskGroupRepository taskGroupRepository;

  @Autowired
  public TaskGroupDataUploaderImpl(
      ProjectRepository projectRepository,
      UserProfileRepository userProfileRepository,
      TaskGroupRepository taskGroupRepository) {
    this.projectRepository = projectRepository;
    this.userProfileRepository = userProfileRepository;
    this.taskGroupRepository = taskGroupRepository;
  }

  /**
   * The method to transform the Excel file row in to a Task Group (TG) entity object.
   *
   * @param row the Excel row
   * @param columnNameToIndex it holds the column name, it's index in the Excel sheet
   * @return DataUpload
   */
  @Override
  public DataUpload createFromRow(Row row, Map<String, Integer> columnNameToIndex) {

    taskGroupEntity = new TaskGroup();
    String title =
        getCellValue(row.getCell(columnNameToIndex.get(AppConstants.TITLE)), String.class);
    Long projectId =
        getCellValue(row.getCell(columnNameToIndex.get(AppConstants.PROJECT_ID)), Long.class);

    try {
      if (columnNameToIndex.get(AppConstants.ID) != null) {
        Long id = getCellValue(row.getCell(columnNameToIndex.get(AppConstants.ID)), Long.class);
        if (id != null) {
          taskGroupEntity.setId(id);
        }
      }
      taskGroupEntity.setTitle(title);
      taskGroupEntity.setTaskGroupMemo(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO)), String.class));
      String ownerEmail =
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.OWNER)), String.class);

      Optional<UserProfile> userProfile = userProfileRepository.findByEmail(ownerEmail);
      userProfile.ifPresent(profile -> taskGroupEntity.setTaskGroupOwner(profile));

      Optional<Project> projectOptional = projectRepository.findById(projectId);
      projectOptional.ifPresent(project -> taskGroupEntity.setProject(project));

      taskGroupEntity.setOrder(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.ORDER)), Integer.class));

      String status =
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.STATUS)), String.class);
      status = Objects.isNull(status) ? AppConstants.ACTIVE : status;
      taskGroupEntity.setStatus(Status.fromString(status));

      taskGroupEntity.setIsLocked(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.IS_LOCKED)), Boolean.class));
      taskGroupEntity.setMemo1(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_1)), String.class));
      taskGroupEntity.setMemo2(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_2)), String.class));
      taskGroupEntity.setMemo3(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_3)), String.class));
      taskGroupEntity.setMemo4(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_4)), String.class));
      taskGroupEntity.setMemo5(
          getCellValue(row.getCell(columnNameToIndex.get(AppConstants.MEMO_5)), String.class));
      if (Objects.nonNull(taskGroupEntity.getId())) {
        retrieveAndSetFieldDetails(taskGroupEntity);
      }
    } catch (Exception e) {
      log.error(
          "Exception occurred while creating a Task Group entity from the excel row for Title={}, ProjectId ={}",
          title,
          projectId,
          e);
      throw new BulkUploadException(
          "Exception occurred while creating a Task Group entity from the excel row", e);
    }

    return this;
  }

  /**
   * This is to fetch TG details if existing and sets to new Entity before saving so that we won't
   * lose the mapping data in the bridge table.
   *
   * @param taskGroupEntity
   */
  private void retrieveAndSetFieldDetails(TaskGroup taskGroupEntity) {

    Optional<TaskGroup> existingTG = taskGroupRepository.findById(taskGroupEntity.getId());
    existingTG.ifPresent(tg -> taskGroupEntity.setFields(tg.getFields()));
  }

  /**
   * Saves each entity object to database.
   *
   * @return RowIngestionResult
   */
  @Override
  public RowIngestionResult dataInjection(int rowNum) {
    IngestionStatus ingestionStatus = null;
    try {
      ingestionStatus =
          taskGroupEntity.getId() == null ? IngestionStatus.INSERTED : IngestionStatus.UPDATED;
      taskGroupRepository.save(taskGroupEntity);
    } catch (Exception e) {
      log.error(
          "Exception Occurred while inserting Task Group Title={} for project Id={} ",
          taskGroupEntity.getTitle(),
          taskGroupEntity.getProject().getId(),
          e);
      throw new BulkUploadException("Exception Occurred while inserting Task Group ", e);
    }
    return RowIngestionResult.builder().rowNumber(rowNum).status(ingestionStatus).build();
  }
}
