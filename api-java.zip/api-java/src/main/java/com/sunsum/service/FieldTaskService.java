package com.sunsum.service;

import com.sunsum.model.dto.FieldTasksStatus;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public interface FieldTaskService {
  public List<FieldTasksStatus> getAllFieldsTask(Long farmHoldingId);

  public List<FieldTasksStatus> getUpcomingFieldTasks(Long farmHoldingId);
}
