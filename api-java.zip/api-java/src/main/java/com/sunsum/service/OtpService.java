package com.sunsum.service;

import com.sunsum.model.dto.OtpVerifyRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface OtpService {

  ResponseEntity<String> sendOtpToEmail(String emailId);

  ResponseEntity<String> sendOtpToMobile(String mobileNo);

  boolean isValidOtp(OtpVerifyRequest otpVerifyRequest);
}
