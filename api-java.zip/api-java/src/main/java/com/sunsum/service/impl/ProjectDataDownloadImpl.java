package com.sunsum.service.impl;

import com.sunsum.constants.AppConstants;
import com.sunsum.exception.BulkDownloadException;
import com.sunsum.repository.ProjectRepository;
import com.sunsum.model.entity.Project;
import com.sunsum.service.DataDownload;
import com.sunsum.util.ExcelUtils;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

/**
 * Class to create a XLSX file with sheet name as project and writes project table data and return
 * as a byte stream.
 */
@Slf4j
@Service("projectDownloader")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class ProjectDataDownloadImpl implements DataDownload {

  private final ProjectRepository projectRepository;
  private final ExcelUtils excelUtils;
  private List<Project> projects;

  @Autowired
  public ProjectDataDownloadImpl(ProjectRepository projectRepository, ExcelUtils excelUtils) {
    this.projectRepository = projectRepository;
    this.excelUtils = excelUtils;
  }

  /**
   * To get the all the project table data.
   *
   * @return DataDownload
   */
  @Override
  public DataDownload fetch() {
    projects = projectRepository.findAllByOrderByIdAsc();
    return this;
  }

  /**
   * Method to create an Excel workbook and adds a sheet
   *
   * @param columns the list of columns separated by comma
   * @return ByteArrayInputStream
   */
  @Override
  public ByteArrayInputStream prepareSheet(String columns, String mandatoryColumns) {

    try (XSSFWorkbook workbook = new XSSFWorkbook()) {
      XSSFSheet sheet = workbook.createSheet(AppConstants.SHEET_PROJECT);
      excelUtils.writeHeaderRow(columns, mandatoryColumns, workbook, sheet);
      writeDataRows(sheet);
      try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
        workbook.write(outputStream);
        return new ByteArrayInputStream(outputStream.toByteArray());
      }
    } catch (Exception e) {
      log.error("Exception Occurred while downloading the PROJECT data", e);
      throw new BulkDownloadException("Exception has occurred while downloading PROJECT data", e);
    }
  }

  /**
   * Writes project table data to the sheet.
   *
   * @param sheet the Excel sheet
   */
  private void writeDataRows(XSSFSheet sheet) {
    int columnCount;
    // As header row added, rowNo should start from 1
    int rowNo = 1;
    Row row;
    // Creating data rows for each query
    for (Project project : projects) {
      try {
        row = sheet.createRow(rowNo);
        columnCount = 0;
        excelUtils.createCell(row, columnCount++, project.getId(), null);
        excelUtils.createCell(row, columnCount++, project.getTitle(), null);
        excelUtils.createCell(row, columnCount++, project.getArea(), null);
        excelUtils.createCell(row, columnCount++, project.getYear(), null);
        excelUtils.createCell(row, columnCount++, project.getOwner().getEmail(), null);
        excelUtils.createCell(row, columnCount++, project.getStatus().getValue(), null);
        excelUtils.createCell(row, columnCount++, project.getMemo1(), null);
        excelUtils.createCell(row, columnCount++, project.getMemo2(), null);
        excelUtils.createCell(row, columnCount++, project.getMemo3(), null);
        excelUtils.createCell(row, columnCount++, project.getMemo4(), null);
        excelUtils.createCell(row, columnCount, project.getMemo5(), null);
        rowNo++;
      } catch (Exception e) {
        log.error(
            "Exception occurred while preparing excel row in project download for Id={}, Title={}, Area={}, year ={} ",
            project.getId(),
            project.getTitle(),
            project.getArea(),
            project.getYear(),
            e);
      }
    }
  }
}
