package com.sunsum.service.impl;

import com.sunsum.constants.AppConstants;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.repository.UploadTrackerRepository;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.config.MasterDataProperties;
import com.sunsum.constants.ErrorMsgConstants;
import com.sunsum.model.dto.BulkUploadTracker;
import com.sunsum.model.dto.RowIngestionResult;
import com.sunsum.model.dto.SheetIngestionResult;
import com.sunsum.model.entity.IngestionStatus;
import com.sunsum.model.entity.UploadTracker;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.service.DataUpload;
import com.sunsum.service.UploadService;
import com.sunsum.util.CommonUtils;
import com.sunsum.util.UploadValidation;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import liquibase.repackaged.org.apache.commons.lang3.exception.ExceptionUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

/** Class for the bulk upload related actions */
@Slf4j
@Service
public class UploadServiceImpl implements UploadService {

  private final UploadValidation uploadValidation;
  private final MasterDataProperties bulkUploadProperties;
  private final ApplicationContext applicationContext;
  private final UploadTrackerRepository uploadTrackerRepository;
  private final ModelMapper modelMapper;
  private final CommonUtils commonUtils;
  private final UserProfileRepository userProfileRepository;

  @Autowired
  public UploadServiceImpl(
      UploadValidation uploadValidation,
      MasterDataProperties bulkUploadProperties,
      ApplicationContext applicationContext,
      UploadTrackerRepository uploadTrackerRepository,
      ModelMapper modelMapper,
      CommonUtils commonUtils,
      UserProfileRepository userProfileRepository) {
    this.uploadValidation = uploadValidation;
    this.bulkUploadProperties = bulkUploadProperties;
    this.applicationContext = applicationContext;
    this.uploadTrackerRepository = uploadTrackerRepository;
    this.modelMapper = modelMapper;
    this.commonUtils = commonUtils;
    this.userProfileRepository = userProfileRepository;
  }

  @Override
  public SheetIngestionResult bulkInsert(MultipartFile file) {
    Workbook workbook;
    try {
      if (!uploadValidation.checkFileType(file)) {
        throw new BusinessRuleException(
            ErrorMsgConstants.INVALID_FILE_FORMAT, HttpStatus.BAD_REQUEST);
      }
      workbook = WorkbookFactory.create(file.getInputStream());
    } catch (IOException e) {
      log.error("Error while reading the data", e);
      throw new BusinessRuleException(
          ErrorMsgConstants.UNABLE_TO_PROCESS_THE_UPLOADED_FILE, HttpStatus.BAD_REQUEST);
    }
    SheetIngestionResult results;
    Map<String, String> fileTypes = bulkUploadProperties.getFileTypes();
    String sheetName = workbook.getSheetAt(0).getSheetName().trim().toLowerCase();
    if (fileTypes.containsKey(sheetName)
        && !uploadValidation.isSheetEmpty(workbook.getSheetAt(0))) {
      DataUpload dataUpload =
          applicationContext.getBean(sheetName + AppConstants.UPLOADER, DataUpload.class);
      Sheet sheet = workbook.getSheetAt(0);
      List<String> mandatoryHeaders =
          uploadValidation.getMandatoryHeadersForFileType(fileTypes.get(sheetName));
      if (uploadValidation.validateHeaders(mandatoryHeaders, sheet)) {
        sheet = uploadValidation.removeEmptyRows(sheet);
        results = extractAndProcessData(sheet, mandatoryHeaders, dataUpload);
      } else {
        log.debug(
            "Missing the mandatory files in the sheet={} and file={}",
            sheetName,
            file.getOriginalFilename());
        throw new BusinessRuleException(
            ErrorMsgConstants.MANDATORY_COLUMNS_MISSING, HttpStatus.BAD_REQUEST);
      }
    } else {
      log.debug(
          "The Sheet Name is not proper={} or the sheet is empty in file={}",
          sheetName,
          file.getOriginalFilename());
      throw new BusinessRuleException(ErrorMsgConstants.INVALID_SHEET_NAME, HttpStatus.BAD_REQUEST);
    }
    return results;
  }

  private SheetIngestionResult extractAndProcessData(
      Sheet sheet, List<String> mandatoryHeaders, DataUpload dataUpload) {

    Map<String, Integer> columnNameToIndex = columnNameToIndex(sheet);
    List<RowIngestionResult> results = new ArrayList<>();
    SheetIngestionResult finalResult = new SheetIngestionResult();
    int totalRows = sheet.getPhysicalNumberOfRows();
    RowIngestionResult result = null;
    DataUpload toBeInserted = null;
    int skipped = 0;
    int rowNum;
    for (int i = 1; i <= totalRows; i++) {
      Row row = sheet.getRow(i);
      if (row == null) {
        break;
      }
      if (uploadValidation.validateMandatoryData(row, mandatoryHeaders, columnNameToIndex)) {
        rowNum = row.getRowNum();
        try {
          toBeInserted = dataUpload.createFromRow(row, columnNameToIndex);
          result = toBeInserted.dataInjection(rowNum);
        } catch (Exception e) {
          Throwable cause = ExceptionUtils.getRootCause(e);
          String errorMsg = cause != null ? cause.getMessage() : e.getMessage();

          result =
              RowIngestionResult.builder()
                  .rowNumber(rowNum)
                  .status(IngestionStatus.FAILED)
                  .failureReason(errorMsg)
                  .build();
        }
      } else {
        result =
            RowIngestionResult.builder()
                .rowNumber(i)
                .status(IngestionStatus.VALIDATION_FAILED)
                .failureReason("Mandatory data is missing")
                .build();
        skipped++;
      }

      results.add(result);
    }
    finalResult.setRows(results);
    int actualRows = totalRows - 1;
    finalResult.setTotalRecords(actualRows);
    int failed =
        (int)
            results.stream()
                .filter(resultInter -> resultInter.getStatus().equals(IngestionStatus.FAILED))
                .count();
    int totalFailed = failed + skipped;
    finalResult.setFailureCount(totalFailed);
    int success = actualRows - totalFailed;
    finalResult.setSuccessCount(success);
    saveToTracker(sheet, actualRows, failed, skipped, success);
    return finalResult;
  }

  /**
   * After processing the file inserting the metadata of the results.
   *
   * @param sheet
   * @param actualRows
   * @param failed
   * @param skipped
   * @param success
   */
  private void saveToTracker(Sheet sheet, int actualRows, int failed, int skipped, int success) {
    UploadTracker uploadTracker = new UploadTracker();
    uploadTracker.setFileType(sheet.getSheetName().toUpperCase());
    uploadTracker.setTotal(actualRows);
    uploadTracker.setFailed(failed);
    uploadTracker.setSkipped(skipped);
    uploadTracker.setSuccess(success);
    uploadTracker.setCreatedBy(commonUtils.getCurrentLoggedInUserId());
    uploadTracker.setCreatedDate(
        LocalDateTime.now(ZoneId.of(ZoneId.SHORT_IDS.get(AppConstants.JST))));
    uploadTrackerRepository.save(uploadTracker);
  }

  static Map<String, Integer> columnNameToIndex(Sheet sheet) {

    Map<String, Integer> columnNameToIndex = new HashMap<>();
    Row firstRow = sheet.getRow(0);
    short minColumnIndex = firstRow.getFirstCellNum();
    short maxColumnIndex = firstRow.getLastCellNum();
    for (short columnIndex = minColumnIndex; columnIndex < maxColumnIndex; columnIndex++) {

      Cell cell = firstRow.getCell(columnIndex);

      if (Objects.nonNull(cell)) {
        columnNameToIndex.put(cell.getStringCellValue().trim(), cell.getColumnIndex());
      }
    }
    return columnNameToIndex;
  }

  /**
   * To get the info about the last uploaded data for each file type
   *
   * @return List<BulkUploadTracker>
   */
  @Override
  public List<BulkUploadTracker> getUploadTrackerDetails() {

    List<UploadTracker> uploadTrackerList =
        uploadTrackerRepository.findLatestRecordsForEachFileType();

    List<Long> userIdList = uploadTrackerList.stream().map(UploadTracker::getCreatedBy).toList();

    final Map<Long, String> userIdToEmailMap =
        userProfileRepository.findAllById(userIdList).stream()
            .collect(Collectors.toMap(UserProfile::getId, UserProfile::getName));

    final List<String> customOrder =
        List.of("ORGANISATION", "USER", "PROJECT", "TASKGROUP", "FIELD", "TASK");
    return uploadTrackerList.stream()
        .map(
            source -> {
              BulkUploadTracker bulkUploadTracker =
                  modelMapper.map(source, BulkUploadTracker.class);
              bulkUploadTracker.setCreatedBy(
                  userIdToEmailMap.getOrDefault(
                      Long.parseLong(bulkUploadTracker.getCreatedBy()), null));
              return bulkUploadTracker;
            })
        .sorted(
            Comparator.comparingInt(
                uploadTracker -> customOrder.indexOf(uploadTracker.getFileType())))
        .toList();
  }
}
