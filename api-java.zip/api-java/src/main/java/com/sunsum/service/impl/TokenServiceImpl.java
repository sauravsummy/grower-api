package com.sunsum.service.impl;

import com.sunsum.model.entity.Token;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.repository.TokenRepository;
import com.sunsum.util.RisocareCommonUtils;
import com.sunsum.service.TokenService;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class TokenServiceImpl implements TokenService {

  private static final Logger logger = LoggerFactory.getLogger(TokenServiceImpl.class);

  private final TokenRepository tokenRepository;

  public TokenServiceImpl(TokenRepository tokenRepository) {
    this.tokenRepository = tokenRepository;
  }

  @Override
  public boolean logoff(String tokenString) {
    try {
      String hashedToken = RisocareCommonUtils.hashString(tokenString);
      Optional<Token> optionalToken = tokenRepository.findByValue(hashedToken);
      optionalToken.ifPresent(tokenRepository::delete);
      logger.info("Logged off successfully");
      return true;
    } catch (Exception e) {
      logger.error("Error occurred while logging off");
    }
    return false;
  }

  @Override
  public Optional<Token> findByToken(String token) {
    return tokenRepository.findByValue(token);
  }

  @Override
  public void save(Token token) {
    tokenRepository.save(token);
  }

  public List<Token> findByUserProfile(UserProfile user) {
    return tokenRepository.findByUserProfile(user);
  }

  public void deleteTokenByUserProfile(UserProfile userProfile) {
    tokenRepository.deleteByUserProfile(userProfile);
  }
}
