package com.sunsum.controller.api;

import com.sunsum.model.dto.BulkUploadTracker;
import com.sunsum.model.dto.SheetIngestionResult;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.util.List;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RequestMapping("/api/v1/bulk")
public interface BulkActionsApi {
  @ApiResponses(
      value = {
        @ApiResponse(code = 200, message = "Uploaded Successfully"),
        @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
        @ApiResponse(
            code = 403,
            message = "Accessing the resource you were trying to reach is forbidden"),
        @ApiResponse(code = 404, message = "The resource you were trying to reach is not found"),
        @ApiResponse(code = 500, message = "Internal Server Error"),
      })
  @PostMapping("/upload")
  @PreAuthorize("hasRole('ROLE_PROJECT_ADMIN')")
  ResponseEntity<SheetIngestionResult> upload(@RequestBody MultipartFile file);

  @ApiResponses(
      value = {
        @ApiResponse(code = 200, message = "Downloaded Successfully"),
        @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
        @ApiResponse(
            code = 403,
            message = "Accessing the resource you were trying to reach is forbidden"),
        @ApiResponse(code = 404, message = "The resource you were trying to reach is not found"),
        @ApiResponse(code = 500, message = "Internal Server Error"),
      })
  @GetMapping(path = "/download", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
  @PreAuthorize("hasRole('ROLE_PROJECT_ADMIN')")
  ResponseEntity<byte[]> download(@RequestParam String category);

  @GetMapping(path = "/uploadTracker")
  ResponseEntity<List<BulkUploadTracker>> uploadTracker();
}
