package com.sunsum.controller;

import com.sunsum.controller.api.TaskApi;
import com.sunsum.model.dto.TaskStatusUpdateRequest;
import com.sunsum.model.dto.TaskView;
import com.sunsum.service.TaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class TaskController implements TaskApi {
  private final TaskService taskService;

  public TaskController(TaskService taskService) {
    this.taskService = taskService;
    log.info("TaskController initialized");
  }

  @Override
  public ResponseEntity<TaskView> getTask(Long taskId, Long fieldId) {
    log.info("Received request to get task by taskId: {} and fieldId: {}", taskId, fieldId);

    TaskView task = taskService.getTaskView(taskId, fieldId);
    return ResponseEntity.ok(task);
  }

  @Override
  public ResponseEntity<String> updateTaskStatus(
      Long taskId, TaskStatusUpdateRequest updateRequest) {
    String updatedStatus = taskService.updateTaskStatus(taskId, updateRequest);
    return ResponseEntity.ok(updatedStatus);
  }
}
