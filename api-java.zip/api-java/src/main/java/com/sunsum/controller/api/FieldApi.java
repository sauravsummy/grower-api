package com.sunsum.controller.api;

import com.sunsum.model.dto.FieldRequest;
import com.sunsum.model.dto.FieldResponse;
import com.sunsum.model.dto.FieldUpdateRequest;
import com.sunsum.model.dto.TaskStatusResponse;
import io.swagger.annotations.*;
import java.io.IOException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/fields")
@Api(value = "Field Api")
public interface FieldApi {

  @ApiOperation(value = "Get field details")
  @ApiResponses(
      value = {
        @ApiResponse(code = 200, message = "OK"),
        @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
        @ApiResponse(
            code = 403,
            message = "Accessing the resource you were trying to reach is forbidden"),
        @ApiResponse(code = 404, message = "The resource you were trying to reach is not found"),
        @ApiResponse(code = 500, message = "Internal Server Error"),
      })
  @ApiImplicitParams({
    @ApiImplicitParam(
        name = "authorization",
        value = "A custom Header",
        required = true,
        paramType = "header",
        dataTypeClass = String.class)
  })
  @GetMapping("/{id}")
  ResponseEntity<FieldResponse> getField(@PathVariable("id") String id);

  @ApiOperation(value = "Create new field")
  @ApiResponses(
      value = {
        @ApiResponse(code = 201, message = "Field with title created successfully"),
        @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
        @ApiResponse(
            code = 403,
            message = "Accessing the resource you were trying to reach is forbidden"),
        @ApiResponse(code = 404, message = "The resource you were trying to reach is not found"),
        @ApiResponse(code = 500, message = "Internal Server Error"),
      })
  @ApiImplicitParams({
    @ApiImplicitParam(
        name = "authorization",
        value = "A custom Header",
        required = true,
        paramType = "header",
        dataTypeClass = String.class)
  })
  @PostMapping
  ResponseEntity<String> create(@ModelAttribute FieldRequest fieldRequest) throws IOException;

  @ApiOperation(value = "Update field")
  @ApiResponses(
      value = {
        @ApiResponse(code = 200, message = "Field with title updated successfully"),
        @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
        @ApiResponse(
            code = 403,
            message = "Accessing the resource you were trying to reach is forbidden"),
        @ApiResponse(code = 404, message = "The resource you were trying to reach is not found"),
        @ApiResponse(code = 500, message = "Internal Server Error"),
      })
  @ApiImplicitParams({
    @ApiImplicitParam(
        name = "authorization",
        value = "A custom Header",
        required = true,
        paramType = "header",
        dataTypeClass = String.class)
  })
  @PutMapping("/{id}")
  ResponseEntity<String> update(
      @ModelAttribute FieldUpdateRequest fieldRequest, @PathVariable String id) throws IOException;

  @ApiOperation(value = "get all tasks")
  @ApiResponses(
      value = {
        @ApiResponse(code = 200, message = "Got All Tasks Successfully"),
        @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
        @ApiResponse(
            code = 403,
            message = "Accessing the resource you were trying to reach is forbidden"),
        @ApiResponse(code = 404, message = "The resource you were trying to reach is not found"),
        @ApiResponse(code = 500, message = "Internal Server Error"),
      })
  @ApiImplicitParams({
    @ApiImplicitParam(
        name = "authorization",
        value = "A custom Header",
        required = true,
        paramType = "header",
        dataTypeClass = String.class)
  })
  @GetMapping("/{id}/tasks")
  ResponseEntity<TaskStatusResponse> getAllTasks(@PathVariable("id") String fieldId);

  @ApiOperation(value = "get upcoming tasks")
  @ApiResponses(
      value = {
        @ApiResponse(code = 200, message = "Got All Tasks Successfully"),
        @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
        @ApiResponse(
            code = 403,
            message = "Accessing the resource you were trying to reach is forbidden"),
        @ApiResponse(code = 404, message = "The resource you were trying to reach is not found"),
        @ApiResponse(code = 500, message = "Internal Server Error"),
      })
  @ApiImplicitParams({
    @ApiImplicitParam(
        name = "authorization",
        value = "A custom Header",
        required = true,
        paramType = "header",
        dataTypeClass = String.class)
  })
  @GetMapping("/{id}/tasks/upcoming")
  ResponseEntity<TaskStatusResponse> getUpComingTasks(@PathVariable("id") String fieldId);
}
