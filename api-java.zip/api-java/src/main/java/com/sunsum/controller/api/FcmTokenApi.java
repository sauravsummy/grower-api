package com.sunsum.controller.api;

import com.sunsum.model.dto.FcmTokenRequest;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public interface FcmTokenApi {

  @ApiOperation(value = "Save FCM Token", notes = "Saves the FCM token for a user")
  @ApiResponses(
      value = {
        @ApiResponse(code = 200, message = "FCM Token saved successfully"),
        @ApiResponse(code = 400, message = "Bad Request, invalid input data"),
        @ApiResponse(code = 401, message = "You are not authorized to perform this action"),
        @ApiResponse(code = 404, message = "User not found"),
        @ApiResponse(code = 500, message = "Internal Server Error")
      })
  @PostMapping("/save-fcm-token")
  ResponseEntity<String> saveFcmToken(
      @RequestHeader(name = "Authorization") String authHeader,
      @RequestBody FcmTokenRequest request);
}
