package com.sunsum.controller;

import static com.sunsum.constants.ErrorMsgConstants.UNAUTHORIZED_USER_FOR_FARMHOLDING;

import com.sunsum.controller.api.FarmHoldingApi;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.FarmHoldingResponse;
import com.sunsum.model.dto.FieldTaskStatusResponse;
import com.sunsum.model.dto.FieldTasksStatus;
import com.sunsum.model.dto.FieldsResponse;
import com.sunsum.service.FarmHoldingService;
import com.sunsum.service.FieldService;
import com.sunsum.service.FieldTaskService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class FarmHoldingController implements FarmHoldingApi {

  private final FarmHoldingService farmHoldingService;
  private final FieldService fieldService;
  private final FieldTaskService fieldTaskService;

  @Override
  public ResponseEntity<FarmHoldingResponse> getFarmHoldingsForUser() {
    FarmHoldingResponse farmHoldingResponse = farmHoldingService.getFarmHoldingsForUser();
    return ResponseEntity.ok(farmHoldingResponse);
  }

  @Override
  public ResponseEntity<FieldsResponse> getFields(String farmHoldingId) {
    if (farmHoldingService.hasUserPermissionForFarmHolding(Long.parseLong(farmHoldingId))) {
      return fieldService.getFields(farmHoldingId);
    } else {
      throw new BusinessRuleException(UNAUTHORIZED_USER_FOR_FARMHOLDING, HttpStatus.FORBIDDEN);
    }
  }

  @Override
  public ResponseEntity<FieldTaskStatusResponse> getAllFieldTasks(Long id) {
    List<FieldTasksStatus> fieldTasksStatus = fieldTaskService.getAllFieldsTask(id);
    FieldTaskStatusResponse fieldTaskStatusResponse = new FieldTaskStatusResponse(fieldTasksStatus);
    return ResponseEntity.ok(fieldTaskStatusResponse);
  }

  @Override
  public ResponseEntity<FieldTaskStatusResponse> getUpComingFieldTasks(Long id) {
    List<FieldTasksStatus> fieldTasksStatus = fieldTaskService.getUpcomingFieldTasks(id);
    FieldTaskStatusResponse fieldTaskStatusResponse = new FieldTaskStatusResponse(fieldTasksStatus);
    return ResponseEntity.ok(fieldTaskStatusResponse);
  }
}
