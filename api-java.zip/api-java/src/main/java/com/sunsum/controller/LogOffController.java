package com.sunsum.controller;

import com.sunsum.constants.ErrorMsgConstants;
import com.sunsum.controller.api.LogOffApi;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.util.CommonUtils;
import com.sunsum.service.TokenService;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LogOffController implements LogOffApi {

  private static final Logger logger = LoggerFactory.getLogger(LogOffController.class);

  private final HttpServletRequest request;
  private final TokenService tokenService;
  private final CommonUtils commonUtils;

  public LogOffController(
      HttpServletRequest request, TokenService tokenService, CommonUtils commonUtils) {
    this.request = request;
    this.tokenService = tokenService;
    this.commonUtils = commonUtils;
    logger.info("LogOffController initialized");
  }

  @Override
  public ResponseEntity<String> logoff(String authHeader) {
    logger.info("Logoff request started from IP: {}", request.getRemoteAddr());

    String tokenString = authHeader.substring(7);
    try {
      logger.debug(
          "Attempting logoff for token: {}",
          tokenString); // Token might be sensitive, consider hashing
      boolean isLoggedOff = tokenService.logoff(tokenString);
      logger.info("Logoff status for token {}: {}", tokenString, isLoggedOff);
      return isLoggedOff
          ? ResponseEntity.ok("User successfully logged off.")
          : ResponseEntity.status(HttpStatus.UNAUTHORIZED)
              .body("Invalid token." + ErrorMsgConstants.UNAUTHORIZED_USER_MSG);
    } catch (Exception e) {
      logger.error("Error occurred during logoff for token {}: ", tokenString, e);
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error occurred.");
    } finally {
      logger.info("Logoff request completed for IP: {}", request.getRemoteAddr());
    }
  }

  @Override
  public ResponseEntity<String> logoffAllDevices(String authHeader) {
    logger.info("Logoff request started from IP: {}", request.getRemoteAddr());

    try {
      logger.debug("Attempting logoff from all devices");
      UserProfile userProfile =
          commonUtils
              .getCurrentLoggedInUser()
              .orElseThrow(
                  () -> new BusinessRuleException(ErrorMsgConstants.UNAUTHORIZED_USER_MSG, HttpStatus.UNAUTHORIZED));
      tokenService.deleteTokenByUserProfile(userProfile);
      return ResponseEntity.ok("User successfully logged off from all devices.");
    } catch (Exception e) {
      logger.error(
          "Error occurred during logging off from all devices due to {} {} : ",
          e.getMessage(),
          e.getCause());
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error occurred.");
    } finally {
      logger.info("Logoff request completed for IP: {}", request.getRemoteAddr());
    }
  }
}
