package com.sunsum.controller.api;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/api/v1")
public interface LogOffApi {

  @ApiOperation(value = "Log off the user")
  @ApiResponses(
      value = {
        @ApiResponse(code = 200, message = "Logged off Successfully"),
        @ApiResponse(code = 401, message = "You are not authorized to perform this action"),
        @ApiResponse(code = 500, message = "Internal Server Error")
      })
  @ApiImplicitParams({
    @ApiImplicitParam(
        name = "authorization",
        value = "Auth Header",
        required = true,
        paramType = "header",
        dataTypeClass = String.class)
  })
  @PostMapping("/logoff")
  ResponseEntity<String> logoff(@RequestHeader("Authorization") String authHeader);

  @ApiOperation(value = "Log off the user from all devices")
  @ApiResponses(
      value = {
        @ApiResponse(code = 200, message = "Logged off Successfully"),
        @ApiResponse(code = 401, message = "You are not authorized to perform this action"),
        @ApiResponse(code = 500, message = "Internal Server Error")
      })
  @ApiImplicitParams({
    @ApiImplicitParam(
        name = "authorization",
        value = "Auth Header",
        required = true,
        paramType = "header",
        dataTypeClass = String.class)
  })
  @PostMapping("/logoff/all")
  ResponseEntity<String> logoffAllDevices(@RequestHeader("Authorization") String authHeader);
}
