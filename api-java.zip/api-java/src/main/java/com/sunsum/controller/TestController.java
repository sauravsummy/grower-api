package com.sunsum.controller;

import com.sunsum.repository.OrganisationRepository;
import com.sunsum.repository.UserProfileRepository;
import com.sunsum.model.entity.Organization;
import com.sunsum.model.entity.UserProfile;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequiredArgsConstructor
@RequestMapping("/api/v1")
@RestController()
public class TestController {

  private final UserProfileRepository userProfileRepository;
  private final OrganisationRepository organisationRepository;

  @GetMapping("/test")
  public void test() {
    Organization organization = organisationRepository.findById(1L).get();
    UserProfile userProfile =
        UserProfile.builder()
            .name("test-user-3")
            .email("test-6@test.com")
            .isActive(true)
            .organization(organization)
            .build();
    UserProfile userProfile1 =
        UserProfile.builder()
            .name("test-user-4")
            .email("test-7@test.com")
            .isActive(true)
            .organization(organization)
            .build();

    userProfileRepository.saveAll(List.of(userProfile1, userProfile));
  }
}
