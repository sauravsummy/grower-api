package com.sunsum.controller;

import com.sunsum.client.impl.AmazonSESEmailClient;
import com.sunsum.controller.api.NotificationApi;
import com.sunsum.model.dto.EmailDTO;
import com.sunsum.schedular.NotificationSchedular;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class NotificationController implements NotificationApi {

  private final AmazonSESEmailClient amazonSESEmailClient;
  private final NotificationSchedular notificationSchedular;

  public NotificationController(
      AmazonSESEmailClient amazonSESEmailClient, NotificationSchedular notificationSchedular) {
    this.amazonSESEmailClient = amazonSESEmailClient;
    this.notificationSchedular = notificationSchedular;
  }

  @Override
  public void sendEmail(@RequestBody EmailDTO emailDTO) {
    amazonSESEmailClient.sendEmail(emailDTO);
  }

  @Override
  public void sendNotification() {
    notificationSchedular.runTask();
  }
}
