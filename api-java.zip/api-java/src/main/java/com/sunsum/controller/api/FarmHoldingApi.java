package com.sunsum.controller.api;

import com.sunsum.model.dto.FarmHoldingResponse;
import com.sunsum.model.dto.FieldTaskStatusResponse;
import com.sunsum.model.dto.FieldsResponse;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/farmholdings")
public interface FarmHoldingApi {

  @ApiOperation(value = "get farm holdings")
  @ApiResponses(
      value = {
        @ApiResponse(code = 200, message = "Got Farm Holdings Successfully"),
        @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
        @ApiResponse(
            code = 403,
            message = "Accessing the resource you were trying to reach is forbidden"),
        @ApiResponse(code = 404, message = "The resource you were trying to reach is not found"),
        @ApiResponse(code = 500, message = "Internal Server Error"),
      })
  @ApiImplicitParams({
    @ApiImplicitParam(
        name = "authorization",
        value = "A custom Header",
        required = true,
        paramType = "header",
        dataTypeClass = String.class)
  })
  @GetMapping
  ResponseEntity<FarmHoldingResponse> getFarmHoldingsForUser();

  @ApiOperation(value = "Get list of fields")
  @ApiResponses(
      value = {
        @ApiResponse(code = 200, message = "OK"),
        @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
        @ApiResponse(
            code = 403,
            message = "Accessing the resource you were trying to reach is forbidden"),
        @ApiResponse(code = 404, message = "The resource you were trying to reach is not found"),
        @ApiResponse(code = 500, message = "Internal Server Error"),
      })
  @ApiImplicitParams({
    @ApiImplicitParam(
        name = "authorization",
        value = "A custom Header",
        required = true,
        paramType = "header",
        dataTypeClass = String.class)
  })
  @ApiParam
  @GetMapping("/{id}/fields")
  ResponseEntity<FieldsResponse> getFields(@PathVariable("id") String farmHoldingId);

  @ApiOperation(value = "Get list of all fields and its associated task")
  @ApiResponses(
      value = {
        @ApiResponse(code = 200, message = "OK"),
        @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
        @ApiResponse(
            code = 403,
            message = "Accessing the resource you were trying to reach is forbidden"),
        @ApiResponse(code = 404, message = "The resource you were trying to reach is not found"),
        @ApiResponse(code = 500, message = "Internal Server Error"),
      })
  @ApiImplicitParams({
    @ApiImplicitParam(
        name = "authorization",
        value = "A custom Header",
        required = true,
        paramType = "header",
        dataTypeClass = String.class)
  })
  @GetMapping("/{id}/all-tasks")
  ResponseEntity<FieldTaskStatusResponse> getAllFieldTasks(@PathVariable("id") Long id);

  @ApiOperation(value = "Get list of all fields and its associated upcoming task")
  @ApiResponses(
      value = {
        @ApiResponse(code = 200, message = "OK"),
        @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
        @ApiResponse(
            code = 403,
            message = "Accessing the resource you were trying to reach is forbidden"),
        @ApiResponse(code = 404, message = "The resource you were trying to reach is not found"),
        @ApiResponse(code = 500, message = "Internal Server Error"),
      })
  @ApiImplicitParams({
    @ApiImplicitParam(
        name = "authorization",
        value = "A custom Header",
        required = true,
        paramType = "header",
        dataTypeClass = String.class)
  })
  @GetMapping("/{id}/upcoming-tasks")
  ResponseEntity<FieldTaskStatusResponse> getUpComingFieldTasks(@PathVariable("id") Long id);
}
