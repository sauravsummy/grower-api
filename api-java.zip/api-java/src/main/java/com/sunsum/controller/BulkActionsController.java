package com.sunsum.controller;

import com.google.common.io.ByteStreams;
import com.sunsum.constants.AppConstants;
import com.sunsum.controller.api.BulkActionsApi;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.BulkUploadTracker;
import com.sunsum.model.dto.SheetIngestionResult;
import com.sunsum.service.DownloadService;
import com.sunsum.service.UploadService;
import java.io.ByteArrayInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@Slf4j
public class BulkActionsController implements BulkActionsApi {

  private final UploadService uploadService;

  private final DownloadService downloadService;

  public BulkActionsController(UploadService uploadService, DownloadService downloadService) {
    this.uploadService = uploadService;
    this.downloadService = downloadService;
  }

  @Override
  public ResponseEntity<SheetIngestionResult> upload(MultipartFile file) {
    SheetIngestionResult results = uploadService.bulkInsert(file);

    return new ResponseEntity<>(results, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<byte[]> download(String category) {
    DateFormat dateFormatter = new SimpleDateFormat(AppConstants.DATE_FORMAT_FOR_FILE_NAME);
    String currentDateTime = dateFormatter.format(new Date());
    category = category.trim().toLowerCase();
    try (ByteArrayInputStream stream = downloadService.download(category)) {
      byte[] byteArray = ByteStreams.toByteArray(stream);
      return ResponseEntity.ok()
          .contentType(MediaType.APPLICATION_OCTET_STREAM)
          .header(
              HttpHeaders.CONTENT_DISPOSITION,
              AppConstants.ATTACHMENT_FILENAME_QUERY_HEADER_VALUE
                  + currentDateTime
                  + AppConstants.HYPHEN
                  + category
                  + AppConstants.EXCEL_EXTENSION)
          .body(byteArray);
    } catch (Exception e) {
      throw new BusinessRuleException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  /**
   * API to fetch the uploaded details of each file type
   *
   * @return
   */
  @Override
  public ResponseEntity<List<BulkUploadTracker>> uploadTracker() {

    List<BulkUploadTracker> response = uploadService.getUploadTrackerDetails();
    return new ResponseEntity<>(response, HttpStatus.OK);
  }
}
