package com.sunsum.controller;

import com.sunsum.constants.ErrorMsgConstants;
import com.sunsum.controller.api.FieldApi;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.FieldRequest;
import com.sunsum.model.dto.FieldUpdateRequest;
import com.sunsum.model.dto.TaskStatusResponse;
import com.sunsum.service.FieldService;
import com.sunsum.service.TaskService;
import com.sunsum.model.dto.FieldResponse;
import java.io.IOException;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class FieldController implements FieldApi {

  private final FieldService fieldService;
  private final TaskService taskService;

  @Override
  public ResponseEntity<FieldResponse> getField(String id) {
    ResponseEntity<FieldResponse> fieldResponse = fieldService.getField(id);
    if (fieldService.hasUserPermissionForField(Long.parseLong(id))) {
      return fieldResponse;
    } else {
      throw new BusinessRuleException(ErrorMsgConstants.UNAUTHORIZED_USER_FOR_FIELD, HttpStatus.FORBIDDEN);
    }
  }

  @Override
  public ResponseEntity<String> create(@ModelAttribute @Valid FieldRequest fieldRequest)
      throws IOException {
    return fieldService.createField(fieldRequest);
  }

  @Override
  public ResponseEntity<String> update(@ModelAttribute FieldUpdateRequest fieldRequest, String id) {
    if (fieldService.hasUserPermissionForField(Long.parseLong(id))) {
      return fieldService.updateField(fieldRequest, id);
    } else {
      throw new BusinessRuleException(ErrorMsgConstants.UNAUTHORIZED_USER_FOR_FIELD, HttpStatus.FORBIDDEN);
    }
  }

  @Override
  public ResponseEntity<TaskStatusResponse> getAllTasks(String fieldId) {
    if (fieldService.hasUserPermissionForField(Long.parseLong(fieldId))) {
      TaskStatusResponse taskStatusResponse = taskService.getAllTasks(fieldId);
      return ResponseEntity.ok(taskStatusResponse);
    } else {
      throw new BusinessRuleException(ErrorMsgConstants.UNAUTHORIZED_USER_FOR_FIELD, HttpStatus.FORBIDDEN);
    }
  }

  @Override
  public ResponseEntity<TaskStatusResponse> getUpComingTasks(@PathVariable("id") String fieldId) {
    if (fieldService.hasUserPermissionForField(Long.parseLong(fieldId))) {
      TaskStatusResponse taskStatusResponse = taskService.getUpcomingTasks(fieldId);
      return ResponseEntity.ok(taskStatusResponse);
    } else {
      throw new BusinessRuleException(ErrorMsgConstants.UNAUTHORIZED_USER_FOR_FIELD, HttpStatus.FORBIDDEN);
    }
  }
}
