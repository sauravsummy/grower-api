package com.sunsum.controller.api;

import com.sunsum.model.dto.TaskStatusUpdateRequest;
import com.sunsum.model.dto.TaskView;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/tasks")
@Api(value = "Task Api")
public interface TaskApi {

  @ApiOperation(value = "Get task by task ID and field ID")
  @ApiResponses(
      value = {
        @ApiResponse(code = 200, message = "OK"),
        @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
        @ApiResponse(
            code = 403,
            message = "Accessing the resource you were trying to reach is forbidden"),
        @ApiResponse(code = 404, message = "The resource you were trying to reach is not found"),
        @ApiResponse(code = 500, message = "Internal Server Error")
      })
  @ApiParam
  @GetMapping("/{id}")
  ResponseEntity<TaskView> getTask(@PathVariable("id") Long taskId, @RequestParam Long fieldId);

  @ApiOperation(value = "Update Task status")
  @ApiResponses(
      value = {
        @ApiResponse(code = 201, message = "Updated successfully"),
        @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
        @ApiResponse(
            code = 403,
            message = "Accessing the resource you were trying to reach is forbidden"),
        @ApiResponse(code = 404, message = "The resource you were trying to reach is not found"),
        @ApiResponse(code = 500, message = "Internal Server Error"),
      })
  @ApiImplicitParams({
    @ApiImplicitParam(
        name = "authorization",
        value = "A custom Header",
        required = true,
        paramType = "header",
        dataTypeClass = String.class)
  })
  @PutMapping("/{id}/execute")
  ResponseEntity<String> updateTaskStatus(
      @PathVariable("id") Long taskId, @ModelAttribute TaskStatusUpdateRequest updateRequest);
}
