package com.sunsum.controller;

import com.sunsum.controller.api.FcmTokenApi;
import com.sunsum.model.dto.FcmTokenRequest;
import com.sunsum.service.FcmTokenService;
import com.sunsum.util.JwtUtil;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@AllArgsConstructor
public class FcmTokenController implements FcmTokenApi {

  private final FcmTokenService fcmTokenService;
  private final JwtUtil jwtUtil;

  @Override
  public ResponseEntity<String> saveFcmToken(
      @RequestHeader(name = "Authorization") String authHeader,
      @RequestBody FcmTokenRequest request) {
    String token = authHeader.replace("Bearer ", "");
    String userId = jwtUtil.extractUserId(token);

    if (userId == null) {
      return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid user ID");
    }

    log.info("Saving FCM token for user: {}", userId);
    request.setUserId(Long.valueOf(userId));
    fcmTokenService.saveFcmToken(request);

    return ResponseEntity.ok("FCM Token saved successfully");
  }
}
