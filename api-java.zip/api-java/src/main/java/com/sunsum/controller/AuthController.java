package com.sunsum.controller;

import com.google.gson.Gson;
import com.sunsum.constants.AppConstants;
import com.sunsum.constants.ErrorMsgConstants;
import com.sunsum.controller.api.AuthApi;
import com.sunsum.exception.BusinessRuleException;
import com.sunsum.model.dto.OtpVerifyRequest;
import com.sunsum.model.entity.Token;
import com.sunsum.model.entity.UserProfile;
import com.sunsum.util.RisocareCommonUtils;
import com.sunsum.service.TokenService;
import com.sunsum.util.JwtUtil;
import java.util.List;
import java.util.Map;
import javax.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class AuthController implements AuthApi {

  @Value("${deviceLoginLimit:20}")
  private Long deviceLoginLimit;

  private final AuthenticationManager authenticationManager;
  private final TokenService tokenService;
  private final JwtUtil jwtUtil;

  public AuthController(
      TokenService tokenService, AuthenticationManager authenticationManager, JwtUtil jwtUtil) {
    this.tokenService = tokenService;
    this.authenticationManager = authenticationManager;
    this.jwtUtil = jwtUtil;
  }

  @Override
  public ResponseEntity<String> auth(@RequestBody @Valid OtpVerifyRequest otpVerifyRequest) {
    try {
      UserProfile user = authenticateUser(otpVerifyRequest);
      String token = createTokenForUser(user);

      /*
       * Verify the token limit: Users are allowed to have up to a specified number of distinct tokens,
       * each intended for use on separate devices.
       * */
      long exitingTokensCount = tokenService.findByUserProfile(user).stream().count();
      if (deviceLoginLimit.compareTo(exitingTokensCount) <= 0) {
        Map<String, String> responseBody =
            Map.of("message", ErrorMsgConstants.MAX_DEVICE_LOGIN_LIMIT_REACHED, AppConstants.TOKEN, token);
        return new ResponseEntity<>(new Gson().toJson(responseBody), HttpStatus.TOO_MANY_REQUESTS);
      }

      saveToken(token, user);
      Map<String, String> responseBody = Map.of("user", user.getName(), AppConstants.TOKEN, token);
      return ResponseEntity.ok(new Gson().toJson(responseBody));

    } catch (BadCredentialsException | UsernameNotFoundException e) {
      throw new BusinessRuleException(ErrorMsgConstants.UNAUTHORIZED_USER_MSG, HttpStatus.UNAUTHORIZED);
    } catch (Exception e) {
      throw new BusinessRuleException(ErrorMsgConstants.UNABLE_TO_AUTHORIZE_USER, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  private UserProfile authenticateUser(OtpVerifyRequest otpVerifyRequest) {
    Authentication authentication =
        authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(otpVerifyRequest, otpVerifyRequest.getOtp()));
    return (UserProfile) authentication.getPrincipal();
  }

  private String createTokenForUser(UserProfile user) {
    List<SimpleGrantedAuthority> authorities =
        user.getRoles().stream()
            .map(role -> new SimpleGrantedAuthority(role.getName().name()))
            .toList();
    return jwtUtil.getToken(user.getId().toString(), authorities);
  }

  private void saveToken(String value, UserProfile user) {
    String hashedToken = RisocareCommonUtils.hashString(value);
    Token token = new Token();
    token.setValue(hashedToken);
    token.setUserProfile(user);
    token.setRevoked(false);
    // Save the token
    tokenService.save(token);
  }
}
