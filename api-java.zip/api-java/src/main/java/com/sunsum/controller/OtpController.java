package com.sunsum.controller;

import com.sunsum.controller.api.OtpApi;
import com.sunsum.service.OtpService;
import javax.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
public class OtpController implements OtpApi {

  private final OtpService otpService;

  @Override
  public ResponseEntity<String> sendOtpToMobile(String mobileNo, HttpServletRequest request) {
    log.info("*******OTP request by User Agent : {}", request.getHeader("User-Agent"));
    log.info(
        "*******OTP request by IP address: {} & mobileno: {}", request.getRemoteAddr(), mobileNo);
    return otpService.sendOtpToMobile(mobileNo);
  }

  @Override
  public ResponseEntity<String> sendOtpToEmail(String emailId, HttpServletRequest request) {
    log.info("*******OTP request by User Agent : {}", request.getHeader("User-Agent"));
    log.info(
        "*******OTP request by IP address: {} & emailId: {}", request.getRemoteAddr(), emailId);

    return otpService.sendOtpToEmail(emailId);
  }
}
