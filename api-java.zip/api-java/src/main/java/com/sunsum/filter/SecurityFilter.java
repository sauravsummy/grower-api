package com.sunsum.filter;

import com.sunsum.model.entity.Token;
import com.sunsum.util.RisocareCommonUtils;
import com.sunsum.service.TokenService;
import com.sunsum.util.JwtUtil;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;
import java.io.IOException;
import java.util.Optional;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
@Slf4j
public class SecurityFilter extends OncePerRequestFilter {

  private final JwtUtil jwtUtil;

  private final TokenService tokenService;

  private final UserDetailsService userDetailsService;

  public SecurityFilter(
      JwtUtil jwtUtil, TokenService tokenService, UserDetailsService userDetailsService) {
    this.jwtUtil = jwtUtil;
    this.tokenService = tokenService;
    this.userDetailsService = userDetailsService;
  }

  @Override
  protected void doFilterInternal(
      HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
      throws ServletException, IOException {

    String requestURI = request.getRequestURI();
    String clientIP = request.getRemoteAddr();
    log.info("Incoming request to URI: {} from IP: {}", requestURI, clientIP);

    String httpMethod = request.getMethod();
    log.info("Request method: {}", httpMethod);

    String authHeader = request.getHeader("Authorization");
    String token = null;
    String userId = null;

    if (authHeader != null && authHeader.startsWith("Bearer ")) {
      token = authHeader.substring(7);
      try {
        userId = jwtUtil.extractUserId(token);
      } catch (ExpiredJwtException
          | UnsupportedJwtException
          | MalformedJwtException
          | SignatureException e) {
        log.error("Exception happened while parsing token", e);
        response.setStatus(HttpServletResponse.SC_FORBIDDEN);
        response.sendError(HttpServletResponse.SC_FORBIDDEN, e.getMessage());
        return;
      }
    }

    if (isInValidToken(request, response, token, userId)) {
      return;
    }

    filterChain.doFilter(request, response);
  }

  private boolean isInValidToken(
      HttpServletRequest request, HttpServletResponse response, String token, String userId) {
    if (token != null && SecurityContextHolder.getContext().getAuthentication() == null) {
      String hashedStoredToken = RisocareCommonUtils.hashString(token);

      Optional<Token> storedToken = tokenService.findByToken(hashedStoredToken);
      UserDetails userDetails = userDetailsService.loadUserByUsername(userId);
      if (isValidTokenRequest(request, storedToken) && jwtUtil.isValid(token, userDetails)) {
        UsernamePasswordAuthenticationToken authenticationToken =
            new UsernamePasswordAuthenticationToken(
                userDetails.getUsername(), null, userDetails.getAuthorities());
        authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
        SecurityContextHolder.getContext().setAuthentication(authenticationToken);

      } else {
        log.warn("Unauthorized access attempt: {}", token);
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        return true;
      }
    }
    return false;
  }

  private static boolean isValidTokenRequest(
      HttpServletRequest request, Optional<Token> storedToken) {
    return (storedToken.isPresent() || request.getRequestURI().contains("logoff"));
  }
}
