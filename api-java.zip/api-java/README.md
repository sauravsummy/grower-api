# Cropwise Smallholder Risocare Backend

## Getting Started
1. clone this repo;
2. import in STS;
3. turn on SonarLint;
4. run localstack;
5. run.

The app will be listening on `port: 8084`

## Contributing

### Version Control

- Git-flow, _checking out from_ / _merging to_ branch `develop`;
- At least 1 reviewer required;
- Be gentle in the comments when code reviewing;
- Test the changes before merging.

### Creating Branches

- for feature branches, use the prefix `feature/`
- for stub branches, use the prefix `stub/`
- for bugfix branches, use the prefix `bugfix/`

### Commiting
- Keep commits short - it facilitates code reviewing, since it's easy to match the code with its intention;
- Follow [these guidelines](https://chris.beams.io/posts/git-commit/); no need to be too strict, but make sure to respect rule #5.

### CI/CD
- SonarCloud is disabled for now, but new code with _smells_ or _warnings_ must be rejected.

### Package Structure

Try to follow the suggested package structure and classes' naming convention:

com.sunsum.stub <br>
  └─ api <br>
    └─ helloworld <br>
      └─ controller <br>
        └─ HelloWord**Controller**.java <br>
      └─ data <br>
        └─ request <br>
          └─ GetAll**QueryParams**.java <br>
    ├─ **[your API's base resource]** <br>
      └─ controller <br>
        └─ **[resource name]-Controller**.java <br>
      └─ data <br>
        └─ request <br>
          └─ **[method name]-QueryParams**.java <br>
          └─ **[method name]-Body** (when you need to validate the payload structure) <br>

### Localstack

- localStack is a cloud service emulator that runs in a single container on your laptop or in your CI environment.
- localstack is being used to test AWS access locally through this application, to reduce development time and increase product velocity.
- For more details on localstack visit official site https://www.localstack.cloud/
- To set up localstack on your local visit https://github.com/marketplace/actions/setup-localstack
- Once localstack is up and running in your local machine **use awslocal** command to create resource; for example to create s3 bucket use below command:
`awslocal s3api create-bucket \
--bucket dev-sunsum-assets \
--create-bucket-configuration LocationConstraint=eu-central-1`
for more details on awslocal command visit https://github.com/localstack/awscli-local

Feel free to propose conventions for unforeseen cases or to update existing ones.
